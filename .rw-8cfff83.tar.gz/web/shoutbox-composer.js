export function enableShiftEnterSubmit(textarea) {
  textarea.addEventListener('keydown', (event) => {
    if (
      event.defaultPrevented ||
      event.isComposing ||
      event.key !== 'Enter' ||
      !event.shiftKey ||
      event.altKey ||
      event.ctrlKey ||
      event.metaKey ||
      !textarea.form
    ) {
      return;
    }

    event.preventDefault();
    textarea.form.requestSubmit();
  });
}