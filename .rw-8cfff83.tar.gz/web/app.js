import {
  deletePostAttachment,
  loadSession,
  request,
  uploadPostAttachment,
} from './client.js';
import { renderAvatar } from './avatar-view.js';
import {
  clearPendingAttachments,
  enhanceMarkdownEditors,
  getPendingAttachments,
  retainPendingAttachments,
} from './markdown-editor.js';
import { enhanceMentionAutocompletes } from './mention-autocomplete.js';
import { renderMarkdown } from './markdown-view.js';
import { renderMentions } from './mention-view.js';
import { awaitPresence } from './presence-gate.js';
import {
  createShoutboxSound,
  shouldPlayShoutboxSound,
} from './shoutbox-sound.js';
import { enableShiftEnterSubmit } from './shoutbox-composer.js';
import { renderUsernameColor } from './username-color.js';

const unreadCount = document.querySelector('#unread-count');
const forumStatus = document.querySelector('#forum-status');
const forumSearchForm = document.querySelector('#forum-search-form');
const forumSearchQuery = document.querySelector('#forum-search-query');
const forumSearchClear = document.querySelector('#forum-search-clear');
const newTopicButton = document.querySelector('#new-topic-button');
const newTopicDialog = document.querySelector('#new-topic-dialog');
const newTopicForm = document.querySelector('#new-topic-form');
const topicList = document.querySelector('#topic-list');
const topicsMore = document.querySelector('#topics-more');
const searchResults = document.querySelector('#search-results');
const searchMore = document.querySelector('#search-more');
const topicView = document.querySelector('#topic-view');
const topicBack = document.querySelector('#topic-back');
const topicTitle = document.querySelector('#topic-title');
const topicSubscribe = document.querySelector('#topic-subscribe');
const topicLock = document.querySelector('#topic-lock');
const topicEdit = document.querySelector('#topic-edit');
const topicDelete = document.querySelector('#topic-delete');
const topicEditDialog = document.querySelector('#topic-edit-dialog');
const topicEditForm = document.querySelector('#topic-edit-form');
const topicEditReasonControl = document.querySelector('#topic-edit-reason-control');
const topicEditStatus = document.querySelector('#topic-edit-status');
const postList = document.querySelector('#post-list');
const topicPagination = document.querySelector('#topic-pagination');
const postsPrevious = document.querySelector('#posts-previous');
const postsNext = document.querySelector('#posts-next');
const replyForm = document.querySelector('#reply-form');
const postEditDialog = document.querySelector('#post-edit-dialog');
const postEditForm = document.querySelector('#post-edit-form');
const editReasonControl = document.querySelector('#edit-reason-control');
const postEditStatus = document.querySelector('#post-edit-status');
const shoutboxPane = document.querySelector('#shoutbox');
const shoutboxToggle = document.querySelector('#shoutbox-toggle');
const shoutboxMute = document.querySelector('#shoutbox-mute');
const shoutboxMuteIcon = document.querySelector('#shoutbox-mute-icon');
const shoutboxForm = document.querySelector('#shoutbox-form');
const shoutboxInput = document.querySelector('#shoutbox-message');
const shoutboxLog = document.querySelector('#shoutbox-log');
const shoutboxStatus = document.querySelector('#shoutbox-status');
const shoutEditDialog = document.querySelector('#shout-edit-dialog');
const shoutEditForm = document.querySelector('#shout-edit-form');
const shoutEditReasonControl = document.querySelector('#shout-edit-reason-control');
const shoutboxSound = createShoutboxSound();

let account = null;
let notificationLoadPromise = null;
let notificationUnreadCount = 0;
let shoutboxCooldownTimer = null;
let shoutboxCursor = null;
let shoutboxReconnectAttempt = 0;
let shoutboxReconnectTimer = null;
let shoutboxSocket = null;
let selectedShout = null;
let selectedTopic = null;
let searchHasMore = false;
let searchOffset = 0;
let searchQuery = '';
let topicPostsHasMore = false;
const attachmentRetryTargets = new WeakMap();
let topicPostsOffset = 0;
let topicsHasMore = false;
let topicsOffset = 0;

function unlockShoutboxSound() {
  void shoutboxSound.unlock().then((unlocked) => {
    if (!unlocked) {
      return;
    }
    document.removeEventListener('keydown', unlockShoutboxSound, true);
    document.removeEventListener('pointerdown', unlockShoutboxSound, true);
  });
}

document.addEventListener('keydown', unlockShoutboxSound, true);
document.addEventListener('pointerdown', unlockShoutboxSound, true);

function canModeratePosts() {
  return account?.role === 'admin' || account?.permissions.includes('posts.moderate');
}

async function searchMentionUsernames(prefix) {
  const result = await request(`/api/profiles?prefix=${encodeURIComponent(prefix)}`);
  return result.usernames;
}

function canModerateShouts() {
  return account?.role === 'admin' || account?.permissions.includes('shouts.moderate');
}

function canManageTopic() {
  return selectedTopic?.authorId === account?.id || canModeratePosts();
}

function setForumStatus(message, error = false) {
  forumStatus.textContent = message;
  forumStatus.dataset.error = String(error);
}

function postingErrorMessage(error, fallback) {
  if (error?.code === 'forum_posting_muted') {
    return 'Forum posting is muted for this account.';
  }
  if (![
    'posting_flood_detected',
    'posting_rate_limited',
    'posting_slowdown',
  ].includes(error?.code)) {
    return fallback;
  }
  return `Slow mode: try again in ${Math.ceil((error.retryAfterMs ?? 1000) / 1000)} seconds.`;
}

function forumEditErrorMessage(error, fallback) {
  if (error?.code === 'post_edit_conflict') {
    return 'This post changed. Close and reopen the editor before trying again.';
  }
  if (error?.code === 'topic_edit_conflict') {
    return 'This topic changed. Close and reopen the editor before trying again.';
  }
  return fallback;
}

function createProfileLink(identity, content) {
  const link = document.createElement('a');
  link.className = 'profile-link';
  renderUsernameColor(link, identity.usernameColor);
  link.href = `/profile?username=${encodeURIComponent(identity.authorUsername)}`;
  link.append(...content);
  return link;
}

function createTopicItem(topic) {
  const button = document.createElement('button');
  button.className = 'topic-item';
  button.type = 'button';
  const title = document.createElement('strong');
  title.textContent = topic.title;
  const meta = document.createElement('span');
  meta.textContent = `${topic.author} · ${topic.postCount} posts`;
  button.append(title, meta);
  button.addEventListener('click', () => window.RWShell.navigate(`/?topic=${topic.id}`));
  return button;
}

async function loadTopics(reset = false) {
  if (reset) {
    topicsOffset = 0;
  }
  const result = await request(`/api/topics?limit=20&offset=${topicsOffset}`);
  const items = result.topics.map(createTopicItem);
  if (reset) {
    topicList.replaceChildren(...items);
  } else {
    topicList.append(...items);
  }
  topicsOffset = result.nextOffset;
  topicsHasMore = result.hasMore;
  topicsMore.hidden = !result.hasMore;
}

function createSearchResultItem(result) {
  const button = document.createElement('button');
  button.className = 'topic-item search-result';
  button.type = 'button';
  const title = document.createElement('strong');
  title.textContent = result.topic.title;
  const excerpt = document.createElement('p');
  excerpt.textContent = result.excerpt;
  const meta = document.createElement('span');
  meta.textContent = result.post
    ? `${result.post.author} · ${new Date(result.post.createdAt).toLocaleString()}`
    : `Topic by ${result.topic.author}`;
  button.append(title, excerpt, meta);
  button.addEventListener('click', () => window.RWShell.navigate(
    `/?topic=${result.topic.id}&post=${result.post?.id ?? ''}&offset=${Math.floor(result.postOffset / 50) * 50}`,
  ));
  return button;
}

async function loadSearch(reset = false) {
  if (reset) {
    searchOffset = 0;
  }
  setForumStatus('Searching...');
  const result = await request(
    `/api/forum/search?q=${encodeURIComponent(searchQuery)}&limit=20&offset=${searchOffset}`,
  );
  const items = result.results.map(createSearchResultItem);
  if (reset) {
    searchResults.replaceChildren(...items);
  } else {
    searchResults.append(...items);
  }
  searchOffset = result.nextOffset;
  searchHasMore = result.hasMore;
  topicList.hidden = true;
  topicsMore.hidden = true;
  searchResults.hidden = false;
  searchMore.hidden = !searchHasMore;
  forumSearchClear.hidden = false;
  setForumStatus(searchResults.childElementCount === 0 ? 'No matching forum content.' : '');
}

function createPostItem(post) {
  const item = document.createElement('article');
  item.className = 'forum-post';
  item.dataset.postId = post.id;
  item.tabIndex = -1;
  const header = document.createElement('header');
  const authorGroup = document.createElement('div');
  authorGroup.className = 'post-author';
  const avatar = document.createElement('span');
  avatar.className = 'account-avatar';
  renderAvatar(avatar, post, post.author);
  const author = document.createElement('strong');
  author.textContent = post.author;
  const time = document.createElement('time');
  time.dateTime = new Date(post.createdAt).toISOString();
  time.textContent = new Date(post.createdAt).toLocaleString();
  authorGroup.append(createProfileLink(post, [avatar, author]));
  header.append(authorGroup, time);
  const body = document.createElement('div');
  body.className = 'forum-post-body';
  if (post.deleted) {
    renderMentions(body, 'Post deleted');
  } else {
    renderMarkdown(body, post.body, post.mentionUsernames);
  }
  item.append(header, body);
  if (!post.deleted && post.attachments?.length) {
    const canManageAttachments = post.authorId === account.id
      || selectedTopic?.authorId === account.id
      || canModeratePosts();
    const attachments = document.createElement('div');
    attachments.className = 'post-attachments';
    for (const attachment of post.attachments) {
      const media = document.createElement('figure');
      media.className = 'post-attachment';
      if (attachment.contentType.startsWith('image/')) {
        const image = document.createElement('img');
        image.alt = attachment.name;
        image.decoding = 'async';
        image.loading = 'lazy';
        image.src = attachment.url;
        media.append(image);
      } else {
        const player = document.createElement(
          attachment.contentType.startsWith('audio/') ? 'audio' : 'video',
        );
        player.controls = true;
        player.preload = 'metadata';
        player.src = attachment.url;
        media.append(player);
      }
      const caption = document.createElement('figcaption');
      caption.className = 'post-attachment-caption';
      const link = document.createElement('a');
      link.download = attachment.name;
      link.href = attachment.url;
      link.textContent = attachment.name;
      caption.append(link, document.createTextNode(` · ${Math.ceil(attachment.size / 1024)} KiB`));
      if (canManageAttachments) {
        const remove = document.createElement('button');
        remove.className = 'post-attachment-remove';
        remove.type = 'button';
        remove.setAttribute('aria-label', `Remove attachment ${attachment.name}`);
        remove.title = 'Remove attachment';
        remove.textContent = '×';
        remove.addEventListener('click', async () => {
          if (!window.confirm(`Remove ${attachment.name}?`)) {
            return;
          }
          remove.disabled = true;
          try {
            await deletePostAttachment(
              attachment.id,
              canModeratePosts() ? 'Removed by moderator' : undefined,
            );
            await openTopic(selectedTopic.id, topicPostsOffset);
          } catch {
            setForumStatus('Could not remove attachment.', true);
            remove.disabled = false;
          }
        });
        caption.append(remove);
      }
      media.append(caption);
      attachments.append(media);
    }
    item.append(attachments);
  }
  if (!post.deleted && (
    post.authorId === account.id
    || selectedTopic?.authorId === account.id
    || canModeratePosts()
  )) {
    const actions = document.createElement('div');
    actions.className = 'post-actions';
    const edit = document.createElement('button');
    edit.className = 'quiet-link';
    edit.type = 'button';
    edit.textContent = 'Edit';
    edit.addEventListener('click', () => {
      setAttachmentRetryTarget(postEditForm, null);
      postEditForm.dataset.postId = post.id;
      postEditForm.dataset.updatedAt = post.updatedAt;
      postEditForm.elements.body.value = post.body;
      clearPendingAttachments(postEditForm.elements.body);
      editReasonControl.hidden = !canModeratePosts();
      postEditForm.elements.reason.required = canModeratePosts();
      postEditStatus.textContent = '';
      postEditDialog.showModal();
    });
    const remove = document.createElement('button');
    remove.className = 'quiet-link';
    remove.type = 'button';
    remove.textContent = 'Delete';
    remove.addEventListener('click', async () => {
      remove.disabled = true;
      const reason = canModeratePosts() ? 'Removed by moderator' : undefined;
      try {
        await request(`/api/posts/${post.id}`, {
          body: { reason },
          method: 'DELETE',
          useCsrf: true,
        });
        await openTopic(selectedTopic.id, topicPostsOffset);
      } catch {
        setForumStatus('Could not delete post.', true);
      } finally {
        remove.disabled = false;
      }
    });
    actions.append(edit, remove);
    item.append(actions);
  }
  return item;
}

async function uploadPendingAttachments(textarea, postId, setStatus) {
  const files = getPendingAttachments(textarea);
  const failed = [];
  for (const [index, file] of files.entries()) {
    setStatus(`Uploading attachment ${index + 1} of ${files.length}...`);
    try {
      await uploadPostAttachment(postId, file);
    } catch {
      failed.push(file);
    }
  }
  retainPendingAttachments(textarea, failed);
  return failed;
}

function setAttachmentRetryTarget(form, target) {
  const submit = form.querySelector('[type="submit"]');
  if (!submit.dataset.defaultLabel) {
    submit.dataset.defaultLabel = submit.textContent;
  }
  if (target) {
    attachmentRetryTargets.set(form, target);
  } else {
    attachmentRetryTargets.delete(form);
  }
  const retrying = Boolean(target);
  for (const input of form.querySelectorAll('input:not([type="file"])')) {
    input.disabled = retrying;
  }
  for (const textarea of form.querySelectorAll('textarea')) {
    textarea.readOnly = retrying;
  }
  for (const control of form.querySelectorAll('.markdown-toolbar button, .markdown-toolbar select')) {
    control.disabled = retrying;
  }
  submit.textContent = retrying ? 'Retry attachments' : submit.dataset.defaultLabel;
}

async function openTopic(topicId, offset = 0, focusPostId = null, loadedResult = null) {
  try {
    const replyRetryTarget = attachmentRetryTargets.get(replyForm);
    if (replyRetryTarget && replyRetryTarget.topicId !== String(topicId)) {
      setAttachmentRetryTarget(replyForm, null);
      replyForm.reset();
    }
    const result = loadedResult
      ?? await request(`/api/topics/${topicId}?limit=50&offset=${offset}`);
    selectedTopic = result.topic;
    topicPostsOffset = offset;
    topicPostsHasMore = result.hasMore;
    topicTitle.textContent = selectedTopic.title;
    postList.replaceChildren(...result.posts.map(createPostItem));
    topicList.hidden = true;
    topicsMore.hidden = true;
    searchResults.hidden = true;
    searchMore.hidden = true;
    topicView.hidden = false;
    newTopicButton.hidden = true;
    topicLock.hidden = !canModeratePosts();
    topicEdit.hidden = !canManageTopic();
    topicDelete.hidden = !canManageTopic();
    topicLock.textContent = selectedTopic.locked ? 'Unlock' : 'Lock';
    topicSubscribe.textContent = selectedTopic.subscribed ? 'Unsubscribe' : 'Subscribe';
    topicSubscribe.setAttribute('aria-pressed', String(selectedTopic.subscribed));
    postsPrevious.hidden = topicPostsOffset === 0;
    postsNext.hidden = !topicPostsHasMore;
    topicPagination.hidden = postsPrevious.hidden && postsNext.hidden;
    replyForm.hidden = selectedTopic.locked;
    setForumStatus('');
    if (focusPostId) {
      const focusedPost = postList.querySelector(`[data-post-id="${focusPostId}"]`);
      if (focusedPost) {
        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        focusedPost.classList.add('is-search-match');
        focusedPost.focus({ preventScroll: true });
        focusedPost.scrollIntoView({
          behavior: reducedMotion ? 'auto' : 'smooth',
          block: 'center',
        });
      }
    }
  } catch {
    setForumStatus('Could not load topic.', true);
  }
}

function setShoutboxStatus(message, state) {
  shoutboxStatus.textContent = message;
  shoutboxStatus.dataset.state = state;
  shoutboxStatus.hidden = !message;
  shoutboxPane.classList.toggle('is-inactive', state === 'disabled' || state === 'signed-out');
}

function renderShoutboxMute() {
  const muted = Boolean(account?.preferences.shoutboxMuted);
  const action = muted ? 'Unmute Shoutbox' : 'Mute Shoutbox';
  shoutboxMute.setAttribute('aria-pressed', String(muted));
  shoutboxMute.setAttribute('aria-label', action);
  shoutboxMute.title = action;
  shoutboxMuteIcon.textContent = String.fromCodePoint(muted ? 0x1f507 : 0x1f50a);
}

function createShout(shout) {
  const item = document.createElement('article');
  item.className = 'shout';
  item.dataset.shoutId = shout.id;
  const header = document.createElement('div');
  header.className = 'shout-meta';
  const authorGroup = document.createElement('div');
  authorGroup.className = 'shout-author';
  const avatar = document.createElement('span');
  avatar.className = 'account-avatar shout-avatar';
  renderAvatar(avatar, shout, shout.author);
  const author = document.createElement('strong');
  author.textContent = shout.author;
  const time = document.createElement('time');
  const createdAt = new Date(shout.createdAt);
  time.dateTime = createdAt.toISOString();
  time.textContent = createdAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const body = document.createElement('div');
  body.className = 'shout-body forum-post-body';
  renderMarkdown(body, shout.body, shout.mentionUsernames);
  authorGroup.append(createProfileLink(shout, [avatar, author]));
  header.append(authorGroup, time);
  item.append(header, body);
  if (shout.authorId === account.id || canModerateShouts()) {
    const actions = document.createElement('div');
    actions.className = 'shout-actions';
    const edit = document.createElement('button');
    edit.className = 'shout-action-button';
    edit.type = 'button';
    edit.setAttribute('aria-label', 'Edit Shoutbox message');
    edit.title = 'Edit';
    edit.textContent = String.fromCodePoint(0x270e);
    edit.addEventListener('click', () => {
      selectedShout = shout;
      const moderating = shout.authorId !== account.id;
      shoutEditForm.elements.body.value = shout.body;
      shoutEditForm.elements.reason.value = '';
      shoutEditForm.elements.reason.required = moderating;
      shoutEditReasonControl.hidden = !moderating;
      shoutEditDialog.showModal();
    });
    const remove = document.createElement('button');
    remove.className = 'shout-action-button shout-action-delete';
    remove.type = 'button';
    remove.setAttribute('aria-label', 'Delete Shoutbox message');
    remove.title = 'Delete';
    remove.textContent = String.fromCodePoint(0x1f5d1);
    remove.addEventListener('click', () => {
      const moderating = shout.authorId !== account.id;
      const reason = moderating
        ? window.prompt('Reason for deleting this Shoutbox message:')
        : '';
      if ((moderating && reason === null) || (!moderating && !window.confirm('Delete this Shoutbox message?'))) {
        return;
      }
      shoutboxSocket?.send(JSON.stringify({ id: shout.id, reason, type: 'delete' }));
    });
    actions.append(edit, remove);
    item.append(actions);
  }
  return item;
}

function renderShouts(shouts) {
  shoutboxLog.replaceChildren(...shouts.map(createShout));
  shoutboxLog.scrollTop = shoutboxLog.scrollHeight;
}

function upsertShout(shout) {
  const rendered = createShout(shout);
  const existing = shoutboxLog.querySelector(`[data-shout-id="${shout.id}"]`);
  if (existing) {
    existing.replaceWith(rendered);
  } else {
    shoutboxLog.append(rendered);
  }
  shoutboxLog.scrollTop = shoutboxLog.scrollHeight;
}

function applyShoutChange(change) {
  if (change.type === 'delete') {
    shoutboxLog.querySelector(`[data-shout-id="${change.id}"]`)?.remove();
  } else if (change.type === 'upsert' && change.shout) {
    upsertShout(change.shout);
  }
}

function setShoutboxCursor(cursor, reset = false) {
  if (
    typeof cursor === 'string'
    && /^\d+$/.test(cursor)
    && (reset || shoutboxCursor === null || BigInt(cursor) > BigInt(shoutboxCursor))
  ) {
    shoutboxCursor = cursor;
  }
}

function isNewShoutboxCursor(cursor) {
  return typeof cursor === 'string'
    && /^\d+$/.test(cursor)
    && (shoutboxCursor === null || BigInt(cursor) > BigInt(shoutboxCursor));
}

function scheduleShoutboxReconnect() {
  clearTimeout(shoutboxReconnectTimer);
  const delayMs = Math.min(30_000, 1000 * (2 ** Math.min(shoutboxReconnectAttempt, 5)));
  shoutboxReconnectAttempt += 1;
  shoutboxReconnectTimer = setTimeout(() => {
    shoutboxReconnectTimer = null;
    connectShoutbox();
  }, delayMs);
}

function connectShoutbox() {
  if (!account?.preferences.shoutboxEnabled) {
    setShoutboxStatus('Disabled', 'disabled');
    shoutboxInput.disabled = true;
    return;
  }
  if (
    shoutboxSocket?.readyState === WebSocket.CONNECTING
    || shoutboxSocket?.readyState === WebSocket.OPEN
  ) {
    return;
  }

  clearTimeout(shoutboxReconnectTimer);
  setShoutboxStatus('Connecting', 'connecting');
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const cursorQuery = shoutboxCursor === null
    ? ''
    : `?cursor=${encodeURIComponent(shoutboxCursor)}`;
  const activeSocket = new WebSocket(`${protocol}//${location.host}/shoutbox${cursorQuery}`);
  shoutboxSocket = activeSocket;
  activeSocket.addEventListener('message', (event) => {
    const message = JSON.parse(event.data);
    if (message.type === 'ready') {
      if (message.reset) {
        renderShouts(message.history ?? []);
        setShoutboxCursor(message.cursor, true);
      }
      for (const change of message.changes ?? []) {
        if (isNewShoutboxCursor(change.cursor)) {
          applyShoutChange(change);
          setShoutboxCursor(change.cursor);
        }
      }
      setShoutboxCursor(message.cursor);
      shoutboxReconnectAttempt = 0;
      shoutboxInput.disabled = account.shoutboxPostingMuted;
      setShoutboxStatus(
        account.shoutboxPostingMuted ? 'Muted' : 'Live',
        account.shoutboxPostingMuted ? 'muted' : 'ready',
      );
    } else if (message.type === 'shout') {
      const accepted = isNewShoutboxCursor(message.cursor);
      if (accepted) {
        upsertShout(message.shout);
        setShoutboxCursor(message.cursor);
      }
      if (shouldPlayShoutboxSound({
        accepted,
        accountId: account.id,
        muted: account.preferences.shoutboxMuted,
        shout: message.shout,
      })) {
        shoutboxSound.play();
      }
      void loadNotifications();
    } else if (message.type === 'shout_updated') {
      if (isNewShoutboxCursor(message.cursor)) {
        upsertShout(message.shout);
        setShoutboxCursor(message.cursor);
      }
      void loadNotifications();
    } else if (message.type === 'shout_deleted') {
      if (isNewShoutboxCursor(message.cursor)) {
        shoutboxLog.querySelector(`[data-shout-id="${message.id}"]`)?.remove();
        setShoutboxCursor(message.cursor);
      }
    } else if (message.type === 'error' && message.code === 'moderation_reason_required') {
      setShoutboxStatus('Reason required', 'error');
    } else if (message.type === 'error' && message.code === 'shout_unavailable') {
      setShoutboxStatus('Message unavailable', 'error');
    } else if (message.type === 'error' && message.code === 'shoutbox_posting_muted') {
      account.shoutboxPostingMuted = true;
      shoutboxInput.disabled = true;
      setShoutboxStatus('Muted', 'muted');
    } else if (
      message.type === 'error'
      && [
        'posting_flood_detected',
        'posting_rate_limited',
        'posting_slowdown',
        'shoutbox_rate_limited',
      ]
        .includes(message.code)
    ) {
      const retryAfterMs = Math.max(1000, Number(message.retryAfterMs) || 1000);
      shoutboxInput.disabled = true;
      setShoutboxStatus(`Wait ${Math.ceil(retryAfterMs / 1000)}s`, 'slowdown');
      clearTimeout(shoutboxCooldownTimer);
      shoutboxCooldownTimer = setTimeout(() => {
        if (shoutboxSocket?.readyState === WebSocket.OPEN) {
          shoutboxInput.disabled = false;
          setShoutboxStatus('Live', 'ready');
        }
      }, retryAfterMs);
    }
  });
  activeSocket.addEventListener('close', (event) => {
    if (shoutboxSocket !== activeSocket) {
      return;
    }
    shoutboxSocket = null;
    shoutboxInput.disabled = true;
    if (account?.preferences.shoutboxEnabled) {
      setShoutboxStatus('Offline', 'offline');
      if (event.code !== 1008) {
        scheduleShoutboxReconnect();
      }
    }
  });
  activeSocket.addEventListener('error', () => setShoutboxStatus('Offline', 'offline'));
}

function updateNotificationIndicators() {
  window.RWShell?.setUnreadCount(notificationUnreadCount);
}

function loadNotifications() {
  if (notificationLoadPromise) {
    return notificationLoadPromise;
  }
  notificationLoadPromise = (async () => {
    try {
      const result = await request('/api/notifications?limit=1');
      notificationUnreadCount = result.unreadCount;
      updateNotificationIndicators();
    } catch {
      updateNotificationIndicators();
    } finally {
      notificationLoadPromise = null;
    }
  })();
  return notificationLoadPromise;
}

setInterval(() => {
  if (account && document.visibilityState === 'visible') {
    void loadNotifications();
  }
}, 5_000);

document.addEventListener('visibilitychange', () => {
  if (account && document.visibilityState === 'visible') {
    void loadNotifications();
  }
});

shoutboxForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const body = shoutboxInput.value.trim();
  if (!body || shoutboxSocket?.readyState !== WebSocket.OPEN) {
    return;
  }
  shoutboxSocket.send(JSON.stringify({ body, type: 'shout' }));
  shoutboxForm.reset();
});

shoutEditForm.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!selectedShout || shoutboxSocket?.readyState !== WebSocket.OPEN) {
    return;
  }
  const body = Object.fromEntries(new FormData(event.currentTarget));
  shoutboxSocket.send(JSON.stringify({ id: selectedShout.id, type: 'edit', ...body }));
  selectedShout = null;
  shoutEditDialog.close();
});

shoutboxToggle.addEventListener('click', () => {
  const willOpen = shoutboxPane.hidden;
  shoutboxPane.hidden = !willOpen;
  shoutboxToggle.setAttribute('aria-expanded', String(willOpen));
  if (willOpen) {
    shoutboxLog.scrollTop = shoutboxLog.scrollHeight;
  }
});

shoutboxMute.addEventListener('click', async () => {
  if (!account) {
    return;
  }
  const unmuting = account.preferences.shoutboxMuted;
  const unlockPromise = shoutboxSound.unlock();
  shoutboxMute.disabled = true;
  try {
    const result = await request('/api/preferences', {
      body: { ...account.preferences, shoutboxMuted: !account.preferences.shoutboxMuted },
      method: 'PATCH',
      useCsrf: true,
    });
    account.preferences = result.preferences;
    renderShoutboxMute();
    if (unmuting && await unlockPromise) {
      shoutboxSound.play();
    }
  } catch {
    setShoutboxStatus('Mute not saved', 'error');
  } finally {
    shoutboxMute.disabled = false;
  }
});

newTopicButton.addEventListener('click', () => newTopicDialog.showModal());
topicsMore.addEventListener('click', () => loadTopics());
searchMore.addEventListener('click', () => {
  loadSearch().catch(() => setForumStatus('Could not load more results.', true));
});
forumSearchForm.addEventListener('submit', (event) => {
  event.preventDefault();
  searchQuery = forumSearchQuery.value.trim();
  window.RWShell.navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
});
forumSearchClear.addEventListener('click', () => {
  forumSearchForm.reset();
  searchQuery = '';
  searchOffset = 0;
  searchHasMore = false;
  searchResults.replaceChildren();
  searchResults.hidden = true;
  searchMore.hidden = true;
  forumSearchClear.hidden = true;
  window.RWShell.navigate(location.pathname === '/search' ? '/search' : '/');
});
topicBack.addEventListener('click', () => {
  window.RWShell.navigate(searchQuery ? `/search?q=${encodeURIComponent(searchQuery)}` : '/');
});
postsPrevious.addEventListener('click', () => openTopic(
  selectedTopic.id,
  Math.max(0, topicPostsOffset - 50),
));
postsNext.addEventListener('click', () => openTopic(selectedTopic.id, topicPostsOffset + 50));
topicLock.addEventListener('click', async () => {
  topicLock.disabled = true;
  try {
    const result = await request(`/api/topics/${selectedTopic.id}/lock`, {
      body: { locked: !selectedTopic.locked },
      method: 'PATCH',
      useCsrf: true,
    });
    selectedTopic = result.topic;
    topicLock.textContent = selectedTopic.locked ? 'Unlock' : 'Lock';
    replyForm.hidden = selectedTopic.locked;
  } catch {
    setForumStatus('Could not update topic lock.', true);
  } finally {
    topicLock.disabled = false;
  }
});
topicSubscribe.addEventListener('click', async () => {
  topicSubscribe.disabled = true;
  try {
    const result = await request(`/api/topics/${selectedTopic.id}/subscription`, {
      method: selectedTopic.subscribed ? 'DELETE' : 'PUT',
      useCsrf: true,
    });
    selectedTopic.subscribed = result.subscription.subscribed;
    topicSubscribe.textContent = selectedTopic.subscribed ? 'Unsubscribe' : 'Subscribe';
    topicSubscribe.setAttribute('aria-pressed', String(selectedTopic.subscribed));
  } catch {
    setForumStatus('Could not update topic subscription.', true);
  } finally {
    topicSubscribe.disabled = false;
  }
});
topicEdit.addEventListener('click', () => {
  topicEditForm.elements.title.value = selectedTopic.title;
  topicEditReasonControl.hidden = !canModeratePosts();
  topicEditForm.elements.reason.required = canModeratePosts();
  topicEditStatus.textContent = '';
  topicEditDialog.showModal();
});
topicDelete.addEventListener('click', async () => {
  if (!window.confirm('Delete this topic?')) {
    return;
  }
  topicDelete.disabled = true;
  try {
    await request(`/api/topics/${selectedTopic.id}`, {
      body: { reason: canModeratePosts() ? 'Removed by moderator' : undefined },
      method: 'DELETE',
      useCsrf: true,
    });
    selectedTopic = null;
    topicView.hidden = true;
    topicList.hidden = false;
    newTopicButton.hidden = false;
    await loadTopics(true);
  } catch {
    setForumStatus('Could not delete topic.', true);
  } finally {
    topicDelete.disabled = false;
  }
});

for (const closeButton of document.querySelectorAll('[data-close-dialog]')) {
  closeButton.addEventListener('click', () => closeButton.closest('dialog').close());
}

newTopicForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('[type="submit"]');
  const body = Object.fromEntries(new FormData(event.currentTarget));
  submit.disabled = true;
  try {
    const retryTarget = attachmentRetryTargets.get(event.currentTarget);
    const result = retryTarget
      ?? await request('/api/topics', { body, method: 'POST', useCsrf: true });
    const hadAttachments = getPendingAttachments(event.currentTarget.elements.body).length > 0;
    if (!retryTarget) {
      await openTopic(result.topic.id, 0, result.post.id, {
        hasMore: false,
        posts: [result.post],
        topic: { ...result.topic, subscribed: true },
      });
      newTopicDialog.close();
    }
    const failed = await uploadPendingAttachments(
      event.currentTarget.elements.body,
      result.post.id,
      (message) => setForumStatus(message),
    );
    if (failed.length) {
      setAttachmentRetryTarget(event.currentTarget, {
        ...result,
        topicId: String(result.topic.id),
      });
      setForumStatus(`Topic posted, but ${failed.length} attachment upload failed. Retry or remove it.`, true);
      return;
    }
    setAttachmentRetryTarget(event.currentTarget, null);
    event.currentTarget.reset();
    if (hadAttachments) {
      await openTopic(result.topic.id);
    }
  } catch (error) {
    setForumStatus(postingErrorMessage(error, 'Could not create topic.'), true);
  } finally {
    submit.disabled = false;
  }
});

replyForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('[type="submit"]');
  const body = Object.fromEntries(new FormData(event.currentTarget));
  submit.disabled = true;
  try {
    const retryTarget = attachmentRetryTargets.get(event.currentTarget);
    const result = retryTarget
      ?? await request(`/api/topics/${selectedTopic.id}/posts`, {
        body,
        method: 'POST',
        useCsrf: true,
      });
    const hadAttachments = getPendingAttachments(event.currentTarget.elements.body).length > 0;
    if (!retryTarget) {
      const rendered = createPostItem(result.post);
      postList.append(rendered);
      rendered.focus({ preventScroll: true });
      rendered.scrollIntoView({
        behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
          ? 'auto'
          : 'smooth',
        block: 'center',
      });
      setForumStatus('');
    }
    const failed = await uploadPendingAttachments(
      event.currentTarget.elements.body,
      result.post.id,
      (message) => setForumStatus(message),
    );
    if (failed.length) {
      setAttachmentRetryTarget(event.currentTarget, result);
      setForumStatus(`Reply posted, but ${failed.length} attachment upload failed. Retry or remove it.`, true);
      return;
    }
    setAttachmentRetryTarget(event.currentTarget, null);
    event.currentTarget.reset();
    if (hadAttachments) {
      await openTopic(selectedTopic.id, topicPostsOffset, result.post.id);
    }
  } catch (error) {
    setForumStatus(postingErrorMessage(error, 'Could not post reply.'), true);
  } finally {
    submit.disabled = false;
  }
});

postEditForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('[type="submit"]');
  const body = Object.fromEntries(new FormData(event.currentTarget));
  body.expectedUpdatedAt = event.currentTarget.dataset.updatedAt;
  submit.disabled = true;
  postEditStatus.textContent = '';
  try {
    const retryTarget = attachmentRetryTargets.get(event.currentTarget);
    const postId = retryTarget?.postId ?? event.currentTarget.dataset.postId;
    if (!retryTarget) {
      await request(`/api/posts/${postId}`, {
        body,
        method: 'PATCH',
        useCsrf: true,
      });
    }
    const failed = await uploadPendingAttachments(
      event.currentTarget.elements.body,
      postId,
      (message) => { postEditStatus.textContent = message; },
    );
    if (failed.length) {
      setAttachmentRetryTarget(event.currentTarget, { postId });
      postEditStatus.textContent = `Post updated, but ${failed.length} attachment upload failed. Retry or remove it.`;
      return;
    }
    setAttachmentRetryTarget(event.currentTarget, null);
    postEditDialog.close();
    await openTopic(selectedTopic.id);
  } catch (error) {
    postEditStatus.textContent = forumEditErrorMessage(error, 'Could not update post.');
  } finally {
    submit.disabled = false;
  }
});

topicEditForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('[type="submit"]');
  const body = Object.fromEntries(new FormData(event.currentTarget));
  body.expectedUpdatedAt = selectedTopic.updatedAt;
  submit.disabled = true;
  topicEditStatus.textContent = '';
  try {
    const result = await request(`/api/topics/${selectedTopic.id}`, {
      body,
      method: 'PATCH',
      useCsrf: true,
    });
    selectedTopic = result.topic;
    topicTitle.textContent = selectedTopic.title;
    topicEditDialog.close();
  } catch (error) {
    topicEditStatus.textContent = forumEditErrorMessage(error, 'Could not update topic.');
  } finally {
    submit.disabled = false;
  }
});

enhanceMarkdownEditors(document, { renderPreview: renderMarkdown });
enhanceMentionAutocompletes(document, { search: searchMentionUsernames });
enableShiftEnterSubmit(shoutboxInput);

async function applyForumRoute() {
  const url = new URL(location.href);
  const topicId = url.searchParams.get('topic');
  if (url.pathname === '/' && /^\d+$/.test(topicId ?? '')) {
    const offset = Number(url.searchParams.get('offset')) || 0;
    await openTopic(topicId, offset, url.searchParams.get('post'));
    return;
  }
  selectedTopic = null;
  topicView.hidden = true;
  newTopicButton.hidden = false;
  if (url.pathname === '/search') {
    topicList.hidden = true;
    topicsMore.hidden = true;
    const requestedQuery = url.searchParams.get('q')?.trim() ?? '';
    forumSearchQuery.value = requestedQuery;
    searchQuery = requestedQuery;
    if (requestedQuery.length >= 2) {
      await loadSearch(true);
    } else {
      searchResults.replaceChildren();
      searchResults.hidden = true;
      searchMore.hidden = true;
      forumSearchClear.hidden = true;
      setForumStatus('Enter a search above.');
    }
    forumSearchQuery.focus();
    return;
  }
  searchResults.hidden = true;
  searchMore.hidden = true;
  topicList.hidden = false;
  topicsMore.hidden = !topicsHasMore;
  setForumStatus('');
}

window.addEventListener('rw:routechange', () => {
  void applyForumRoute().catch(() => setForumStatus('Could not load this view.', true));
});

async function initialize() {
  await awaitPresence();
  let session;
  try {
    session = await loadSession();
  } catch {
    setShoutboxStatus('', 'signed-out');
    return;
  }
  account = session.account;
  window.RWTheme?.setColorScheme(account.preferences.colorScheme);
  window.RWTheme?.setPreference(account.preferences.theme);
  newTopicButton.disabled = false;
  shoutboxToggle.disabled = false;
  shoutboxMute.disabled = false;
  renderShoutboxMute();
  connectShoutbox();
  await Promise.all([
    loadNotifications(),
    loadTopics(true).catch(() => setForumStatus('Could not load topics.', true)),
  ]);
  await applyForumRoute();
}

initialize();