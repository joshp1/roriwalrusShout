import { randomUUID } from 'node:crypto';
import pg from 'pg';
import { verifyRegistrationInviteToken } from './registration-invites.js';

const { Pool } = pg;
const shoutSyncLockId = 1_847_672_020;
const serverDiagnosticLockId = 1_847_672_021;
const membershipDecisionMessages = new Map([
  ['active', 'Your membership is active.'],
  ['pending', 'Your membership status is pending.'],
  ['rejected', 'Your membership status is rejected.'],
  ['revoked', 'Your membership was revoked.'],
  ['suspended', 'Your membership was suspended.'],
]);

function escapeLikePattern(value) {
  return value.replaceAll('\\', '\\\\').replaceAll('%', '\\%').replaceAll('_', '\\_');
}

function deletedAccountIdentity(accountId) {
  const suffix = accountId.toLowerCase().replaceAll('-', '').slice(0, 24);
  const normalizedUsername = `deleted-${suffix}`;
  return {
    email: `${normalizedUsername}@deleted.invalid`,
    normalizedUsername,
    username: 'Deleted account',
  };
}

function mapAccount(row) {
  return {
    avatarContentType: row.avatar_content_type,
    avatarUpdatedAt: row.avatar_updated_at,
    colorScheme: row.color_scheme ?? 'green',
    createdAt: row.created_at,
    deletedAt: row.deleted_at,
    description: row.description ?? '',
    displayName: row.display_name,
    email: row.email,
    emailVerifiedAt: row.email_verified_at,
    forcePasswordChange: row.force_password_change ?? false,
    fontSize: row.font_size ?? 'standard',
    fontTypeface: row.font_typeface ?? 'verdana',
    forumPostingMuted: row.forum_posting_muted ?? false,
    id: row.id,
    membershipStatus: row.membership_status ?? 'active',
    passwordHash: row.password_hash,
    permissions: row.permissions ?? [],
    role: row.role,
    signature: row.signature ?? '',
    shoutboxEnabled: row.shoutbox_enabled,
    shoutboxHeightLines: row.shoutbox_height_lines ?? 18,
    shoutboxMuted: row.shoutbox_muted,
    shoutboxOrder: row.shoutbox_order ?? 'oldest-first',
    shoutboxPostingMuted: row.shoutbox_posting_muted ?? false,
    theme: row.theme,
    timestampColor: row.timestamp_color ?? 'default',
    timeZone: row.time_zone ?? 'local',
    username: row.username,
    usernameColor: row.username_color ?? 'default',
    usernameColorEffect: row.username_color_effect ?? 'none',
    usernameColorEffectsUnlocked: Boolean(row.username_color_effects_unlocked_at),
    visibleToRole: row.visible_to_role ?? null,
    slowdownMs: row.slowdown_ms ?? 0,
  };
}

function mapPublicProfile(row) {
  return {
    avatarContentType: row.avatar_updated_at ? row.avatar_content_type : null,
    avatarUrl: row.avatar_updated_at
      ? `/api/avatars/${row.id}?v=${new Date(row.avatar_updated_at).getTime()}`
      : null,
    createdAt: row.created_at,
    description: row.description,
    displayName: row.display_name,
    followedByViewer: Boolean(row.followed_by_viewer),
    followerCount: Number(row.follower_count ?? 0),
    id: row.id,
    location: row.location ?? '',
    signature: row.signature ?? '',
    specialStatus: ({ dev: 'Dev', owner: 'Owner' })[row.role] ?? null,
    timestampColor: row.timestamp_color ?? 'default',
    title: row.title ?? '',
    username: row.username,
    usernameColor: row.username_color,
    usernameColorEffect: row.username_color_effect ?? 'none',
    visibleToRole: row.visible_to_role ?? null,
  };
}

function mapNotification(row) {
  return {
    createdAt: row.created_at,
    href: row.href,
    id: row.id,
    message: row.message,
    readAt: row.read_at,
  };
}

function mapSession(row) {
  return {
    createdAt: row.created_at,
    current: Boolean(row.current),
    expiresAt: row.expires_at,
    id: row.id,
    lastSeenAt: row.last_seen_at,
    userAgent: row.user_agent ?? 'Unknown device',
  };
}

function mapManagedAccount(row) {
  return {
    createdAt: row.created_at,
    deletedAt: row.deleted_at,
    email: row.email,
    forcePasswordChange: row.force_password_change,
    forumPostingMuted: row.forum_posting_muted ?? false,
    hasAvatar: Boolean(row.avatar_updated_at),
    id: row.id,
    membershipStatus: row.membership_status,
    permissions: row.permissions ?? [],
    role: row.role,
    slowdownMs: row.slowdown_ms,
    shoutboxPostingMuted: row.shoutbox_posting_muted ?? false,
    updatedAt: row.updated_at,
    username: row.username,
  };
}

function mapAuditEvent(row) {
  return {
    action: row.action,
    actorId: row.actor_account_id,
    createdAt: row.created_at,
    details: row.details,
    id: String(row.id),
    reason: row.reason,
    targetId: row.target_account_id,
  };
}

function mapAuthenticationAuditEvent(row) {
  return {
    accountId: row.account_id,
    action: row.action,
    createdAt: row.created_at,
    details: row.details,
    id: String(row.id),
  };
}

function mapSiteSettings(row) {
  return {
    globalRegistrationTokenConfigured: row.global_registration_token_configured
      ?? row.global_registration_token_lookup_digest !== null,
    globalRegistrationTokenEnabled: row.global_registration_token_enabled,
    presenceCounterEnabled: row.presence_counter_enabled,
    shoutboxVisibilityCount: row.shoutbox_visibility_count,
    shoutboxVisibilityDays: Math.ceil(row.shoutbox_visibility_hours / 24),
    shoutboxVisibilityMode: row.shoutbox_visibility_mode,
    updatedAt: row.updated_at,
  };
}

function mapShout(row) {
  const mentionAccounts = (row.mention_accounts ?? []).map((account) => ({
    username: account.username,
    usernameColor: account.usernameColor ?? 'default',
    usernameColorEffect: account.usernameColorEffect ?? 'none',
  }));
  const viewerReactions = row.viewer_reactions
    ?? (row.viewer_reaction ? [row.viewer_reaction] : []);
  return {
    author: row.display_name,
    authorId: row.account_id,
    authorRole: row.role,
    authorUsername: row.username,
    avatarContentType: row.avatar_updated_at ? row.avatar_content_type : null,
    avatarUrl: row.avatar_updated_at
      ? `/api/avatars/${row.account_id}?v=${new Date(row.avatar_updated_at).getTime()}`
      : null,
    body: row.body,
    createdAt: row.created_at,
    id: String(row.id),
    mentionAccounts,
    mentionUsernames: row.mention_usernames
      ?? mentionAccounts.map((account) => account.username),
    reactions: row.reactions ?? [],
    syncCursor: row.sync_cursor == null ? null : String(row.sync_cursor),
    timestampColor: row.timestamp_color ?? 'default',
    updatedAt: row.updated_at ?? row.created_at,
    viewerReaction: viewerReactions[0] ?? null,
    viewerReactions,
    usernameColor: row.username_color,
    usernameColorEffect: row.username_color_effect ?? 'none',
    visibleToRole: row.visible_to_role ?? null,
  };
}

function mapShoutChange(row) {
  const cursor = String(row.sync_cursor);
  if (row.deleted_at) {
    return { cursor, id: String(row.id), type: 'delete' };
  }
  return { cursor, shout: mapShout(row), type: 'upsert' };
}

export function createDatabasePool(connectionString, { statementTimeout = 10_000 } = {}) {
  return new Pool({
    connectionString,
    max: 10,
    statement_timeout: statementTimeout,
  });
}

export function createDatabaseReadinessCheck(pool, { timeoutMs = 1000 } = {}) {
  return async function checkDatabaseReadiness() {
    const result = await pool.query({
      query_timeout: timeoutMs,
      text: 'SELECT 1 AS ready',
    });
    return result.rows[0]?.ready === 1;
  };
}

export function createRepository(pool, { dummyPasswordHash }) {
  async function withTransaction(operation) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await operation(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async function lockShoutSyncCursor(client) {
    await client.query('SELECT pg_advisory_xact_lock($1)', [shoutSyncLockId]);
  }

  async function prepareServerDiagnostic(client) {
    const lock = await client.query(
      'SELECT pg_try_advisory_xact_lock($1) AS locked',
      [serverDiagnosticLockId],
    );
    if (!lock.rows[0]?.locked) {
      return false;
    }
    await client.query("SET LOCAL statement_timeout = '2000ms'");
    return true;
  }

  async function insertServerDiagnosticAudit(client, {
    action,
    actorId,
    createdAt,
    details,
    reason,
  }) {
    await client.query(
      `INSERT INTO moderation_audit_events (
         actor_account_id, target_account_id, action, reason, details, created_at
       ) VALUES ($1, NULL, $2, $3, $4::jsonb, $5)`,
      [actorId, action, reason, JSON.stringify(details), createdAt],
    );
  }

  async function selectShoutHistoryPage(queryable, {
    before = null,
    historyCount = null,
    historyHours = null,
    limit,
    viewerId = null,
  }) {
    const result = await queryable.query(
      `WITH retained_shouts AS MATERIALIZED (
         SELECT shouts.id, shouts.created_at
         FROM shouts JOIN accounts ON accounts.id = shouts.account_id
         WHERE shouts.deleted_at IS NULL
           AND account_visible_to($2, accounts.id)
           AND ($2::uuid IS NULL OR shouts.created_at >= (
             SELECT viewers.created_at FROM accounts viewers WHERE viewers.id = $2
           ))
           AND ($3::integer IS NULL OR shouts.created_at >= now() - ($3 * interval '1 hour'))
         ORDER BY shouts.created_at DESC, shouts.id DESC
         LIMIT $4
       ), paged_shouts AS (
         SELECT id, created_at FROM retained_shouts
         WHERE $5::timestamptz IS NULL
           OR (created_at, id) < ($5::timestamptz, $6::bigint)
         ORDER BY created_at DESC, id DESC
         LIMIT $1
       )
       SELECT shouts.id, shouts.account_id, shouts.body, shouts.created_at,
        shouts.updated_at, shouts.sync_cursor,
        accounts.display_name, accounts.username, accounts.role, accounts.username_color,
        accounts.username_color_effect, accounts.timestamp_color, accounts.visible_to_role,
        accounts.avatar_content_type, accounts.avatar_updated_at,
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object(
            'username', mentioned.username,
            'usernameColor', mentioned.username_color,
            'usernameColorEffect', mentioned.username_color_effect
          ) ORDER BY mentioned.normalized_username)
          FROM shout_mentions
          JOIN accounts mentioned ON mentioned.id = shout_mentions.mentioned_account_id
          WHERE shout_mentions.shout_id = shouts.id
            AND mentioned.membership_status = 'active'
            AND mentioned.deleted_at IS NULL
            AND account_visible_to($2, mentioned.id)
        ), '[]'::jsonb) AS mention_accounts,
        COALESCE((
          SELECT jsonb_agg(
            jsonb_build_object('count', reaction_counts.count, 'reaction', reaction_counts.reaction)
            ORDER BY reaction_counts.reaction
          )
          FROM (
            SELECT reactions.reaction, count(*)::integer AS count
            FROM shout_reactions reactions
            JOIN accounts reacting_accounts ON reacting_accounts.id = reactions.account_id
            WHERE reactions.shout_id = shouts.id
              AND account_visible_to($2, reacting_accounts.id)
            GROUP BY reactions.reaction
          ) reaction_counts
        ), '[]'::jsonb) AS reactions,
        ARRAY(
          SELECT viewer_reactions.reaction
          FROM shout_reactions viewer_reactions
          WHERE viewer_reactions.shout_id = shouts.id
            AND viewer_reactions.account_id = $2
          ORDER BY viewer_reactions.reaction
        ) AS viewer_reactions
       FROM paged_shouts
       JOIN shouts ON shouts.id = paged_shouts.id
       JOIN accounts ON accounts.id = shouts.account_id
       ORDER BY paged_shouts.created_at DESC, paged_shouts.id DESC`,
      [
        limit + 1,
        viewerId,
        historyHours,
        historyCount,
        before?.createdAt ?? null,
        before?.id ?? null,
      ],
    );
    const hasMore = result.rows.length > limit;
    const rows = result.rows.slice(0, limit);
    const oldest = rows.at(-1);
    return {
      history: rows.reverse().map(mapShout),
      historyHasMore: hasMore,
      historyNextBefore: hasMore && oldest ? {
        createdAt: oldest.created_at.toISOString(),
        id: String(oldest.id),
      } : null,
    };
  }

  async function selectShouts(queryable, limit, viewerId = null, historyHours = null) {
    const page = await selectShoutHistoryPage(queryable, {
      historyHours,
      limit,
      viewerId,
    });
    return page.history;
  }

  async function selectShoutById(queryable, shoutId, viewerId) {
    const result = await queryable.query(
      `SELECT shouts.id, shouts.account_id, shouts.body, shouts.created_at,
        shouts.updated_at, shouts.sync_cursor,
        accounts.display_name, accounts.username, accounts.role, accounts.username_color,
        accounts.username_color_effect, accounts.timestamp_color, accounts.visible_to_role,
        accounts.avatar_content_type, accounts.avatar_updated_at,
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object(
            'username', mentioned.username,
            'usernameColor', mentioned.username_color,
            'usernameColorEffect', mentioned.username_color_effect
          ) ORDER BY mentioned.normalized_username)
          FROM shout_mentions
          JOIN accounts mentioned ON mentioned.id = shout_mentions.mentioned_account_id
          WHERE shout_mentions.shout_id = shouts.id
            AND mentioned.membership_status = 'active'
            AND mentioned.deleted_at IS NULL
            AND account_visible_to($2, mentioned.id)
        ), '[]'::jsonb) AS mention_accounts,
        COALESCE((
          SELECT jsonb_agg(
            jsonb_build_object('count', reaction_counts.count, 'reaction', reaction_counts.reaction)
            ORDER BY reaction_counts.reaction
          )
          FROM (
            SELECT reactions.reaction, count(*)::integer AS count
            FROM shout_reactions reactions
            JOIN accounts reacting_accounts ON reacting_accounts.id = reactions.account_id
            WHERE reactions.shout_id = shouts.id
              AND account_visible_to($2, reacting_accounts.id)
            GROUP BY reactions.reaction
          ) reaction_counts
        ), '[]'::jsonb) AS reactions,
        ARRAY(
          SELECT viewer_reactions.reaction
          FROM shout_reactions viewer_reactions
          WHERE viewer_reactions.shout_id = shouts.id
            AND viewer_reactions.account_id = $2
          ORDER BY viewer_reactions.reaction
        ) AS viewer_reactions
       FROM shouts JOIN accounts ON accounts.id = shouts.account_id
       WHERE shouts.id = $1 AND shouts.deleted_at IS NULL
         AND account_visible_to($2, accounts.id)`,
      [shoutId, viewerId],
    );
    return result.rows[0] ? mapShout(result.rows[0]) : null;
  }

  async function reconcileShoutMentions(client, actorId, shoutId, mentions) {
    await client.query(
      `DELETE FROM shout_mentions existing
       WHERE existing.shout_id = $3
         AND NOT EXISTS (
           SELECT 1 FROM accounts
           WHERE accounts.id = existing.mentioned_account_id
             AND accounts.normalized_username = ANY($1::text[])
             AND accounts.id <> $2
             AND accounts.membership_status = 'active'
             AND accounts.deleted_at IS NULL
             AND account_visible_to($2, accounts.id)
             AND account_visible_to(accounts.id, $2)
         )`,
      [mentions, actorId, shoutId],
    );
    const result = await client.query(
      `WITH resolved_mentions AS (
        SELECT id, normalized_username, username, username_color, username_color_effect
         FROM accounts
         WHERE normalized_username = ANY($1::text[])
           AND id <> $2
           AND membership_status = 'active'
           AND deleted_at IS NULL
           AND account_visible_to($2, id)
           AND account_visible_to(id, $2)
       ), inserted_mentions AS (
         INSERT INTO shout_mentions (shout_id, mentioned_account_id)
         SELECT $3, id FROM resolved_mentions
         ON CONFLICT DO NOTHING
         RETURNING mentioned_account_id
       ), inserted_notifications AS (
       INSERT INTO notifications (account_id, message, href)
       SELECT inserted_mentions.mentioned_account_id,
         actor.username || ' mentioned you in Shoutbox', '/'
       FROM inserted_mentions
       JOIN accounts actor ON actor.id = $2
       RETURNING account_id
       )
       SELECT resolved_mentions.username, resolved_mentions.username_color,
         resolved_mentions.username_color_effect
       FROM resolved_mentions
       LEFT JOIN inserted_notifications
         ON inserted_notifications.account_id = resolved_mentions.id
       ORDER BY resolved_mentions.normalized_username`,
      [mentions, actorId, shoutId],
    );
    return result.rows.map((row) => ({
      username: row.username,
      usernameColor: row.username_color,
      usernameColorEffect: row.username_color_effect ?? 'none',
    }));
  }

  return {
    dummyPasswordHash,
    async clearLoginBackoff(subjectDigest) {
      await pool.query(
        'DELETE FROM login_backoffs WHERE subject_digest = $1',
        [subjectDigest],
      );
    },
    async getAvatar(viewerId, accountId) {
      const result = await pool.query(
        `SELECT avatar_content_type, avatar_data FROM accounts
         WHERE id = $2
           AND membership_status = 'active'
           AND deleted_at IS NULL
           AND account_visible_to($1, id)`,
        [viewerId, accountId],
      );
      const row = result.rows[0];
      return row?.avatar_data
        ? { contentType: row.avatar_content_type, data: row.avatar_data }
        : null;
    },
    async consumeRateLimit({ action, limit, now, subjectDigest, windowMs }) {
      const result = await pool.query(
        `INSERT INTO auth_rate_limits (action, subject_digest, window_started_at, attempt_count)
         VALUES ($1, $2, $3, 1)
         ON CONFLICT (action, subject_digest) DO UPDATE SET
           attempt_count = CASE
             WHEN auth_rate_limits.window_started_at <= $3 - ($4 * interval '1 millisecond') THEN 1
             ELSE auth_rate_limits.attempt_count + 1
           END,
           window_started_at = CASE
             WHEN auth_rate_limits.window_started_at <= $3 - ($4 * interval '1 millisecond') THEN $3
             ELSE auth_rate_limits.window_started_at
           END
         RETURNING attempt_count`,
        [action, subjectDigest, now, windowMs],
      );
      return result.rows[0].attempt_count <= limit;
    },
    async getLoginBackoff(subjectDigest, now) {
      const result = await pool.query(
        `SELECT GREATEST(
           0,
           CEIL(EXTRACT(EPOCH FROM (blocked_until - $2)) * 1000)
         )::bigint AS retry_after_ms
         FROM login_backoffs
         WHERE subject_digest = $1`,
        [subjectDigest, now],
      );
      return Number(result.rows[0]?.retry_after_ms ?? 0);
    },
    async recordLoginFailure({ accountId, now, resetAfterMs, subjectDigest }) {
      const result = await pool.query(
        `WITH updated AS (
           INSERT INTO login_backoffs (
             subject_digest, failure_count, last_failed_at, blocked_until
           ) VALUES ($1, 1, $2, $2)
           ON CONFLICT (subject_digest) DO UPDATE SET
             failure_count = CASE
               WHEN login_backoffs.last_failed_at <= $2 - ($3 * interval '1 millisecond') THEN 1
               ELSE LEAST(login_backoffs.failure_count + 1, 13)
             END,
             last_failed_at = $2,
             blocked_until = $2 + (
               CASE
                 WHEN login_backoffs.last_failed_at <= $2 - ($3 * interval '1 millisecond')
                   OR login_backoffs.failure_count < 2 THEN 0
                 ELSE LEAST(
                   900000,
                   1000 * POWER(2, LEAST(login_backoffs.failure_count + 1, 13) - 3)
                 )
               END * interval '1 millisecond'
             )
           RETURNING blocked_until
         ), audit_event AS (
           INSERT INTO authentication_audit_events (account_id, action)
           VALUES ($4, 'auth.login.credentials_rejected')
           RETURNING id
         )
         SELECT GREATEST(
           0,
           CEIL(EXTRACT(EPOCH FROM (blocked_until - $2)) * 1000)
         )::bigint AS retry_after_ms
         FROM updated CROSS JOIN audit_event`,
        [subjectDigest, now, resetAfterMs, accountId],
      );
      return Number(result.rows[0]?.retry_after_ms ?? 0);
    },
    async consumePasswordResetToken({ passwordHash, tokenDigest, usedAt }) {
      return withTransaction(async (client) => {
        const tokenResult = await client.query(
          `UPDATE password_reset_tokens
           SET consumed_at = $2
           WHERE token_digest = $1 AND consumed_at IS NULL AND expires_at > $2
           RETURNING account_id`,
          [tokenDigest, usedAt],
        );
        const accountId = tokenResult.rows[0]?.account_id;
        if (!accountId) {
          return false;
        }

        await client.query(
          `UPDATE accounts
           SET password_hash = $2, force_password_change = false, updated_at = $3
           WHERE id = $1`,
          [accountId, passwordHash, usedAt],
        );
        await client.query(
          `UPDATE password_reset_tokens SET consumed_at = $2
           WHERE account_id = $1 AND consumed_at IS NULL`,
          [accountId, usedAt],
        );
        await client.query(
          `UPDATE sessions SET revoked_at = $2 WHERE account_id = $1 AND revoked_at IS NULL`,
          [accountId, usedAt],
        );
        await client.query(
          `INSERT INTO notifications (account_id, message, href)
           VALUES ($1, 'Your password was changed. Sign in again on your other devices.', '/account#sign-in')`,
          [accountId],
        );
        await client.query(
          `INSERT INTO authentication_audit_events (account_id, action)
           VALUES ($1, 'auth.password_reset.completed')`,
          [accountId],
        );
        return true;
      });
    },
    async consumeVerificationToken(tokenDigest, usedAt) {
      return withTransaction(async (client) => {
        const tokenResult = await client.query(
          `UPDATE email_verification_tokens
           SET consumed_at = $2
           WHERE token_digest = $1 AND consumed_at IS NULL AND expires_at > $2
             AND EXISTS (
               SELECT 1 FROM accounts
               WHERE accounts.id = email_verification_tokens.account_id
                 AND accounts.membership_status = 'pending'
                 AND accounts.deleted_at IS NULL
             )
           RETURNING account_id`,
          [tokenDigest, usedAt],
        );
        const accountId = tokenResult.rows[0]?.account_id;
        if (!accountId) {
          return false;
        }

        const accountResult = await client.query(
          `UPDATE accounts
           SET email_verified_at = COALESCE(email_verified_at, $2),
             membership_status = 'active',
             updated_at = $2
           WHERE id = $1 AND membership_status = 'pending' AND deleted_at IS NULL
           RETURNING email`,
          [accountId, usedAt],
        );
        if (!accountResult.rows[0]) {
          return false;
        }
        await client.query(
          `INSERT INTO notifications (account_id, message, href)
           VALUES ($1, 'Your email is verified. Welcome to roriwalrus.', '/profile?tab=settings')`,
          [accountId],
        );
        await client.query(
          `INSERT INTO authentication_audit_events (account_id, action)
           VALUES ($1, 'auth.email.verified')`,
          [accountId],
        );
        return { email: accountResult.rows[0].email };
      });
    },
    async createAccount({
      email,
      inviteToken,
      inviteTokenDigest,
      normalizedUsername,
      passwordHash,
      registeredAt,
      username,
    }) {
      return withTransaction(async (client) => {
        const globalTokenResult = await client.query(
          `SELECT global_registration_token_salt, global_registration_token_verifier
           FROM site_settings
           WHERE singleton = true
             AND global_registration_token_enabled = true
             AND global_registration_token_lookup_digest = $1
           FOR SHARE`,
          [inviteTokenDigest],
        );
        const globalToken = globalTokenResult.rows[0];
        const globalTokenValid = Boolean(globalToken) && await verifyRegistrationInviteToken(
          inviteToken,
          globalToken.global_registration_token_salt,
          globalToken.global_registration_token_verifier,
        );
        if (globalToken && !globalTokenValid) {
          return { account: null, created: false, inviteValid: false };
        }
        const inviteResult = globalTokenValid ? { rows: [] } : await client.query(
          `SELECT id, issuer_account_id, issuer_kind, token_salt, token_verifier
           FROM registration_invites
           WHERE token_lookup_digest = $1 AND issuer_kind = 'account' AND redeemed_at IS NULL
           FOR UPDATE`,
          [inviteTokenDigest],
        );
        const invite = inviteResult.rows[0];
        if (!globalTokenValid && (!invite || !await verifyRegistrationInviteToken(
          inviteToken,
          invite.token_salt,
          invite.token_verifier,
        ))) {
          return { account: null, created: false, inviteValid: false };
        }

        const reservationResult = await client.query(
          `INSERT INTO username_reservations (normalized_username)
           VALUES ($1) ON CONFLICT DO NOTHING RETURNING normalized_username`,
          [normalizedUsername],
        );
        if (!reservationResult.rows[0]) {
          const existingResult = await client.query(
            `SELECT * FROM accounts WHERE normalized_email = $1`,
            [email],
          );
          return {
            account: existingResult.rows[0] ? mapAccount(existingResult.rows[0]) : null,
            created: false,
            inviteValid: true,
          };
        }

        const result = await client.query(
          `INSERT INTO accounts (
             id, email, normalized_email, username, normalized_username, display_name, password_hash
           )
           VALUES ($1, $2, $2, $3, $4, $3, $5)
           ON CONFLICT DO NOTHING
           RETURNING *`,
          [randomUUID(), email, username, normalizedUsername, passwordHash],
        );
        if (result.rows[0]) {
          const account = mapAccount(result.rows[0]);
          if (globalTokenValid) {
            await client.query(
              `INSERT INTO authentication_audit_events (account_id, action, created_at)
               VALUES ($1, 'auth.registration_global_token.used', $2)`,
              [account.id, registeredAt],
            );
          } else {
            await client.query(
              `UPDATE registration_invites
               SET redeemed_by_account_id = $2, redeemed_at = $3
               WHERE id = $1 AND redeemed_at IS NULL`,
              [invite.id, account.id, registeredAt],
            );
            await client.query(
              `INSERT INTO authentication_audit_events (
                 account_id, action, details, created_at
               ) VALUES ($1, 'auth.registration_invite.redeemed', $2::jsonb, $3)`,
              [account.id, JSON.stringify({
                inviteId: String(invite.id),
                issuerAccountId: invite.issuer_account_id,
                issuerKind: invite.issuer_kind,
              }), registeredAt],
            );
          }
          return { account, created: true, inviteValid: true };
        }

        await client.query(
          `DELETE FROM username_reservations WHERE normalized_username = $1`,
          [normalizedUsername],
        );
        const existingResult = await client.query(
          `SELECT * FROM accounts WHERE normalized_email = $1`,
          [email],
        );
        return {
          account: existingResult.rows[0] ? mapAccount(existingResult.rows[0]) : null,
          created: false,
          inviteValid: true,
        };
      });
    },
    async createRegistrationInvite({ actorId, createdAt, tokenLookupDigest, tokenSalt, tokenVerifier }) {
      return withTransaction(async (client) => {
        const result = await client.query(
          `INSERT INTO registration_invites (
             token_lookup_digest, token_salt, token_verifier,
             issuer_kind, issuer_account_id, created_at
           ) VALUES ($1, $2, $3, 'account', $4, $5)
           RETURNING id, created_at`,
          [tokenLookupDigest, tokenSalt, tokenVerifier, actorId, createdAt],
        );
        const invite = result.rows[0];
        await client.query(
          `INSERT INTO authentication_audit_events (
             account_id, action, details, created_at
           ) VALUES ($1, 'auth.registration_invite.issued', $2::jsonb, $3)`,
          [actorId, JSON.stringify({ inviteId: String(invite.id), issuerKind: 'account' }), createdAt],
        );
        return { createdAt: invite.created_at, id: String(invite.id) };
      });
    },
    async createSession({ accountId, csrfDigest, expiresAt, id, persistent, tokenDigest, userAgent }) {
      await withTransaction(async (client) => {
        await client.query(
          `INSERT INTO sessions (
             token_digest, csrf_digest, account_id, expires_at, id, last_seen_at, user_agent
           ) VALUES ($1, $2, $3, $4, $5, now(), $6)`,
          [tokenDigest, csrfDigest, accountId, expiresAt, id, userAgent],
        );
        await client.query(
          `INSERT INTO authentication_audit_events (
             account_id, session_id, action, details
           ) VALUES ($1, $2, 'auth.login.succeeded', $3::jsonb)`,
          [accountId, id, JSON.stringify({ persistent: Boolean(persistent) })],
        );
      });
    },
    async createShout(accountId, body, mentions) {
      return withTransaction(async (client) => {
        await lockShoutSyncCursor(client);
        const result = await client.query(
          `WITH inserted AS (
             INSERT INTO shouts (account_id, body) VALUES ($1, $2)
             RETURNING id, account_id, body, created_at, updated_at, sync_cursor
           )
            SELECT inserted.id, inserted.account_id, inserted.body, inserted.created_at,
              inserted.updated_at, inserted.sync_cursor,
              accounts.display_name, accounts.username, accounts.role, accounts.username_color,
              accounts.username_color_effect, accounts.timestamp_color,
              accounts.visible_to_role,
              accounts.avatar_content_type, accounts.avatar_updated_at
           FROM inserted JOIN accounts ON accounts.id = inserted.account_id`,
          [accountId, body],
        );
        const mentionAccounts = await reconcileShoutMentions(
          client,
          accountId,
          result.rows[0].id,
          mentions,
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $1, 'shout.create', 'Shout created',
             jsonb_build_object('shoutId', $2::text))`,
          [accountId, result.rows[0].id],
        );
        return mapShout({ ...result.rows[0], mention_accounts: mentionAccounts });
      });
    },
    async deleteShout(actorId, shoutId, canModerate, reason) {
      return withTransaction(async (client) => {
        await lockShoutSyncCursor(client);
        const currentResult = await client.query(
          `SELECT shouts.*, accounts.display_name, accounts.username, accounts.role,
            accounts.username_color, accounts.username_color_effect, accounts.timestamp_color,
            accounts.visible_to_role,
            accounts.avatar_content_type, accounts.avatar_updated_at
           FROM shouts JOIN accounts ON accounts.id = shouts.account_id
           WHERE shouts.id = $1 AND shouts.deleted_at IS NULL
             AND shouts.created_at >= (
               SELECT viewers.created_at FROM accounts viewers WHERE viewers.id = $2
             )
             AND account_visible_to($2, accounts.id)
           FOR UPDATE OF shouts`,
          [shoutId, actorId],
        );
        const current = currentResult.rows[0];
        const ownsShout = current?.account_id === actorId;
        if (!current || (!ownsShout && !canModerate)) {
          return null;
        }
        if (!ownsShout && (typeof reason !== 'string' || reason.length < 3 || reason.length > 200)) {
          return { reasonRequired: true };
        }
        await client.query(
          `INSERT INTO shout_revisions (shout_id, actor_account_id, action, body, reason)
           VALUES ($1, $2, 'delete', $3, $4)`,
          [shoutId, actorId, current.body, ownsShout ? null : reason],
        );
        const deleted = await client.query(
          `UPDATE shouts SET deleted_at = now(), updated_at = now(),
             sync_cursor = nextval('shout_sync_cursor_sequence')
           WHERE id = $1 RETURNING sync_cursor`,
          [shoutId],
        );
        await client.query('DELETE FROM shout_mentions WHERE shout_id = $1', [shoutId]);
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'shout.delete', $3, $4::jsonb)`,
          [
            actorId,
            current.account_id,
            ownsShout ? 'Shout deleted' : reason,
            JSON.stringify({ shoutId: String(shoutId) }),
          ],
        );
        return {
          createdAt: current.created_at,
          cursor: String(deleted.rows[0].sync_cursor),
          id: String(shoutId),
          visibleToRole: current.visible_to_role ?? null,
        };
      });
    },
    async updateShout(actorId, shoutId, body, mentions, canModerate, reason) {
      return withTransaction(async (client) => {
        await lockShoutSyncCursor(client);
        const currentResult = await client.query(
          `SELECT shouts.*, accounts.display_name, accounts.username, accounts.role,
            accounts.username_color, accounts.username_color_effect, accounts.timestamp_color,
            accounts.visible_to_role,
            accounts.avatar_content_type, accounts.avatar_updated_at
           FROM shouts JOIN accounts ON accounts.id = shouts.account_id
           WHERE shouts.id = $1 AND shouts.deleted_at IS NULL
             AND shouts.created_at >= (
               SELECT viewers.created_at FROM accounts viewers WHERE viewers.id = $2
             )
             AND account_visible_to($2, accounts.id)
           FOR UPDATE OF shouts`,
          [shoutId, actorId],
        );
        const current = currentResult.rows[0];
        const ownsShout = current?.account_id === actorId;
        if (!current || (!ownsShout && !canModerate)) {
          return null;
        }
        if (!ownsShout && (typeof reason !== 'string' || reason.length < 3 || reason.length > 200)) {
          return { reasonRequired: true };
        }
        await client.query(
          `INSERT INTO shout_revisions (shout_id, actor_account_id, action, body, reason)
           VALUES ($1, $2, 'edit', $3, $4)`,
          [shoutId, actorId, current.body, ownsShout ? null : reason],
        );
        const updated = await client.query(
          `UPDATE shouts SET body = $2, updated_at = now(),
             sync_cursor = nextval('shout_sync_cursor_sequence')
           WHERE id = $1 RETURNING sync_cursor, updated_at`,
          [shoutId, body],
        );
        const mentionAccounts = await reconcileShoutMentions(
          client,
          current.account_id,
          shoutId,
          mentions,
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'shout.edit', $3, $4::jsonb)`,
          [
            actorId,
            current.account_id,
            ownsShout ? 'Shout edited' : reason,
            JSON.stringify({ shoutId: String(shoutId) }),
          ],
        );
        return mapShout({
          ...current,
          body,
          mention_accounts: mentionAccounts,
          sync_cursor: updated.rows[0].sync_cursor,
          updated_at: updated.rows[0].updated_at,
        });
      });
    },
    async toggleShoutReaction(accountId, shoutId, reaction) {
      return withTransaction(async (client) => {
        await lockShoutSyncCursor(client);
        const shoutResult = await client.query(
          `SELECT shouts.id, reacting_accounts.visible_to_role AS actor_visible_to_role
           FROM shouts
           JOIN accounts ON accounts.id = shouts.account_id
           JOIN accounts reacting_accounts ON reacting_accounts.id = $2
           WHERE shouts.id = $1 AND shouts.deleted_at IS NULL
             AND shouts.created_at >= (
               SELECT viewers.created_at FROM accounts viewers WHERE viewers.id = $2
             )
             AND account_visible_to($2, accounts.id)
           FOR UPDATE`,
          [shoutId, accountId],
        );
        if (!shoutResult.rows[0]) {
          return null;
        }
        const removed = await client.query(
          `DELETE FROM shout_reactions
           WHERE shout_id = $1 AND account_id = $2 AND reaction = $3
           RETURNING reaction`,
          [shoutId, accountId, reaction],
        );
        if (!removed.rows[0]) {
          await client.query(
            `INSERT INTO shout_reactions (shout_id, account_id, reaction)
             VALUES ($1, $2, $3)
             ON CONFLICT DO NOTHING`,
            [shoutId, accountId, reaction],
          );
        }
        await client.query(
          `UPDATE shouts
           SET sync_cursor = nextval('shout_sync_cursor_sequence')
           WHERE id = $1`,
          [shoutId],
        );
        const shout = await selectShoutById(client, shoutId, accountId);
        return shout ? {
          ...shout,
          reactionVisibleToRole: shoutResult.rows[0].actor_visible_to_role ?? null,
        } : null;
      });
    },
    async listShoutReactions(viewerId, shoutId, reaction, limit, offset) {
      const available = await pool.query(
        `SELECT 1 FROM shouts
         JOIN accounts authors ON authors.id = shouts.account_id
         WHERE shouts.id = $1 AND shouts.deleted_at IS NULL
           AND shouts.created_at >= (
             SELECT viewers.created_at FROM accounts viewers WHERE viewers.id = $2
           )
           AND account_visible_to($2, authors.id)`,
        [shoutId, viewerId],
      );
      if (!available.rows[0]) {
        return null;
      }
      const result = await pool.query(
        `SELECT reactions.reaction, accounts.display_name, accounts.username,
          accounts.username_color, accounts.username_color_effect
         FROM shout_reactions reactions
         JOIN accounts ON accounts.id = reactions.account_id
         WHERE reactions.shout_id = $1
           AND ($2::text IS NULL OR reactions.reaction = $2)
           AND accounts.membership_status = 'active'
           AND accounts.deleted_at IS NULL
            AND account_visible_to($5, accounts.id)
         ORDER BY reactions.reaction, accounts.normalized_username, accounts.id
         LIMIT $3 OFFSET $4`,
          [shoutId, reaction, limit, offset, viewerId],
      );
      return result.rows.map((row) => ({
        displayName: row.display_name,
        reaction: row.reaction,
        username: row.username,
        usernameColor: row.username_color,
        usernameColorEffect: row.username_color_effect ?? 'none',
      }));
    },
    async countUnreadNotifications(accountId) {
      const result = await pool.query(
        `SELECT count(*)::integer AS unread_count
         FROM notifications WHERE account_id = $1 AND read_at IS NULL`,
        [accountId],
      );
      return result.rows[0].unread_count;
    },
    async findAccountByEmail(email) {
      const result = await pool.query(
        `SELECT * FROM accounts WHERE normalized_email = $1`,
        [email],
      );
      return result.rows[0] ? mapAccount(result.rows[0]) : null;
    },
    async findAccountByUsername(username) {
      const result = await pool.query(
        `SELECT accounts.*, COALESCE(grants.permissions, ARRAY[]::text[]) AS permissions
         FROM accounts
         LEFT JOIN LATERAL (
           SELECT array_agg(permission ORDER BY permission) AS permissions
           FROM moderator_grants WHERE account_id = accounts.id
         ) grants ON true
         WHERE normalized_username = $1`,
        [username],
      );
      return result.rows[0] ? mapAccount(result.rows[0]) : null;
    },
    async findManagedAccount(viewerId, accountId) {
      const result = await pool.query(
        `SELECT accounts.*, COALESCE(grants.permissions, ARRAY[]::text[]) AS permissions
         FROM accounts
         LEFT JOIN LATERAL (
           SELECT array_agg(permission ORDER BY permission) AS permissions
           FROM moderator_grants WHERE account_id = accounts.id
         ) grants ON true
         WHERE accounts.id = $2
           AND account_visible_to($1, accounts.id)`,
        [viewerId, accountId],
      );
      return result.rows[0] ? mapManagedAccount(result.rows[0]) : null;
    },
    async findPublicProfileByUsername(username, viewerId) {
      const result = await pool.query(
        `SELECT accounts.id, accounts.username, accounts.display_name, accounts.description,
          accounts.location, accounts.signature, accounts.title,
          accounts.role,
          accounts.timestamp_color, accounts.username_color, accounts.username_color_effect,
          accounts.avatar_content_type, accounts.avatar_updated_at,
          accounts.created_at,
          count(follows.follower_account_id)::integer AS follower_count,
          EXISTS (
            SELECT 1 FROM account_follows viewer_follow
            WHERE viewer_follow.follower_account_id = $2
              AND viewer_follow.followed_account_id = accounts.id
          ) AS followed_by_viewer
         FROM accounts
         LEFT JOIN account_follows follows ON follows.followed_account_id = accounts.id
           AND account_visible_to($2, follows.follower_account_id)
         WHERE accounts.normalized_username = $1
           AND accounts.membership_status = 'active'
           AND accounts.deleted_at IS NULL
           AND account_visible_to($2, accounts.id)
         GROUP BY accounts.id`,
        [username, viewerId],
      );
      return result.rows[0] ? mapPublicProfile(result.rows[0]) : null;
    },
    async searchActiveUsernamesByPrefix(prefix, viewerId, limit) {
      const result = await pool.query(
        `SELECT username FROM accounts
         WHERE normalized_username COLLATE "C" LIKE $1 ESCAPE E'\\\\'
           AND id <> $2
           AND membership_status = 'active'
           AND deleted_at IS NULL
           AND account_visible_to($2, id)
         ORDER BY normalized_username COLLATE "C", id
         LIMIT $3`,
        [`${escapeLikePattern(prefix)}%`, viewerId, limit],
      );
      return result.rows.map(({ username }) => username);
    },
    async findSession(tokenDigest, now, idleTimeoutMs) {
      const result = await pool.query(
        `SELECT sessions.id AS session_id, sessions.csrf_digest, sessions.last_seen_at,
          accounts.*,
          COALESCE(grants.permissions, ARRAY[]::text[]) AS permissions
         FROM sessions JOIN accounts ON accounts.id = sessions.account_id
         LEFT JOIN LATERAL (
           SELECT array_agg(permission ORDER BY permission) AS permissions
           FROM moderator_grants WHERE account_id = accounts.id
         ) grants ON true
         WHERE sessions.token_digest = $1
           AND sessions.revoked_at IS NULL
           AND sessions.expires_at > $2
           AND sessions.last_seen_at > $2 - ($3 * interval '1 millisecond')
           AND accounts.membership_status = 'active'
           AND accounts.force_password_change = false`,
        [tokenDigest, now, idleTimeoutMs],
      );
      const row = result.rows[0];
      if (!row) {
        return null;
      }
      if (now.getTime() - new Date(row.last_seen_at).getTime() >= 5 * 60 * 1000) {
        await pool.query(
          `UPDATE sessions SET last_seen_at = $2
           WHERE token_digest = $1 AND revoked_at IS NULL`,
          [tokenDigest, now],
        );
      }
      return { account: mapAccount(row), csrfDigest: row.csrf_digest, id: row.session_id };
    },
    async listSessions(accountId, currentSessionId, now, idleTimeoutMs) {
      const result = await pool.query(
        `SELECT id, created_at, last_seen_at, expires_at, user_agent, id = $2 AS current
         FROM sessions
         WHERE account_id = $1
           AND revoked_at IS NULL
           AND expires_at > $3
           AND last_seen_at > $3 - ($4 * interval '1 millisecond')
         ORDER BY current DESC, last_seen_at DESC, id`,
        [accountId, currentSessionId, now, idleTimeoutMs],
      );
      return result.rows.map(mapSession);
    },
    async listNotifications(accountId, limit, offset = 0) {
      const result = await pool.query(
        `SELECT id, message, href, read_at, created_at
         FROM notifications WHERE account_id = $1
         ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
        [accountId, limit, offset],
      );
      return result.rows.map(mapNotification);
    },
    async listAccountAudit(viewerId, accountId, limit, offset) {
      const result = await pool.query(
        `SELECT id, actor_account_id, target_account_id, action, reason, details, created_at
         FROM moderation_audit_events
         WHERE target_account_id = $2
           AND account_visible_to($1, target_account_id)
           AND (
             actor_account_id IS NULL
             OR account_visible_to($1, actor_account_id)
           )
         ORDER BY created_at DESC, id DESC LIMIT $3 OFFSET $4`,
        [viewerId, accountId, limit, offset],
      );
      return result.rows.map(mapAuditEvent);
    },
    async listAuthenticationAudit(viewerId, limit, offset) {
      const result = await pool.query(
        `SELECT id, account_id, action, details, created_at
         FROM authentication_audit_events
         WHERE account_id IS NULL OR account_visible_to($1, account_id)
         ORDER BY id DESC LIMIT $2 OFFSET $3`,
        [viewerId, limit, offset],
      );
      return result.rows.map(mapAuthenticationAuditEvent);
    },
    async listManagedAccounts(viewerId, limit, offset) {
      const result = await pool.query(
        `SELECT accounts.*, COALESCE(grants.permissions, ARRAY[]::text[]) AS permissions
         FROM accounts
         LEFT JOIN LATERAL (
           SELECT array_agg(permission ORDER BY permission) AS permissions
           FROM moderator_grants WHERE account_id = accounts.id
         ) grants ON true
         WHERE account_visible_to($1, accounts.id)
         ORDER BY accounts.created_at DESC, accounts.id DESC LIMIT $2 OFFSET $3`,
        [viewerId, limit, offset],
      );
      return result.rows.map(mapManagedAccount);
    },
    async countManagedAccounts(viewerId) {
      const result = await pool.query(
        `SELECT count(*)::integer AS count
         FROM accounts
         WHERE accounts.deleted_at IS NULL
           AND account_visible_to($1, accounts.id)`,
        [viewerId],
      );
      return result.rows[0].count;
    },
    async clearAccountAvatar({ actorId, expectedUpdatedAt, reason, targetId, updatedAt }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT * FROM accounts WHERE id = $1 FOR UPDATE`,
          [targetId],
        );
        const current = currentResult.rows[0];
        if (!current || new Date(current.updated_at).getTime() !== expectedUpdatedAt.getTime()) {
          return { account: null };
        }

        await client.query(
          `UPDATE accounts
           SET avatar_content_type = NULL, avatar_data = NULL, avatar_updated_at = NULL,
             updated_at = $2
           WHERE id = $1`,
          [targetId, updatedAt],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'account.avatar.remove', $3, $4::jsonb)`,
          [actorId, targetId, reason, JSON.stringify({
            after: { hasAvatar: false },
            before: { hasAvatar: Boolean(current.avatar_updated_at) },
          })],
        );

        const updatedResult = await client.query(
          `SELECT accounts.*, COALESCE(grants.permissions, ARRAY[]::text[]) AS permissions
           FROM accounts
           LEFT JOIN LATERAL (
             SELECT array_agg(permission ORDER BY permission) AS permissions
             FROM moderator_grants WHERE account_id = accounts.id
           ) grants ON true
           WHERE accounts.id = $1`,
          [targetId],
        );
        return { account: mapManagedAccount(updatedResult.rows[0]) };
      });
    },
    async getSiteSettings() {
      const result = await pool.query(
      `SELECT global_registration_token_enabled,
        global_registration_token_lookup_digest IS NOT NULL
          AS global_registration_token_configured,
        presence_counter_enabled,
        shoutbox_visibility_count,
                shoutbox_visibility_hours, shoutbox_visibility_mode, updated_at
         FROM site_settings WHERE singleton = true`,
      );
      if (!result.rows[0]) {
        throw new Error('site_settings_missing');
      }
      return mapSiteSettings(result.rows[0]);
    },
    async rotateGlobalRegistrationToken({
      actorId,
      expectedUpdatedAt,
      tokenLookupDigest,
      tokenSalt,
      tokenVerifier,
      updatedAt,
    }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT global_registration_token_enabled,
             global_registration_token_lookup_digest,
             presence_counter_enabled, shoutbox_visibility_count,
             shoutbox_visibility_hours, shoutbox_visibility_mode, updated_at
           FROM site_settings WHERE singleton = true FOR UPDATE`,
        );
        const current = currentResult.rows[0];
        if (!current) {
          throw new Error('site_settings_missing');
        }
        if (new Date(current.updated_at).getTime() !== expectedUpdatedAt.getTime()) {
          return null;
        }
        const updatedResult = await client.query(
          `UPDATE site_settings
           SET global_registration_token_enabled = true,
             global_registration_token_lookup_digest = $1,
             global_registration_token_salt = $2,
             global_registration_token_verifier = $3,
             updated_at = $4
           WHERE singleton = true
           RETURNING global_registration_token_enabled,
             true AS global_registration_token_configured,
             presence_counter_enabled, shoutbox_visibility_count,
             shoutbox_visibility_hours, shoutbox_visibility_mode, updated_at`,
          [tokenLookupDigest, tokenSalt, tokenVerifier, updatedAt],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, NULL, 'site.global_registration_token.rotate',
             'Global registration token rotated', $2::jsonb)`,
          [actorId, JSON.stringify({
            after: { configured: true, enabled: true },
            before: {
              configured: current.global_registration_token_lookup_digest !== null,
              enabled: current.global_registration_token_enabled,
            },
          })],
        );
        return mapSiteSettings(updatedResult.rows[0]);
      });
    },
    async updateSiteSettings({
      actorId,
      expectedUpdatedAt,
      globalRegistrationTokenEnabled,
      presenceCounterEnabled,
      reason,
      shoutboxVisibilityCount,
      shoutboxVisibilityHours,
      shoutboxVisibilityMode,
      updatedAt,
    }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
            `SELECT global_registration_token_enabled,
              global_registration_token_lookup_digest, presence_counter_enabled,
              shoutbox_visibility_count,
              shoutbox_visibility_hours, shoutbox_visibility_mode, updated_at
           FROM site_settings WHERE singleton = true FOR UPDATE`,
        );
        const current = currentResult.rows[0];
        if (!current) {
          throw new Error('site_settings_missing');
        }
        if (new Date(current.updated_at).getTime() !== expectedUpdatedAt.getTime()) {
          return null;
        }
        if (
          globalRegistrationTokenEnabled
          && current.global_registration_token_lookup_digest === null
        ) {
          return { globalTokenMissing: true };
        }
        const nextVisibilityCount = shoutboxVisibilityCount
          ?? current.shoutbox_visibility_count;
        const nextVisibilityHours = shoutboxVisibilityHours
          ?? current.shoutbox_visibility_hours;
        if (
          current.global_registration_token_enabled === globalRegistrationTokenEnabled
          && current.presence_counter_enabled === presenceCounterEnabled
          && current.shoutbox_visibility_count === nextVisibilityCount
          && current.shoutbox_visibility_hours === nextVisibilityHours
          && current.shoutbox_visibility_mode === shoutboxVisibilityMode
        ) {
          return mapSiteSettings(current);
        }
        const updatedResult = await client.query(
          `UPDATE site_settings
           SET global_registration_token_enabled = $1, presence_counter_enabled = $2,
               shoutbox_visibility_count = $3, shoutbox_visibility_hours = $4,
               shoutbox_visibility_mode = $5, updated_at = $6
           WHERE singleton = true
           RETURNING global_registration_token_enabled,
                     global_registration_token_lookup_digest IS NOT NULL
                       AS global_registration_token_configured,
                     presence_counter_enabled,
                     shoutbox_visibility_count,
                     shoutbox_visibility_hours, shoutbox_visibility_mode, updated_at`,
          [
            globalRegistrationTokenEnabled,
            presenceCounterEnabled,
            nextVisibilityCount,
            nextVisibilityHours,
            shoutboxVisibilityMode,
            updatedAt,
          ],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, NULL, $2, $3, $4::jsonb)`,
          [actorId, 'site.settings.update', reason, JSON.stringify({
            after: {
              globalRegistrationTokenEnabled,
              presenceCounterEnabled,
              shoutboxVisibilityCount: nextVisibilityCount,
              shoutboxVisibilityHours: nextVisibilityHours,
              shoutboxVisibilityMode,
            },
            before: {
              globalRegistrationTokenEnabled: current.global_registration_token_enabled,
              presenceCounterEnabled: current.presence_counter_enabled,
              shoutboxVisibilityCount: current.shoutbox_visibility_count,
              shoutboxVisibilityHours: current.shoutbox_visibility_hours,
              shoutboxVisibilityMode: current.shoutbox_visibility_mode,
            },
          })],
        );
        return mapSiteSettings(updatedResult.rows[0]);
      });
    },
    async recordServerDiagnostic({ action, actorId, createdAt, details, reason }) {
      await pool.query(
        `INSERT INTO moderation_audit_events (
           actor_account_id, target_account_id, action, reason, details, created_at
         ) VALUES ($1, NULL, $2, $3, $4::jsonb, $5)`,
        [actorId, action, reason, JSON.stringify(details), createdAt],
      );
    },
    async runShoutboxDiagnostic({ actorId, createdAt, loadLimit, writeCount }) {
      return withTransaction(async (client) => {
        if (!await prepareServerDiagnostic(client)) {
          return null;
        }
        await client.query('SAVEPOINT server_diagnostic_work');
        const inserted = await client.query(
          `INSERT INTO shouts (account_id, body)
           SELECT $1, '[Diagnostic] transient Shoutbox load ' || sequence
           FROM generate_series(1, $2) sequence
           RETURNING id`,
          [actorId, writeCount],
        );
        const loaded = await selectShouts(client, loadLimit, actorId);
        await client.query('ROLLBACK TO SAVEPOINT server_diagnostic_work');
        await client.query('RELEASE SAVEPOINT server_diagnostic_work');
        const result = {
          broadcasted: 0,
          loaded: loaded.length,
          persisted: 0,
          written: inserted.rows.length,
        };
        await insertServerDiagnosticAudit(client, {
          action: 'diagnostic.shoutbox.write_load',
          actorId,
          createdAt,
          details: result,
          reason: 'Shoutbox write and load diagnostic run',
        });
        return result;
      });
    },
    async runNotificationPushDiagnostic({ actorId, createdAt, notificationCount }) {
      return withTransaction(async (client) => {
        if (!await prepareServerDiagnostic(client)) {
          return null;
        }
        const inserted = await client.query(
          `INSERT INTO notifications (account_id, message, href, created_at)
           SELECT $1, '[Diagnostic] notification push ' || sequence || ' of ' || $2,
             '/notifications', $3
           FROM generate_series(1, $2) sequence
           RETURNING id`,
          [actorId, notificationCount, createdAt],
        );
        const ids = inserted.rows.map((row) => String(row.id));
        const deliveries = await client.query(
          `SELECT count(*)::integer AS count
           FROM web_push_deliveries
           WHERE notification_id = ANY($1::bigint[])`,
          [ids],
        );
        const result = {
          notificationCount: inserted.rows.length,
          queuedDeliveries: deliveries.rows[0]?.count ?? 0,
        };
        await insertServerDiagnosticAudit(client, {
          action: 'diagnostic.notification_push',
          actorId,
          createdAt,
          details: result,
          reason: 'Notification push diagnostic run',
        });
        return result;
      });
    },
    async listShouts(limit, viewerId = null) {
      return selectShouts(pool, limit, viewerId);
    },
    async getShoutboxCursor() {
      const result = await pool.query(
        'SELECT COALESCE(MAX(sync_cursor), 0) AS cursor FROM shouts',
      );
      return String(result.rows[0].cursor);
    },
    async getShoutboxSnapshot(limit, viewerId = null) {
      return withTransaction(async (client) => {
        await client.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
        const cursorResult = await client.query(
          'SELECT COALESCE(MAX(sync_cursor), 0) AS cursor FROM shouts',
        );
        const settingsResult = await client.query(
          `SELECT shoutbox_visibility_count, shoutbox_visibility_hours,
                  shoutbox_visibility_mode
           FROM site_settings WHERE singleton = true`,
        );
        const settings = settingsResult.rows[0];
        if (!settings) {
          throw new Error('site_settings_missing');
        }
        const visibility = {
          count: settings.shoutbox_visibility_count,
          hours: settings.shoutbox_visibility_hours,
          mode: settings.shoutbox_visibility_mode,
        };
        const page = await selectShoutHistoryPage(client, {
          historyCount: visibility.mode === 'count' ? visibility.count : null,
          historyHours: visibility.mode === 'time' ? visibility.hours : null,
          limit,
          viewerId,
        });
        return {
          cursor: String(cursorResult.rows[0].cursor),
          ...page,
          visibility,
        };
      });
    },
    async getShoutboxHistoryPage(before, limit, viewerId = null) {
      return withTransaction(async (client) => {
        await client.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
        const settingsResult = await client.query(
          `SELECT shoutbox_visibility_count, shoutbox_visibility_hours,
                  shoutbox_visibility_mode
           FROM site_settings WHERE singleton = true`,
        );
        const settings = settingsResult.rows[0];
        if (!settings) {
          throw new Error('site_settings_missing');
        }
        return selectShoutHistoryPage(client, {
          before,
          historyCount: settings.shoutbox_visibility_mode === 'count'
            ? settings.shoutbox_visibility_count
            : null,
          historyHours: settings.shoutbox_visibility_mode === 'time'
            ? settings.shoutbox_visibility_hours
            : null,
          limit,
          viewerId,
        });
      });
    },
    async listShoutChanges(afterCursor, limit, viewerId = null) {
      const result = await pool.query(
        `SELECT shouts.id, shouts.account_id, shouts.body, shouts.created_at,
          shouts.updated_at, shouts.deleted_at, shouts.sync_cursor,
          accounts.display_name, accounts.username, accounts.role, accounts.username_color,
          accounts.username_color_effect, accounts.timestamp_color, accounts.visible_to_role,
          accounts.avatar_content_type, accounts.avatar_updated_at,
          COALESCE((
            SELECT jsonb_agg(jsonb_build_object(
              'username', mentioned.username,
              'usernameColor', mentioned.username_color,
              'usernameColorEffect', mentioned.username_color_effect
            ) ORDER BY mentioned.normalized_username)
            FROM shout_mentions
            JOIN accounts mentioned ON mentioned.id = shout_mentions.mentioned_account_id
            WHERE shout_mentions.shout_id = shouts.id
              AND mentioned.membership_status = 'active'
              AND mentioned.deleted_at IS NULL
              AND account_visible_to($3, mentioned.id)
          ), '[]'::jsonb) AS mention_accounts,
          COALESCE((
            SELECT jsonb_agg(
              jsonb_build_object('count', reaction_counts.count, 'reaction', reaction_counts.reaction)
              ORDER BY reaction_counts.reaction
            )
            FROM (
              SELECT reactions.reaction, count(*)::integer AS count
              FROM shout_reactions reactions
              JOIN accounts reacting_accounts ON reacting_accounts.id = reactions.account_id
              WHERE reactions.shout_id = shouts.id
                AND account_visible_to($3, reacting_accounts.id)
              GROUP BY reactions.reaction
            ) reaction_counts
          ), '[]'::jsonb) AS reactions,
          ARRAY(
            SELECT viewer_reactions.reaction
            FROM shout_reactions viewer_reactions
            WHERE viewer_reactions.shout_id = shouts.id
              AND viewer_reactions.account_id = $3
            ORDER BY viewer_reactions.reaction
          ) AS viewer_reactions
         FROM shouts JOIN accounts ON accounts.id = shouts.account_id
         WHERE shouts.sync_cursor > $1
           AND account_visible_to($3, accounts.id)
           AND ($3::uuid IS NULL OR shouts.created_at >= (
             SELECT viewers.created_at FROM accounts viewers WHERE viewers.id = $3
           ))
         ORDER BY shouts.sync_cursor ASC LIMIT $2`,
        [afterCursor, limit, viewerId],
      );
      return result.rows.map(mapShoutChange);
    },
    async manageAccount({
      action,
      actorId,
      expectedUpdatedAt,
      grants,
      reason,
      targetId,
      updatedAt,
      updates,
    }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT * FROM accounts WHERE id = $1 FOR UPDATE`,
          [targetId],
        );
        const current = currentResult.rows[0];
        if (!current || new Date(current.updated_at).getTime() !== expectedUpdatedAt.getTime()) {
          return { account: null };
        }

        const nextRole = updates.role ?? current.role;
        const nextMembershipStatus = updates.membershipStatus ?? current.membership_status;
        const nextDeletedAt = updates.deletedAt ?? current.deleted_at;
        if (
          ['admin', 'dev', 'owner'].includes(current.role)
          && current.membership_status === 'active'
          && !current.deleted_at
          && (!['admin', 'dev', 'owner'].includes(nextRole) || nextMembershipStatus !== 'active' || nextDeletedAt)
        ) {
          const administrators = await client.query(
            `SELECT id FROM accounts
             WHERE role IN ('admin', 'dev', 'owner')
               AND membership_status = 'active' AND deleted_at IS NULL
             FOR UPDATE`,
          );
          if (administrators.rows.length <= 1) {
            return { account: null, lastAdministrator: true };
          }
        }

        const columns = {
          deletedAt: 'deleted_at',
          forcePasswordChange: 'force_password_change',
          forumPostingMuted: 'forum_posting_muted',
          membershipStatus: 'membership_status',
          role: 'role',
          shoutboxPostingMuted: 'shoutbox_posting_muted',
          slowdownMs: 'slowdown_ms',
        };
        const parameters = [targetId];
        const assignments = Object.entries(updates).map(([key, value]) => {
          parameters.push(value);
          return `${columns[key]} = $${parameters.length}`;
        });
        parameters.push(updatedAt);
        assignments.push(`updated_at = $${parameters.length}`);
        await client.query(
          `UPDATE accounts SET ${assignments.join(', ')} WHERE id = $1`,
          parameters,
        );
        if (updates.deletedAt && !current.deleted_at) {
          const deletedIdentity = deletedAccountIdentity(targetId);
          await client.query(
            `DELETE FROM email_verification_tokens WHERE account_id = $1`,
            [targetId],
          );
          await client.query(
            `DELETE FROM password_reset_tokens WHERE account_id = $1`,
            [targetId],
          );
          await client.query(
            `DELETE FROM username_reservations WHERE normalized_username = $1`,
            [current.normalized_username],
          );
          await client.query(
            `UPDATE accounts
             SET email = $2, normalized_email = $2, username = $3,
               display_name = $3, normalized_username = $4, email_verified_at = NULL,
               location = '', signature = '', title = ''
             WHERE id = $1`,
            [
              targetId,
              deletedIdentity.email,
              deletedIdentity.username,
              deletedIdentity.normalizedUsername,
            ],
          );
          await client.query(
            `DELETE FROM post_attachments WHERE uploader_account_id = $1`,
            [targetId],
          );
        }

        if (grants !== undefined || (updates.role && updates.role !== 'moderator')) {
          await client.query(`DELETE FROM moderator_grants WHERE account_id = $1`, [targetId]);
        }
        for (const permission of grants ?? []) {
          await client.query(
            `INSERT INTO moderator_grants (account_id, permission, granted_by)
             VALUES ($1, $2, $3)`,
            [targetId, permission, actorId],
          );
        }
        if (
          updates.deletedAt
          || updates.forcePasswordChange
          || updates.membershipStatus !== undefined
          || updates.role !== undefined
          || grants !== undefined
        ) {
          await client.query(
            `UPDATE sessions SET revoked_at = $2
             WHERE account_id = $1 AND revoked_at IS NULL`,
            [targetId, updatedAt],
          );
        }

        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, $3, $4, $5::jsonb)`,
          [actorId, targetId, action, reason, JSON.stringify({
            after: updates,
            before: {
              forcePasswordChange: current.force_password_change,
              forumPostingMuted: current.forum_posting_muted,
              membershipStatus: current.membership_status,
              role: current.role,
              shoutboxPostingMuted: current.shoutbox_posting_muted,
              slowdownMs: current.slowdown_ms,
            },
            grants,
          })],
        );

        if (
          updates.membershipStatus !== undefined
          && nextMembershipStatus !== current.membership_status
          && nextMembershipStatus !== 'deleted'
        ) {
          await client.query(
            `INSERT INTO notifications (account_id, message, href)
             VALUES ($1, $2, '/notifications')`,
            [targetId, membershipDecisionMessages.get(nextMembershipStatus)],
          );
        }

        const updatedResult = await client.query(
          `SELECT accounts.*, COALESCE(grants.permissions, ARRAY[]::text[]) AS permissions
           FROM accounts
           LEFT JOIN LATERAL (
             SELECT array_agg(permission ORDER BY permission) AS permissions
             FROM moderator_grants WHERE account_id = accounts.id
           ) grants ON true
           WHERE accounts.id = $1`,
          [targetId],
        );
        return { account: mapManagedAccount(updatedResult.rows[0]) };
      });
    },
    async setFollowing(followerId, followedId, following) {
      return withTransaction(async (client) => {
        const result = following
          ? await client.query(
            `INSERT INTO account_follows (follower_account_id, followed_account_id)
             SELECT $1, $2 WHERE account_visible_to($1, $2)
             ON CONFLICT DO NOTHING
             RETURNING follower_account_id`,
            [followerId, followedId],
          )
          : await client.query(
            `DELETE FROM account_follows
             WHERE follower_account_id = $1 AND followed_account_id = $2
             RETURNING follower_account_id`,
            [followerId, followedId],
          );
        if (!result.rows[0]) {
          return false;
        }
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, $3, $4, $5::jsonb)`,
          [
            followerId,
            followedId,
            following ? 'account.follow' : 'account.unfollow',
            following ? 'Account followed' : 'Account unfollowed',
            JSON.stringify({
              after: { following },
              before: { following: !following },
            }),
          ],
        );
        return true;
      });
    },
    async replacePasswordResetToken(accountId, tokenDigest, expiresAt) {
      await withTransaction(async (client) => {
        await client.query(`DELETE FROM password_reset_tokens WHERE account_id = $1`, [accountId]);
        await client.query(
          `INSERT INTO password_reset_tokens (token_digest, account_id, expires_at)
           VALUES ($1, $2, $3)`,
          [tokenDigest, accountId, expiresAt],
        );
      });
    },
    async replaceVerificationToken(accountId, tokenDigest, expiresAt) {
      await withTransaction(async (client) => {
        await client.query(`DELETE FROM email_verification_tokens WHERE account_id = $1`, [accountId]);
        await client.query(
          `INSERT INTO email_verification_tokens (token_digest, account_id, expires_at)
           VALUES ($1, $2, $3)`,
          [tokenDigest, accountId, expiresAt],
        );
      });
    },
    async recordAuthenticationEvent({ accountId, action, details, occurredAt }) {
      await pool.query(
        `INSERT INTO authentication_audit_events (account_id, action, details, created_at)
         VALUES ($1, $2, $3::jsonb, $4)`,
        [accountId, action, JSON.stringify(details), occurredAt],
      );
    },
    async revokeSession(tokenDigest, revokedAt, accountId) {
      await pool.query(
        `WITH revoked AS (
           UPDATE sessions SET revoked_at = $2
           WHERE token_digest = $1 AND account_id = $3 AND revoked_at IS NULL
           RETURNING account_id, id
         )
         INSERT INTO authentication_audit_events (account_id, session_id, action)
         SELECT account_id, id, 'auth.session.logged_out' FROM revoked`,
        [tokenDigest, revokedAt, accountId],
      );
    },
    async revokeAccountSession(accountId, sessionId, revokedAt) {
      const result = await pool.query(
        `WITH revoked AS (
           UPDATE sessions SET revoked_at = $3
           WHERE account_id = $1 AND id = $2 AND revoked_at IS NULL
           RETURNING id
         ), audit_event AS (
           INSERT INTO authentication_audit_events (account_id, session_id, action)
           SELECT $1, id, 'auth.session.revoked' FROM revoked
           RETURNING id
         )
         SELECT id FROM revoked`,
        [accountId, sessionId, revokedAt],
      );
      return Boolean(result.rows[0]);
    },
    async revokeAllSessions(accountId, revokedAt) {
      return withTransaction(async (client) => {
        const result = await client.query(
          `UPDATE sessions SET revoked_at = $2
           WHERE account_id = $1 AND revoked_at IS NULL
           RETURNING id`,
          [accountId, revokedAt],
        );
        await client.query(
          `INSERT INTO authentication_audit_events (account_id, action, details)
           VALUES ($1, 'auth.sessions.revoked_all', $2::jsonb)`,
          [accountId, JSON.stringify({ revokedCount: result.rows.length })],
        );
        return result.rows.length;
      });
    },
    async setNotificationRead({ accountId, notificationId, read, updatedAt }) {
      const result = await pool.query(
        `UPDATE notifications SET read_at = $3
         WHERE id = $1 AND account_id = $2
         RETURNING id, message, href, read_at, created_at`,
        [notificationId, accountId, read ? updatedAt : null],
      );
      return result.rows[0] ? mapNotification(result.rows[0]) : null;
    },
    async markAllNotificationsRead({ accountId, updatedAt }) {
      const result = await pool.query(
        `UPDATE notifications SET read_at = $2
         WHERE account_id = $1 AND read_at IS NULL
         RETURNING id`,
        [accountId, updatedAt],
      );
      return result.rows.length;
    },
    async updatePreferences(accountId, preferences) {
      const result = await pool.query(
        `UPDATE accounts
         SET theme = $2, color_scheme = $3, shoutbox_enabled = $4,
           shoutbox_muted = $5, font_size = $6, font_typeface = $7,
           time_zone = $8, shoutbox_height_lines = $9, shoutbox_order = $10,
           updated_at = now()
         WHERE id = $1 RETURNING *`,
        [
          accountId,
          preferences.theme,
          preferences.colorScheme,
          preferences.shoutboxEnabled,
          preferences.shoutboxMuted,
          preferences.fontSize,
          preferences.fontTypeface,
          preferences.timeZone,
          preferences.shoutboxHeightLines,
          preferences.shoutboxOrder,
        ],
      );
      return mapAccount(result.rows[0]);
    },
    async updateProfile(accountId, profile) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
           `SELECT description, location, signature, title, timestamp_color, username_color, username_color_effect,
             username_color_effects_unlocked_at FROM accounts
           WHERE id = $1 AND membership_status = 'active' AND deleted_at IS NULL
           FOR UPDATE`,
          [accountId],
        );
        const current = currentResult.rows[0];
        if (!current) {
          return null;
        }
        const usernameColorEffect = profile.usernameColorEffect
          ?? current.username_color_effect
          ?? 'none';
        const timestampColor = profile.timestampColor ?? current.timestamp_color ?? 'default';
        if (
          usernameColorEffect !== 'none'
          && !current.username_color_effects_unlocked_at
        ) {
          return null;
        }
        const result = await client.query(
          `UPDATE accounts
           SET description = $2, username_color = $3, username_color_effect = $4,
             timestamp_color = $5, location = $6, title = $7, signature = $8,
             updated_at = now()
           WHERE id = $1
           RETURNING description, location, signature, title, timestamp_color, username_color,
             username_color_effect`,
          [
            accountId,
            profile.description,
            profile.usernameColor,
            usernameColorEffect,
            timestampColor,
            profile.location,
            profile.title,
            profile.signature,
          ],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $1, 'account.profile.update', $2, $3::jsonb)`,
          [accountId, 'Account profile updated', JSON.stringify({
            after: {
              descriptionPresent: Boolean(profile.description),
              locationPresent: Boolean(profile.location),
              signaturePresent: Boolean(profile.signature),
              timestampColor,
              titlePresent: Boolean(profile.title),
              usernameColor: profile.usernameColor,
              usernameColorEffect,
            },
            before: {
              descriptionPresent: Boolean(current.description),
              locationPresent: Boolean(current.location),
              signaturePresent: Boolean(current.signature),
              timestampColor: current.timestamp_color ?? 'default',
              titlePresent: Boolean(current.title),
              usernameColor: current.username_color,
              usernameColorEffect: current.username_color_effect,
            },
          })],
        );
        return {
          description: result.rows[0].description,
          location: result.rows[0].location,
          signature: result.rows[0].signature,
          timestampColor: result.rows[0].timestamp_color,
          title: result.rows[0].title,
          usernameColor: result.rows[0].username_color,
          usernameColorEffect: result.rows[0].username_color_effect,
        };
      });
    },
    async createUsernameColorUnlockCode({ actorId, createdAt, expiresAt, tokenDigest }) {
      return withTransaction(async (client) => {
        const result = await client.query(
          `INSERT INTO username_color_unlock_codes (
             token_digest, created_by_account_id, created_at, expires_at
           ) VALUES ($1, $2, $3, $4)
           RETURNING id, expires_at`,
          [tokenDigest, actorId, createdAt, expiresAt],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $1, 'account.username_color_unlock.issue', $2, $3::jsonb)`,
          [actorId, 'Username color unlock code issued', JSON.stringify({
            expiresAt: expiresAt.toISOString(),
            unlockCodeId: String(result.rows[0].id),
          })],
        );
        return { expiresAt: result.rows[0].expires_at, id: String(result.rows[0].id) };
      });
    },
    async redeemUsernameColorUnlockCode(accountId, tokenDigest) {
      return withTransaction(async (client) => {
        const accountResult = await client.query(
          `SELECT id FROM accounts
           WHERE id = $1 AND membership_status = 'active' AND deleted_at IS NULL
           FOR UPDATE`,
          [accountId],
        );
        if (!accountResult.rows[0]) {
          return false;
        }
        const codeResult = await client.query(
          `SELECT id FROM username_color_unlock_codes
           WHERE token_digest = $1 AND redeemed_at IS NULL AND expires_at > now()
           FOR UPDATE`,
          [tokenDigest],
        );
        const code = codeResult.rows[0];
        if (!code) {
          return false;
        }
        await client.query(
          `UPDATE username_color_unlock_codes
           SET redeemed_by_account_id = $2, redeemed_at = now()
           WHERE id = $1`,
          [code.id, accountId],
        );
        await client.query(
          `UPDATE accounts
           SET username_color_effects_unlocked_at = COALESCE(
             username_color_effects_unlocked_at, now()
           ), updated_at = now()
           WHERE id = $1`,
          [accountId],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $1, 'account.username_color_unlock.redeem', $2, $3::jsonb)`,
          [accountId, 'Username color effects unlocked', JSON.stringify({
            unlockCodeId: String(code.id),
          })],
        );
        return true;
      });
    },
    async updateAvatar({ accountId, contentType, data, updatedAt }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT avatar_updated_at FROM accounts WHERE id = $1 FOR UPDATE`,
          [accountId],
        );
        if (!currentResult.rows[0]) {
          return null;
        }
        const result = await client.query(
          `UPDATE accounts
           SET avatar_content_type = $2, avatar_data = $3, avatar_updated_at = $4,
             updated_at = $4
           WHERE id = $1 RETURNING *`,
          [accountId, contentType, data, updatedAt],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $1, 'account.avatar.update', $2, $3::jsonb)`,
          [accountId, 'Account avatar updated', JSON.stringify({
            after: { hasAvatar: true },
            before: { hasAvatar: Boolean(currentResult.rows[0].avatar_updated_at) },
          })],
        );
        return mapAccount(result.rows[0]);
      });
    },
  };
}