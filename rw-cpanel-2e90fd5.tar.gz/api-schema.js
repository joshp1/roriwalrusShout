import { canonicalUuidPath } from './uuid.js';

function exactPath(pathname) {
  const escaped = pathname.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`^${escaped}$`);
}

function defineRoute(method, path, area, input, samplePath = path, pattern = exactPath(path)) {
  return Object.freeze({ area, input, method, path, pattern, samplePath });
}

const decimalId = '(\\d+)';
const uuidCapture = `(${canonicalUuidPath})`;

export const apiRouteSchemas = Object.freeze([
  defineRoute('GET', '/api/health', 'health', 'none'),
  defineRoute('GET', '/api/readiness', 'readiness', 'none'),
  defineRoute('GET', '/api/auth/static-access', 'auth', 'session cookie'),
  defineRoute('GET', '/api/presence/challenge', 'presence', 'presence cookie'),
  defineRoute('POST', '/api/presence/challenge', 'presence', 'JSON token'),
  defineRoute('GET', '/api/avatars/:accountId', 'account', 'UUID path; session cookie', '/api/avatars/00000000-0000-4000-8000-000000000001', new RegExp(`^/api/avatars/${uuidCapture}$`, 'i')),
  defineRoute('GET', '/api/auth/session', 'auth', 'session cookie'),
  defineRoute('GET', '/api/account/sessions', 'account', 'session cookie'),
  defineRoute('GET', '/api/notifications', 'notifications', 'query limit, offset; session cookie'),
  defineRoute('PUT', '/api/notifications/read', 'notifications', 'session cookie; CSRF'),
  defineRoute('GET', '/api/push/configuration', 'notifications', 'session cookie'),
  defineRoute('GET', '/api/shouts/:shoutId/reactions', 'shoutbox', 'positive bigint path; query optional reaction, limit, offset; session cookie', '/api/shouts/1/reactions', new RegExp(`^/api/shouts/${decimalId}/reactions$`)),
  defineRoute('GET', '/api/posts/:postId/reactions', 'forum', 'positive bigint path; query optional reaction, limit, offset; session cookie', '/api/posts/1/reactions', new RegExp(`^/api/posts/${decimalId}/reactions$`)),
  defineRoute('GET', '/api/posts/:postId/deleted', 'forum', 'positive bigint path; query limit, offset; authorized staff session', '/api/posts/1/deleted', new RegExp(`^/api/posts/${decimalId}/deleted$`)),
  defineRoute('GET', '/api/direct-messages', 'direct_messages', 'query limit, offset; session cookie'),
  defineRoute('GET', '/api/direct-messages/:threadId', 'direct_messages', 'positive bigint path; query limit, offset; session cookie', '/api/direct-messages/1', new RegExp(`^/api/direct-messages/${decimalId}$`)),
  defineRoute('GET', '/api/admin/direct-messages', 'admin', 'query limit, offset; session cookie'),
  defineRoute('GET', '/api/forum/search', 'forum', 'query q, limit, offset; session cookie'),
  defineRoute('GET', '/api/topics', 'forum', 'query limit, offset; session cookie'),
  defineRoute('GET', '/api/topics/:topicId', 'forum', 'positive bigint path; query limit, offset; session cookie', '/api/topics/1', new RegExp(`^/api/topics/${decimalId}$`)),
  defineRoute('GET', '/api/attachments/:attachmentId', 'forum', 'positive bigint path; session cookie', '/api/attachments/1', new RegExp(`^/api/attachments/${decimalId}$`)),
  defineRoute('DELETE', '/api/attachments/:attachmentId', 'forum', 'positive bigint path; JSON optional moderator reason; session cookie; CSRF', '/api/attachments/1', new RegExp(`^/api/attachments/${decimalId}$`)),
  defineRoute('GET', '/api/profiles', 'profile', 'query prefix; session cookie'),
  defineRoute('GET', '/api/profiles/:username', 'profile', 'username path; session cookie', '/api/profiles/member', /^\/api\/profiles\/([^/]+)$/),
  defineRoute('GET', '/api/admin/accounts', 'admin', 'query limit, offset; session cookie'),
  defineRoute('PATCH', '/api/admin/accounts/:targetId', 'admin', 'UUID path; JSON expectedUpdatedAt and one or more account settings; session cookie; CSRF', '/api/admin/accounts/00000000-0000-4000-8000-000000000001', new RegExp(`^/api/admin/accounts/${uuidCapture}$`, 'i')),
  defineRoute('GET', '/api/admin/site-settings', 'admin', 'session cookie'),
  defineRoute('GET', '/api/admin/authentication-audit', 'admin', 'query limit, offset; session cookie'),
  defineRoute('POST', '/api/admin/server-diagnostics', 'admin', 'JSON bounded operation parameters; session cookie; CSRF'),
  defineRoute('GET', '/api/admin/accounts/:targetId/audit', 'admin', 'UUID path; query limit, offset; session cookie', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/audit', new RegExp(`^/api/admin/accounts/${uuidCapture}/audit$`, 'i')),
  defineRoute('GET', '/api/admin/accounts/:targetId/content', 'admin', 'UUID path; query limit, offset; session cookie', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/content', new RegExp(`^/api/admin/accounts/${uuidCapture}/content$`, 'i')),
  defineRoute('PATCH', '/api/admin/site-settings', 'admin', 'JSON globalRegistrationTokenEnabled, presenceCounterEnabled, shoutboxVisibilityMode, exactly one active limit: shoutboxVisibilityCount or shoutboxVisibilityDays, expectedUpdatedAt'),
  defineRoute('POST', '/api/admin/global-registration-token', 'admin', 'JSON expectedUpdatedAt; session cookie; CSRF; rotates and returns reusable token once'),
  defineRoute('POST', '/api/admin/username-color-unlocks', 'admin', 'session cookie; CSRF'),
  defineRoute('POST', '/api/direct-messages', 'direct_messages', 'JSON title, usernames'),
  defineRoute('POST', '/api/direct-messages/:threadId/messages', 'direct_messages', 'positive bigint path; JSON body', '/api/direct-messages/1/messages', new RegExp(`^/api/direct-messages/${decimalId}/messages$`)),
  defineRoute('POST', '/api/direct-messages/:threadId/invite', 'direct_messages', 'positive bigint path; JSON username', '/api/direct-messages/1/invite', new RegExp(`^/api/direct-messages/${decimalId}/invite$`)),
  defineRoute('POST', '/api/direct-messages/:threadId/leave', 'direct_messages', 'positive bigint path', '/api/direct-messages/1/leave', new RegExp(`^/api/direct-messages/${decimalId}/leave$`)),
  defineRoute('POST', '/api/direct-messages/:threadId/lock', 'direct_messages', 'positive bigint path', '/api/direct-messages/1/lock', new RegExp(`^/api/direct-messages/${decimalId}/lock$`)),
  defineRoute('PUT', '/api/direct-messages/:threadId/read', 'direct_messages', 'positive bigint path; session cookie; CSRF', '/api/direct-messages/1/read', new RegExp(`^/api/direct-messages/${decimalId}/read$`)),
  defineRoute('POST', '/api/admin/direct-messages/:threadId/inspection', 'admin', 'positive bigint path; JSON optional limit, offset', '/api/admin/direct-messages/1/inspection', new RegExp(`^/api/admin/direct-messages/${decimalId}/inspection$`)),
  defineRoute('DELETE', '/api/account/sessions/:sessionId', 'account', 'UUID path; session cookie; CSRF', '/api/account/sessions/00000000-0000-4000-8000-000000000001', new RegExp(`^/api/account/sessions/${uuidCapture}$`, 'i')),
  defineRoute('POST', '/api/topics', 'forum', 'JSON title, body'),
  defineRoute('PATCH', '/api/topics/:topicId', 'forum', 'positive bigint path; JSON title, expectedUpdatedAt, optional reason', '/api/topics/1', new RegExp(`^/api/topics/${decimalId}$`)),
  defineRoute('DELETE', '/api/topics/:topicId', 'forum', 'positive bigint path; JSON optional reason', '/api/topics/1', new RegExp(`^/api/topics/${decimalId}$`)),
  defineRoute('PUT', '/api/topics/:topicId/subscription', 'forum', 'positive bigint path; session cookie; CSRF', '/api/topics/1/subscription', new RegExp(`^/api/topics/${decimalId}/subscription$`)),
  defineRoute('DELETE', '/api/topics/:topicId/subscription', 'forum', 'positive bigint path; session cookie; CSRF', '/api/topics/1/subscription', new RegExp(`^/api/topics/${decimalId}/subscription$`)),
  defineRoute('POST', '/api/topics/:topicId/posts', 'forum', 'positive bigint path; JSON body', '/api/topics/1/posts', new RegExp(`^/api/topics/${decimalId}/posts$`)),
  defineRoute('POST', '/api/posts/:postId/attachments', 'forum', 'positive bigint path; binary attachment up to 10 MiB; encoded X-Attachment-Name; session cookie; CSRF', '/api/posts/1/attachments', new RegExp(`^/api/posts/${decimalId}/attachments$`)),
  defineRoute('PUT', '/api/posts/:postId/reactions', 'forum', 'positive bigint path; JSON reaction; session cookie; CSRF', '/api/posts/1/reactions', new RegExp(`^/api/posts/${decimalId}/reactions$`)),
  defineRoute('DELETE', '/api/posts/:postId/reactions', 'forum', 'positive bigint path; session cookie; CSRF', '/api/posts/1/reactions', new RegExp(`^/api/posts/${decimalId}/reactions$`)),
  defineRoute('POST', '/api/posts/:postId/restore', 'forum', 'positive bigint path; JSON expectedUpdatedAt, reason; authorized staff session; CSRF', '/api/posts/1/restore', new RegExp(`^/api/posts/${decimalId}/restore$`)),
  defineRoute('PATCH', '/api/topics/:topicId/lock', 'forum', 'positive bigint path; JSON locked', '/api/topics/1/lock', new RegExp(`^/api/topics/${decimalId}/lock$`)),
  defineRoute('PATCH', '/api/posts/:postId', 'forum', 'positive bigint path; JSON body, expectedUpdatedAt, optional reason', '/api/posts/1', new RegExp(`^/api/posts/${decimalId}$`)),
  defineRoute('DELETE', '/api/posts/:postId', 'forum', 'positive bigint path; JSON optional reason', '/api/posts/1', new RegExp(`^/api/posts/${decimalId}$`)),
  defineRoute('PATCH', '/api/account/profile', 'account', 'JSON description, title, location, signature, usernameColor preset or #rrggbb, usernameColorEffect'),
  defineRoute('POST', '/api/account/username-color-unlock', 'account', 'JSON code; session cookie; CSRF'),
  defineRoute('PUT', '/api/profiles/:username', 'profile', 'username path; session cookie; CSRF', '/api/profiles/member', /^\/api\/profiles\/([^/]+)$/),
  defineRoute('DELETE', '/api/profiles/:username', 'profile', 'username path; session cookie; CSRF', '/api/profiles/member', /^\/api\/profiles\/([^/]+)$/),
  defineRoute('DELETE', '/api/admin/accounts/:targetId', 'admin', 'UUID path; JSON expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001', new RegExp(`^/api/admin/accounts/${uuidCapture}$`, 'i')),
  defineRoute('PATCH', '/api/admin/accounts/:targetId/membership', 'admin', 'UUID path; JSON membershipStatus, expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/membership', new RegExp(`^/api/admin/accounts/${uuidCapture}/membership$`, 'i')),
  defineRoute('POST', '/api/admin/accounts/:targetId/force-password-reset', 'admin', 'UUID path; JSON expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/force-password-reset', new RegExp(`^/api/admin/accounts/${uuidCapture}/force-password-reset$`, 'i')),
  defineRoute('DELETE', '/api/admin/accounts/:targetId/avatar', 'admin', 'UUID path; JSON expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/avatar', new RegExp(`^/api/admin/accounts/${uuidCapture}/avatar$`, 'i')),
  defineRoute('PUT', '/api/admin/accounts/:targetId/moderator-grants', 'admin', 'UUID path; JSON permissions, expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/moderator-grants', new RegExp(`^/api/admin/accounts/${uuidCapture}/moderator-grants$`, 'i')),
  defineRoute('PATCH', '/api/admin/accounts/:targetId/role', 'admin', 'UUID path; JSON role, expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/role', new RegExp(`^/api/admin/accounts/${uuidCapture}/role$`, 'i')),
  defineRoute('PATCH', '/api/admin/accounts/:targetId/slowdown', 'admin', 'UUID path; JSON slowdownMs, expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/slowdown', new RegExp(`^/api/admin/accounts/${uuidCapture}/slowdown$`, 'i')),
  defineRoute('PATCH', '/api/admin/accounts/:targetId/forum-mute', 'admin', 'UUID path; JSON muted, expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/forum-mute', new RegExp(`^/api/admin/accounts/${uuidCapture}/forum-mute$`, 'i')),
  defineRoute('PATCH', '/api/admin/accounts/:targetId/shoutbox-mute', 'admin', 'UUID path; JSON muted, expectedUpdatedAt', '/api/admin/accounts/00000000-0000-4000-8000-000000000001/shoutbox-mute', new RegExp(`^/api/admin/accounts/${uuidCapture}/shoutbox-mute$`, 'i')),
  defineRoute('POST', '/api/admin/registration-invites', 'admin', 'session cookie; CSRF'),
  defineRoute('POST', '/api/auth/register', 'auth', 'JSON email, inviteToken, password, username'),
  defineRoute('POST', '/api/auth/verify-email', 'auth', 'JSON token'),
  defineRoute('POST', '/api/auth/verification/resend', 'auth', 'JSON email'),
  defineRoute('POST', '/api/auth/login', 'auth', 'JSON username, password, optional rememberMe'),
  defineRoute('POST', '/api/auth/logout', 'auth', 'session cookie; CSRF'),
  defineRoute('POST', '/api/auth/logout-all', 'auth', 'session cookie; CSRF'),
  defineRoute('PUT', '/api/account/avatar', 'account', 'binary avatar up to 1 MiB; session cookie; CSRF'),
  defineRoute('POST', '/api/auth/password-reset/request', 'auth', 'JSON email'),
  defineRoute('POST', '/api/auth/password-reset/confirm', 'auth', 'JSON password, token'),
  defineRoute('PATCH', '/api/preferences', 'account', 'JSON preference fields including shoutboxHeightLines 7-60 and shoutboxOrder enum'),
  defineRoute('PUT', '/api/push/subscription', 'notifications', 'JSON PushSubscription; session cookie; CSRF'),
  defineRoute('DELETE', '/api/push/subscription', 'notifications', 'JSON endpoint; session cookie; CSRF'),
  defineRoute('PATCH', '/api/notifications/:notificationId', 'notifications', 'positive bigint path; JSON read', '/api/notifications/1', new RegExp(`^/api/notifications/${decimalId}$`)),
]);

export function getApiRouteSchema(method, pathname) {
  return apiRouteSchemas.find((schema) => (
    schema.method === method && schema.pattern.test(pathname)
  )) ?? null;
}