import { setTimeout as sleep } from 'node:timers/promises';
import {
  grantableModeratorPermissions,
  isAdministrator,
  permissions,
  requirePermission,
} from './policy.js';
import { parseIsoTimestamp } from './timestamp.js';
import { isCanonicalUuid } from './uuid.js';
import {
  createUsernameColorUnlockCode,
  digestUsernameColorUnlockCode,
} from './username-color-effects.js';
import {
  createRegistrationInviteSalt,
  createRegistrationInviteToken,
  deriveRegistrationInviteVerifier,
  digestRegistrationInviteToken,
} from './registration-invites.js';

const maximumPageSize = 50;
const managedMembershipStatuses = new Set([
  'active',
  'pending',
  'rejected',
  'revoked',
  'suspended',
]);
const managedRoles = new Set(['admin', 'member', 'moderator']);
const shoutboxVisibilityModes = new Set(['count', 'time']);
const maximumDiagnosticLagMs = 5000;
const maximumDiagnosticNotificationCount = 25;
const maximumDiagnosticShoutboxLoad = 50;
const maximumDiagnosticShoutboxWrites = 20;
const mutationAuditReasons = new Map([
  ['account.delete', 'Account deleted'],
  ['account.force_password_reset', 'Password reset required'],
  ['account.forum_posting_mute', 'Forum posting mute changed'],
  ['account.membership', 'Membership status changed'],
  ['account.moderator_grants', 'Moderator permissions changed'],
  ['account.role', 'Account role changed'],
  ['account.shoutbox_posting_mute', 'Shoutbox posting mute changed'],
  ['account.slowdown', 'Posting slowdown changed'],
  ['account.update', 'Account settings changed'],
]);

export class AdministrationError extends Error {
  constructor(code, statusCode) {
    super(code);
    this.code = code;
    this.statusCode = statusCode;
  }
}

function parsePageValue(value, fallback, maximum) {
  if (value === undefined || value === null) {
    return fallback;
  }
  if (!['number', 'string'].includes(typeof value) || !/^\d+$/.test(String(value))) {
    throw new AdministrationError('invalid_administration_query', 400);
  }
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed > maximum) {
    throw new AdministrationError('invalid_administration_query', 400);
  }
  return parsed;
}

function parsePageLimit(value, fallback) {
  const limit = parsePageValue(value, fallback, maximumPageSize);
  if (limit === 0) {
    throw new AdministrationError('invalid_administration_query', 400);
  }
  return limit;
}

function parseTargetId(value) {
  if (!isCanonicalUuid(value)) {
    throw new AdministrationError('invalid_account', 400);
  }
  return String(value);
}

function parseExpectedUpdatedAt(value, code = 'invalid_account_version') {
  const expectedUpdatedAt = parseIsoTimestamp(value);
  if (!expectedUpdatedAt) {
    throw new AdministrationError(code, 400);
  }
  return expectedUpdatedAt;
}

function managedAccountProjection(account, includeEmail) {
  if (includeEmail) {
    return account;
  }
  const { email: _email, ...projection } = account;
  return projection;
}

export function createAdministrationService({
  authService,
  clock = () => new Date(),
  diagnosticDelay = (delayMs, signal) => sleep(delayMs, undefined, { signal }),
  diagnosticNow = () => performance.now(),
  forumRepository,
  inviteSaltFactory = createRegistrationInviteSalt,
  inviteTokenFactory = createRegistrationInviteToken,
  inviteVerifierFactory = deriveRegistrationInviteVerifier,
  repository,
  unlockCodeFactory = createUsernameColorUnlockCode,
}) {
  let diagnosticPending = false;

  async function listAccounts(sessionToken, query = {}) {
    const { account } = await authService.getSession(sessionToken);
    requirePermission(account, permissions.usersView);
    const limit = parsePageLimit(query.limit, 25);
    const offset = parsePageValue(query.offset, 0, Number.MAX_SAFE_INTEGER);
    const [accounts, totalCount] = await Promise.all([
      repository.listManagedAccounts(account.id, limit + 1, offset),
      repository.countManagedAccounts(account.id),
    ]);
    return {
      accounts: accounts.slice(0, limit).map((managedAccount) => (
        managedAccountProjection(managedAccount, isAdministrator(account))
      )),
      hasMore: accounts.length > limit,
      nextOffset: offset + Math.min(accounts.length, limit),
      totalCount,
    };
  }

  async function listAudit(sessionToken, targetId, query = {}) {
    const { account } = await authService.getSession(sessionToken);
    requirePermission(account, permissions.auditView);
    const limit = parsePageLimit(query.limit, 25);
    const offset = parsePageValue(query.offset, 0, Number.MAX_SAFE_INTEGER);
    const events = await repository.listAccountAudit(
      account.id,
      parseTargetId(targetId),
      limit + 1,
      offset,
    );
    return {
      events: events.slice(0, limit),
      hasMore: events.length > limit,
      nextOffset: offset + Math.min(events.length, limit),
    };
  }

  async function listAuthenticationAudit(sessionToken, query = {}) {
    const { account } = await authService.getSession(sessionToken);
    requirePermission(account, permissions.auditView);
    const limit = parsePageLimit(query.limit, 25);
    const offset = parsePageValue(query.offset, 0, Number.MAX_SAFE_INTEGER);
    const events = await repository.listAuthenticationAudit(account.id, limit + 1, offset);
    return {
      events: events.slice(0, limit),
      hasMore: events.length > limit,
      nextOffset: offset + Math.min(events.length, limit),
    };
  }

  async function listContent(sessionToken, targetId, query = {}) {
    const { account } = await authService.getSession(sessionToken);
    requirePermission(account, permissions.usersView);
    const id = parseTargetId(targetId);
    const limit = parsePageLimit(query.limit, 25);
    const offset = parsePageValue(query.offset, 0, Number.MAX_SAFE_INTEGER);
    if (!await repository.findManagedAccount(account.id, id)) {
      throw new AdministrationError('account_not_found', 404);
    }
    const [posts, threads] = await Promise.all([
      forumRepository.listPostsByAccount(account.id, id, limit + 1, offset),
      forumRepository.listTopicsByAccount(account.id, id, Math.min(limit, 25)),
    ]);
    return {
      hasMore: posts.length > limit,
      nextOffset: offset + Math.min(posts.length, limit),
      posts: posts.slice(0, limit),
      threads,
    };
  }

  async function isPresenceCounterEnabled() {
    const settings = await repository.getSiteSettings();
    return settings.presenceCounterEnabled;
  }

  async function getSiteSettings(sessionToken) {
    const { account } = await authService.getSession(sessionToken);
    requirePermission(account, permissions.siteSettingsManage);
    return repository.getSiteSettings();
  }

  async function setSiteSettings(sessionToken, csrfToken, input) {
    const countMode = input.shoutboxVisibilityMode === 'count';
    const timeMode = input.shoutboxVisibilityMode === 'time';
    const hasCount = Object.hasOwn(input, 'shoutboxVisibilityCount');
    const hasDays = Object.hasOwn(input, 'shoutboxVisibilityDays');
    const hasHours = Object.hasOwn(input, 'shoutboxVisibilityHours');
    if (
      typeof input.globalRegistrationTokenEnabled !== 'boolean'
      || typeof input.presenceCounterEnabled !== 'boolean'
      || !shoutboxVisibilityModes.has(input.shoutboxVisibilityMode)
      || hasHours
      || (countMode && (
        !hasCount
        || hasDays
        || !Number.isInteger(input.shoutboxVisibilityCount)
        || input.shoutboxVisibilityCount < 10
        || input.shoutboxVisibilityCount > 200
      ))
      || (timeMode && (
        hasCount
        || !hasDays
        || !Number.isInteger(input.shoutboxVisibilityDays)
        || input.shoutboxVisibilityDays < 1
        || input.shoutboxVisibilityDays > 30
      ))
    ) {
      throw new AdministrationError('invalid_site_settings', 400);
    }
    const session = await authService.getSession(sessionToken);
    await authService.requireCsrf(session, csrfToken);
    requirePermission(session.account, permissions.siteSettingsManage);
    const settings = await repository.updateSiteSettings({
      actorId: session.account.id,
      expectedUpdatedAt: parseExpectedUpdatedAt(
        input.expectedUpdatedAt,
        'invalid_site_settings_version',
      ),
      globalRegistrationTokenEnabled: input.globalRegistrationTokenEnabled,
      presenceCounterEnabled: input.presenceCounterEnabled,
      reason: 'Site settings changed',
      shoutboxVisibilityMode: input.shoutboxVisibilityMode,
      updatedAt: clock(),
      ...(countMode
        ? { shoutboxVisibilityCount: input.shoutboxVisibilityCount }
        : { shoutboxVisibilityHours: input.shoutboxVisibilityDays * 24 }),
    });
    if (settings?.globalTokenMissing) {
      throw new AdministrationError('global_registration_token_missing', 409);
    }
    if (!settings) {
      throw new AdministrationError('site_settings_update_conflict', 409);
    }
    return settings;
  }

  async function issueUsernameColorUnlock(sessionToken, csrfToken) {
    const session = await authService.getSession(sessionToken);
    await authService.requireCsrf(session, csrfToken);
    requirePermission(session.account, permissions.siteSettingsManage);
    const code = unlockCodeFactory();
    const tokenDigest = digestUsernameColorUnlockCode(code);
    const createdAt = clock();
    const expiresAt = new Date(createdAt.getTime() + (30 * 24 * 60 * 60 * 1000));
    await repository.createUsernameColorUnlockCode({
      actorId: session.account.id,
      createdAt,
      expiresAt,
      tokenDigest,
    });
    return { code, expiresAt };
  }

  async function issueRegistrationInvite(sessionToken, csrfToken) {
    const session = await authService.getSession(sessionToken);
    await authService.requireCsrf(session, csrfToken);
    requirePermission(session.account, permissions.siteSettingsManage);
    const token = inviteTokenFactory();
    const tokenLookupDigest = digestRegistrationInviteToken(token);
    const tokenSalt = inviteSaltFactory();
    const tokenVerifier = await inviteVerifierFactory(token, tokenSalt);
    const createdAt = clock();
    await repository.createRegistrationInvite({
      actorId: session.account.id,
      createdAt,
      tokenLookupDigest,
      tokenSalt,
      tokenVerifier,
    });
    return { createdAt, token };
  }

  async function issueGlobalRegistrationToken(sessionToken, csrfToken, input) {
    const session = await authService.getSession(sessionToken);
    await authService.requireCsrf(session, csrfToken);
    requirePermission(session.account, permissions.siteSettingsManage);
    const token = inviteTokenFactory();
    const tokenLookupDigest = digestRegistrationInviteToken(token);
    const tokenSalt = inviteSaltFactory();
    const tokenVerifier = await inviteVerifierFactory(token, tokenSalt);
    const settings = await repository.rotateGlobalRegistrationToken({
      actorId: session.account.id,
      expectedUpdatedAt: parseExpectedUpdatedAt(
        input.expectedUpdatedAt,
        'invalid_site_settings_version',
      ),
      tokenLookupDigest,
      tokenSalt,
      tokenVerifier,
      updatedAt: clock(),
    });
    if (!settings) {
      throw new AdministrationError('site_settings_update_conflict', 409);
    }
    return { settings, token };
  }

  async function runServerDiagnostic(sessionToken, csrfToken, input, { signal } = {}) {
    const keys = input && !Array.isArray(input) ? Object.keys(input).sort() : [];
    const validLag = input?.operation === 'artificial-lag'
      && keys.join(',') === 'delayMs,operation'
      && Number.isInteger(input.delayMs)
      && input.delayMs >= 0
      && input.delayMs <= maximumDiagnosticLagMs;
    const validShoutbox = input?.operation === 'shoutbox-write-load'
      && keys.join(',') === 'loadLimit,operation,writeCount'
      && Number.isInteger(input.writeCount)
      && input.writeCount >= 1
      && input.writeCount <= maximumDiagnosticShoutboxWrites
      && Number.isInteger(input.loadLimit)
      && input.loadLimit >= 1
      && input.loadLimit <= maximumDiagnosticShoutboxLoad;
    const validNotificationPush = input?.operation === 'notification-push'
      && keys.join(',') === 'notificationCount,operation'
      && Number.isInteger(input.notificationCount)
      && input.notificationCount >= 1
      && input.notificationCount <= maximumDiagnosticNotificationCount;
    if (!validLag && !validShoutbox && !validNotificationPush) {
      throw new AdministrationError('invalid_server_diagnostic', 400);
    }
    const session = await authService.getSession(sessionToken);
    await authService.requireCsrf(session, csrfToken);
    requirePermission(session.account, permissions.serverDiagnosticsRun);
    if (diagnosticPending) {
      throw new AdministrationError('server_diagnostic_busy', 409);
    }
    diagnosticPending = true;
    const startedAt = diagnosticNow();
    try {
      let result;
      if (validLag) {
        await diagnosticDelay(input.delayMs, signal);
        result = { completed: true, requestedDelayMs: input.delayMs };
      } else if (validShoutbox) {
        result = await repository.runShoutboxDiagnostic({
          actorId: session.account.id,
          createdAt: clock(),
          loadLimit: input.loadLimit,
          writeCount: input.writeCount,
        });
      } else {
        result = await repository.runNotificationPushDiagnostic({
          actorId: session.account.id,
          createdAt: clock(),
          notificationCount: input.notificationCount,
        });
      }
      if (!result) {
        throw new AdministrationError('server_diagnostic_busy', 409);
      }
      const durationMs = Math.max(0, Math.round(diagnosticNow() - startedAt));
      if (validLag) {
        await repository.recordServerDiagnostic({
          action: 'diagnostic.artificial_lag',
          actorId: session.account.id,
          createdAt: clock(),
          details: { durationMs, requestedDelayMs: input.delayMs },
          reason: 'Artificial lag diagnostic run',
        });
      }
      return {
        durationMs,
        operation: input.operation,
        result,
      };
    } catch (error) {
      if (error?.name === 'AbortError') {
        throw new AdministrationError('server_diagnostic_aborted', 499);
      }
      throw error;
    } finally {
      diagnosticPending = false;
    }
  }

  async function prepareMutation(sessionToken, csrfToken, targetId, input, permission) {
    const session = await authService.getSession(sessionToken);
    await authService.requireCsrf(session, csrfToken);
    requirePermission(session.account, permission);
    const target = await repository.findManagedAccount(
      session.account.id,
      parseTargetId(targetId),
    );
    if (!target) {
      throw new AdministrationError('account_not_found', 404);
    }
    if (target.membershipStatus === 'deleted') {
      throw new AdministrationError('account_already_deleted', 409);
    }
    if (target.id === session.account.id) {
      throw new AdministrationError('self_moderation_denied', 403);
    }
    if (session.account.role === 'moderator' && target.role !== 'member') {
      throw new AdministrationError('moderation_hierarchy_denied', 403);
    }
    return {
      actor: session.account,
      expectedUpdatedAt: parseExpectedUpdatedAt(input.expectedUpdatedAt),
      target,
    };
  }

  async function runMutation(prepared, action, updates, grants) {
    const result = await repository.manageAccount({
      action,
      actorId: prepared.actor.id,
      expectedUpdatedAt: prepared.expectedUpdatedAt,
      grants,
      reason: mutationAuditReasons.get(action),
      targetId: prepared.target.id,
      updatedAt: clock(),
      updates,
    });
    if (result?.lastAdministrator) {
      throw new AdministrationError('last_administrator', 409);
    }
    if (!result?.account) {
      throw new AdministrationError('account_update_conflict', 409);
    }
    return managedAccountProjection(result.account, isAdministrator(prepared.actor));
  }

  async function updateAccount(sessionToken, csrfToken, targetId, input) {
    const allowedFields = new Set([
      'expectedUpdatedAt',
      'forumPostingMuted',
      'membershipStatus',
      'moderatorPermissions',
      'role',
      'shoutboxPostingMuted',
      'slowdownMs',
    ]);
    const changedFields = Object.keys(input).filter((key) => key !== 'expectedUpdatedAt');
    if (
      changedFields.length === 0
      || Object.keys(input).some((key) => !allowedFields.has(key))
      || (Object.hasOwn(input, 'membershipStatus')
        && !managedMembershipStatuses.has(input.membershipStatus))
      || (Object.hasOwn(input, 'slowdownMs')
        && (!Number.isInteger(input.slowdownMs)
          || input.slowdownMs < 0
          || input.slowdownMs > 300_000))
      || (Object.hasOwn(input, 'forumPostingMuted')
        && typeof input.forumPostingMuted !== 'boolean')
      || (Object.hasOwn(input, 'shoutboxPostingMuted')
        && typeof input.shoutboxPostingMuted !== 'boolean')
      || (Object.hasOwn(input, 'role') && !managedRoles.has(input.role))
      || (Object.hasOwn(input, 'moderatorPermissions') && (
        !Array.isArray(input.moderatorPermissions)
        || new Set(input.moderatorPermissions).size !== input.moderatorPermissions.length
        || input.moderatorPermissions.some((permission) => (
          !grantableModeratorPermissions.includes(permission)
        ))
      ))
    ) {
      throw new AdministrationError('invalid_account_update', 400);
    }
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.usersView,
    );
    if (Object.hasOwn(input, 'membershipStatus') || Object.hasOwn(input, 'slowdownMs')) {
      requirePermission(prepared.actor, permissions.usersModerate);
    }
    if (Object.hasOwn(input, 'forumPostingMuted')) {
      requirePermission(prepared.actor, permissions.postsModerate);
    }
    if (Object.hasOwn(input, 'shoutboxPostingMuted')) {
      requirePermission(prepared.actor, permissions.shoutsModerate);
    }
    if (Object.hasOwn(input, 'role')) {
      requirePermission(prepared.actor, permissions.rolesManage);
    }
    if (Object.hasOwn(input, 'moderatorPermissions')) {
      requirePermission(prepared.actor, permissions.moderatorGrantsManage);
      if ((input.role ?? prepared.target.role) !== 'moderator') {
        throw new AdministrationError('moderator_required', 409);
      }
    }
    const updates = Object.fromEntries(changedFields
      .filter((key) => key !== 'moderatorPermissions')
      .map((key) => [key, input[key]]));
    return runMutation(
      prepared,
      'account.update',
      updates,
      Object.hasOwn(input, 'moderatorPermissions') ? input.moderatorPermissions : undefined,
    );
  }

  async function setMembershipStatus(sessionToken, csrfToken, targetId, input) {
    if (!managedMembershipStatuses.has(input.membershipStatus)) {
      throw new AdministrationError('invalid_membership_status', 400);
    }
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.usersModerate,
    );
    return runMutation(prepared, 'account.membership', {
      membershipStatus: input.membershipStatus,
    });
  }

  async function forcePasswordReset(sessionToken, csrfToken, targetId, input) {
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.usersModerate,
    );
    return runMutation(prepared, 'account.force_password_reset', { forcePasswordChange: true });
  }

  async function removeAvatar(sessionToken, csrfToken, targetId, input) {
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.usersModerate,
    );
    const result = await repository.clearAccountAvatar({
      actorId: prepared.actor.id,
      expectedUpdatedAt: prepared.expectedUpdatedAt,
      reason: 'Account avatar removed',
      targetId: prepared.target.id,
      updatedAt: clock(),
    });
    if (!result?.account) {
      throw new AdministrationError('account_update_conflict', 409);
    }
    return managedAccountProjection(result.account, isAdministrator(prepared.actor));
  }

  async function deleteAccount(sessionToken, csrfToken, targetId, input) {
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.accountsDelete,
    );
    return runMutation(prepared, 'account.delete', {
      deletedAt: clock(),
      membershipStatus: 'deleted',
    });
  }

  async function setRole(sessionToken, csrfToken, targetId, input) {
    if (!managedRoles.has(input.role)) {
      throw new AdministrationError('invalid_role', 400);
    }
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.rolesManage,
    );
    return runMutation(prepared, 'account.role', { role: input.role });
  }

  async function setModeratorGrants(sessionToken, csrfToken, targetId, input) {
    if (
      !Array.isArray(input.permissions)
      || new Set(input.permissions).size !== input.permissions.length
      || input.permissions.some((permission) => !grantableModeratorPermissions.includes(permission))
    ) {
      throw new AdministrationError('invalid_moderator_grants', 400);
    }
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.moderatorGrantsManage,
    );
    if (prepared.target.role !== 'moderator') {
      throw new AdministrationError('moderator_required', 409);
    }
    return runMutation(prepared, 'account.moderator_grants', {}, input.permissions);
  }

  async function setSlowdown(sessionToken, csrfToken, targetId, input) {
    if (!Number.isInteger(input.slowdownMs) || input.slowdownMs < 0 || input.slowdownMs > 300_000) {
      throw new AdministrationError('invalid_slowdown', 400);
    }
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.usersModerate,
    );
    return runMutation(prepared, 'account.slowdown', { slowdownMs: input.slowdownMs });
  }

  async function setForumPostingMute(sessionToken, csrfToken, targetId, input) {
    if (typeof input.muted !== 'boolean') {
      throw new AdministrationError('invalid_forum_posting_mute', 400);
    }
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.postsModerate,
    );
    return runMutation(prepared, 'account.forum_posting_mute', {
      forumPostingMuted: input.muted,
    });
  }

  async function setShoutboxPostingMute(sessionToken, csrfToken, targetId, input) {
    if (typeof input.muted !== 'boolean') {
      throw new AdministrationError('invalid_shoutbox_posting_mute', 400);
    }
    const prepared = await prepareMutation(
      sessionToken,
      csrfToken,
      targetId,
      input,
      permissions.shoutsModerate,
    );
    return runMutation(prepared, 'account.shoutbox_posting_mute', {
      shoutboxPostingMuted: input.muted,
    });
  }

  return {
    deleteAccount,
    forcePasswordReset,
    getSiteSettings,
    issueGlobalRegistrationToken,
    issueRegistrationInvite,
    issueUsernameColorUnlock,
    isPresenceCounterEnabled,
    listAccounts,
    listAudit,
    listAuthenticationAudit,
    listContent,
    removeAvatar,
    runServerDiagnostic,
    setMembershipStatus,
    setForumPostingMute,
    setModeratorGrants,
    setRole,
    setSiteSettings,
    setSlowdown,
    setShoutboxPostingMute,
    updateAccount,
  };
}