function mapTopic(row) {
  return {
    author: row.display_name,
    authorId: row.author_account_id,
    authorUsername: row.username,
    createdAt: row.created_at,
    id: String(row.id),
    lastActivityAt: row.last_activity_at ?? row.updated_at,
    locked: row.locked,
    postCount: Number(row.post_count ?? 0),
    ...(row.subscribed === undefined ? {} : { subscribed: Boolean(row.subscribed) }),
    title: row.title,
    updatedAt: row.updated_at,
    usernameColor: row.username_color,
    usernameColorEffect: row.username_color_effect ?? 'none',
  };
}

function mapPost(row) {
  return {
    author: row.display_name,
    authorId: row.author_account_id,
    authorUsername: row.username,
    avatarContentType: row.avatar_updated_at ? row.avatar_content_type : null,
    avatarUrl: row.avatar_updated_at
      ? `/api/avatars/${row.author_account_id}?v=${new Date(row.avatar_updated_at).getTime()}`
      : null,
    ...(row.attachments === undefined ? {} : { attachments: row.attachments }),
    body: row.deleted_at ? null : row.body,
    createdAt: row.created_at,
    deleted: Boolean(row.deleted_at),
    id: String(row.id),
    mentionUsernames: row.mention_usernames ?? [],
    topicId: String(row.topic_id),
    topicTitle: row.topic_title,
    updatedAt: row.updated_at,
    usernameColor: row.username_color,
    usernameColorEffect: row.username_color_effect ?? 'none',
  };
}

function mapAttachment(row, includeData = false) {
  return {
    contentType: row.content_type,
    createdAt: row.created_at,
    ...(includeData ? { data: row.data } : {}),
    id: String(row.id),
    name: row.file_name,
    postId: String(row.post_id),
    size: Number(row.byte_size),
    url: `/api/attachments/${row.id}`,
  };
}

function mapSearchResult(row) {
  return {
    excerpt: row.excerpt,
    kind: row.kind,
    post: row.post_id ? {
      author: row.post_author,
      authorId: row.post_author_account_id,
      authorUsername: row.post_author_username,
      createdAt: row.post_created_at,
      id: String(row.post_id),
      topicId: String(row.topic_id),
      usernameColor: row.post_username_color,
      usernameColorEffect: row.post_username_color_effect ?? 'none',
    } : null,
    postOffset: Number(row.post_offset),
    topic: {
      author: row.topic_author,
      authorId: row.topic_author_account_id,
      authorUsername: row.topic_author_username,
      createdAt: row.topic_created_at,
      id: String(row.topic_id),
      locked: row.locked,
      title: row.title,
      updatedAt: row.topic_updated_at,
      usernameColor: row.topic_username_color,
      usernameColorEffect: row.topic_username_color_effect ?? 'none',
    },
  };
}

function postAttachmentAuthorization(post, accountId, moderator, ownerEditCutoff) {
  if (!post || post.topic_deleted_at) {
    return 'not_found';
  }
  const threadOwner = post.topic_author_account_id === accountId && !post.topic_locked;
  const ownerWithinWindow = post.author_account_id === accountId
    && !post.topic_locked
    && new Date(post.created_at).getTime() >= ownerEditCutoff.getTime();
  return moderator || threadOwner || ownerWithinWindow ? 'ok' : 'denied';
}

export function createForumRepository(pool) {
  async function withTransaction(operation) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await operation(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async function selectPost(queryable, postId) {
    const result = await queryable.query(
      `SELECT posts.*, topics.title AS topic_title, accounts.display_name,
        accounts.username, accounts.username_color, accounts.username_color_effect,
        accounts.avatar_content_type,
        accounts.avatar_updated_at,
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object(
            'contentType', post_attachments.content_type,
            'createdAt', post_attachments.created_at,
            'id', post_attachments.id::text,
            'name', post_attachments.file_name,
            'postId', post_attachments.post_id::text,
            'size', post_attachments.byte_size,
            'url', '/api/attachments/' || post_attachments.id::text
          ) ORDER BY post_attachments.id)
          FROM post_attachments WHERE post_attachments.post_id = posts.id
        ), '[]'::jsonb) AS attachments,
        ARRAY(
          SELECT mentioned.username
          FROM post_mentions
          JOIN accounts mentioned ON mentioned.id = post_mentions.mentioned_account_id
          WHERE post_mentions.post_id = posts.id
            AND mentioned.membership_status = 'active'
            AND mentioned.deleted_at IS NULL
          ORDER BY mentioned.normalized_username
        ) AS mention_usernames
       FROM posts
       JOIN topics ON topics.id = posts.topic_id
       JOIN accounts ON accounts.id = posts.author_account_id
       WHERE posts.id = $1`,
      [postId],
    );
    return result.rows[0] ? mapPost(result.rows[0]) : null;
  }

  async function syncPostMentions(client, actorId, postId, topicId, mentions) {
    await client.query(
      `WITH resolved_mentions AS (
         SELECT id FROM accounts
         WHERE normalized_username = ANY($1::text[])
           AND id <> $2
           AND membership_status = 'active'
           AND deleted_at IS NULL
       ), removed_mentions AS (
         DELETE FROM post_mentions
         WHERE post_id = $3
           AND mentioned_account_id NOT IN (SELECT id FROM resolved_mentions)
       ), inserted_mentions AS (
         INSERT INTO post_mentions (post_id, mentioned_account_id)
         SELECT $3, id FROM resolved_mentions
         ON CONFLICT DO NOTHING
         RETURNING mentioned_account_id
       )
       INSERT INTO notifications (account_id, message, href)
       SELECT inserted_mentions.mentioned_account_id,
         actor.username || ' mentioned you in a forum post',
         '/?topic=' || $4::text
       FROM inserted_mentions
       JOIN accounts actor ON actor.id = $2`,
      [mentions, actorId, postId, topicId],
    );
  }

  async function notifyTopicSubscribers(client, actorId, postId, topicId) {
    await client.query(
      `INSERT INTO notifications (account_id, message, href)
       SELECT topic_subscriptions.account_id,
         actor.username || ' replied to ' || topics.title,
         '/?topic=' || topics.id::text
       FROM topic_subscriptions
       JOIN topics ON topics.id = topic_subscriptions.topic_id
       JOIN accounts subscribers ON subscribers.id = topic_subscriptions.account_id
       JOIN accounts actor ON actor.id = $1
       WHERE topic_subscriptions.topic_id = $3
         AND topic_subscriptions.account_id <> $1
         AND subscribers.membership_status = 'active'
         AND subscribers.deleted_at IS NULL
         AND NOT EXISTS (
           SELECT 1 FROM post_mentions
           WHERE post_mentions.post_id = $2
             AND post_mentions.mentioned_account_id = topic_subscriptions.account_id
         )`,
      [actorId, postId, topicId],
    );
  }

  return {
    async authorizePostAttachment({ accountId, moderator, ownerEditCutoff, postId }) {
      const result = await pool.query(
        `SELECT posts.author_account_id, posts.created_at,
           topics.author_account_id AS topic_author_account_id,
           topics.deleted_at AS topic_deleted_at, topics.locked AS topic_locked
         FROM posts JOIN topics ON topics.id = posts.topic_id
         WHERE posts.id = $1 AND posts.deleted_at IS NULL`,
        [postId],
      );
      return { status: postAttachmentAuthorization(
        result.rows[0],
        accountId,
        moderator,
        ownerEditCutoff,
      ) };
    },
    async createPostAttachment({
      accountId,
      contentType,
      data,
      fileName,
      maximumCount,
      moderator,
      ownerEditCutoff,
      postId,
      quotaBytes,
    }) {
      return withTransaction(async (client) => {
        await client.query('SELECT id FROM accounts WHERE id = $1 FOR UPDATE', [accountId]);
        const postResult = await client.query(
          `SELECT posts.author_account_id, posts.created_at,
             topics.author_account_id AS topic_author_account_id,
             topics.deleted_at AS topic_deleted_at, topics.locked AS topic_locked
           FROM posts JOIN topics ON topics.id = posts.topic_id
           WHERE posts.id = $1 AND posts.deleted_at IS NULL
           FOR UPDATE OF topics, posts`,
          [postId],
        );
        const post = postResult.rows[0];
        const authorization = postAttachmentAuthorization(
          post,
          accountId,
          moderator,
          ownerEditCutoff,
        );
        if (authorization !== 'ok') {
          return { status: authorization };
        }
        const usageResult = await client.query(
          `SELECT
             (SELECT count(*) FROM post_attachments WHERE post_id = $1) AS post_count,
             (SELECT COALESCE(sum(byte_size), 0) FROM post_attachments
              WHERE uploader_account_id = $2) AS account_bytes`,
          [postId, accountId],
        );
        if (Number(usageResult.rows[0].post_count) >= maximumCount) {
          return { status: 'limit' };
        }
        if (Number(usageResult.rows[0].account_bytes) + data.length > quotaBytes) {
          return { status: 'quota' };
        }
        const inserted = await client.query(
          `INSERT INTO post_attachments (
             post_id, uploader_account_id, file_name, content_type, byte_size, data
           ) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
          [postId, accountId, fileName, contentType, data.length, data],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'post.attachment.create', 'Post attachment added',
             jsonb_build_object(
               'attachmentId', $3::text, 'postId', $4::text,
               'contentType', $5::text, 'byteSize', $6::integer
             ))`,
          [
            accountId,
            post.author_account_id,
            inserted.rows[0].id,
            postId,
            contentType,
            data.length,
          ],
        );
        return { attachment: mapAttachment(inserted.rows[0]), status: 'ok' };
      });
    },
    async deletePostAttachment({
      accountId,
      attachmentId,
      moderator,
      ownerEditCutoff,
      reason,
    }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT post_attachments.*, posts.author_account_id,
             posts.created_at AS post_created_at,
             topics.author_account_id AS topic_author_account_id,
             topics.deleted_at AS topic_deleted_at, topics.locked AS topic_locked
           FROM post_attachments
           JOIN posts ON posts.id = post_attachments.post_id
           JOIN topics ON topics.id = posts.topic_id
           WHERE post_attachments.id = $1 AND posts.deleted_at IS NULL
           FOR UPDATE OF post_attachments, posts, topics`,
          [attachmentId],
        );
        const current = currentResult.rows[0];
        if (!current || current.topic_deleted_at) {
          return { status: 'not_found' };
        }
        const threadOwner = current.topic_author_account_id === accountId && !current.topic_locked;
        const ownerWithinWindow = current.author_account_id === accountId
          && !current.topic_locked
          && new Date(current.post_created_at).getTime() >= ownerEditCutoff.getTime();
        if (!moderator && !threadOwner && !ownerWithinWindow) {
          return { status: 'denied' };
        }
        const auditReason = moderator
          ? reason
          : threadOwner && current.author_account_id !== accountId
            ? 'Thread owner attachment removal'
            : 'Author attachment removal';
        await client.query('DELETE FROM post_attachments WHERE id = $1', [attachmentId]);
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'post.attachment.delete', $3, jsonb_build_object(
             'attachmentId', $4::text, 'postId', $5::text,
             'contentType', $6::text, 'byteSize', $7::integer
           ))`,
          [
            accountId,
            current.author_account_id,
            auditReason,
            attachmentId,
            current.post_id,
            current.content_type,
            current.byte_size,
          ],
        );
        return { attachment: mapAttachment(current), status: 'ok' };
      });
    },
    async getPostAttachment(attachmentId) {
      const result = await pool.query(
        `SELECT post_attachments.* FROM post_attachments
         JOIN posts ON posts.id = post_attachments.post_id
         JOIN topics ON topics.id = posts.topic_id
         WHERE post_attachments.id = $1
           AND posts.deleted_at IS NULL AND topics.deleted_at IS NULL`,
        [attachmentId],
      );
      return result.rows[0] ? mapAttachment(result.rows[0], true) : null;
    },
    async createTopic(accountId, title, body, mentions) {
      return withTransaction(async (client) => {
        const topicResult = await client.query(
          `INSERT INTO topics (author_account_id, title) VALUES ($1, $2) RETURNING *`,
          [accountId, title],
        );
        const postResult = await client.query(
          `INSERT INTO posts (topic_id, author_account_id, body)
           VALUES ($1, $2, $3) RETURNING id`,
          [topicResult.rows[0].id, accountId, body],
        );
        await client.query(
          `INSERT INTO topic_subscriptions (account_id, topic_id) VALUES ($1, $2)`,
          [accountId, topicResult.rows[0].id],
        );
        await syncPostMentions(
          client,
          accountId,
          postResult.rows[0].id,
          topicResult.rows[0].id,
          mentions,
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES
             ($1, $1, 'topic.create', 'Topic created',
               jsonb_build_object('topicId', $2::text)),
             ($1, $1, 'post.create', 'Post created',
               jsonb_build_object('postId', $3::text, 'topicId', $2::text))`,
          [accountId, topicResult.rows[0].id, postResult.rows[0].id],
        );
        const post = await selectPost(client, postResult.rows[0].id);
        return { post, topic: { ...mapTopic(topicResult.rows[0]), subscribed: true } };
      });
    },
    async createPost(accountId, topicId, body, mentions) {
      return withTransaction(async (client) => {
        const result = await client.query(
          `WITH inserted AS (
             INSERT INTO posts (topic_id, author_account_id, body)
             SELECT id, $1, $3 FROM topics
             WHERE id = $2 AND locked = false AND deleted_at IS NULL
             RETURNING id, topic_id
           )
           UPDATE topics SET updated_at = now()
           FROM inserted WHERE topics.id = inserted.topic_id
           RETURNING inserted.id`,
          [accountId, topicId, body],
        );
        if (!result.rows[0]) {
          return null;
        }
        await syncPostMentions(client, accountId, result.rows[0].id, topicId, mentions);
        await notifyTopicSubscribers(client, accountId, result.rows[0].id, topicId);
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $1, 'post.create', 'Post created', jsonb_build_object(
             'postId', $2::text, 'topicId', $3::text
           ))`,
          [accountId, result.rows[0].id, topicId],
        );
        return selectPost(client, result.rows[0].id);
      });
    },
    async deletePost({ actorId, deletedAt, moderator, ownerEditCutoff, postId, reason }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT posts.*, topics.author_account_id AS topic_author_account_id,
             topics.deleted_at AS topic_deleted_at, topics.locked AS topic_locked
           FROM posts JOIN topics ON topics.id = posts.topic_id
           WHERE posts.id = $1 AND posts.deleted_at IS NULL
           FOR UPDATE OF topics, posts`,
          [postId],
        );
        const current = currentResult.rows[0];
        if (!current) {
          return { status: 'not_found' };
        }
        const threadOwner = current.topic_author_account_id === actorId && !current.topic_locked;
        const ownerWithinWindow = current.author_account_id === actorId
          && !current.topic_locked
          && !current.topic_deleted_at
          && new Date(current.created_at).getTime() >= ownerEditCutoff.getTime();
        if (!moderator && !threadOwner && !ownerWithinWindow) {
          return { status: 'denied' };
        }
        const auditReason = moderator
          ? reason
          : threadOwner && current.author_account_id !== actorId
            ? 'Thread owner deletion'
            : 'Author deletion';
        await client.query(
          `INSERT INTO post_revisions (post_id, editor_account_id, body, reason)
           VALUES ($1, $2, $3, $4)`,
          [postId, actorId, current.body, auditReason],
        );
        await client.query(
          `UPDATE posts SET deleted_at = $2, updated_at = $2 WHERE id = $1`,
          [postId, deletedAt],
        );
        await client.query('DELETE FROM post_attachments WHERE post_id = $1', [postId]);
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'post.delete', $3, jsonb_build_object(
             'postId', $4::text, 'topicId', $5::text
           ))`,
          [actorId, current.author_account_id, auditReason, postId, current.topic_id],
        );
        return { post: await selectPost(client, postId), status: 'ok' };
      });
    },
    async editPost({
      actorId,
      body,
      expectedUpdatedAt,
      mentions,
      moderator,
      ownerEditCutoff,
      postId,
      reason,
      updatedAt,
    }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT posts.*, topics.author_account_id AS topic_author_account_id,
             topics.deleted_at AS topic_deleted_at, topics.locked AS topic_locked
           FROM posts JOIN topics ON topics.id = posts.topic_id
           WHERE posts.id = $1 AND posts.deleted_at IS NULL
           FOR UPDATE OF topics, posts`,
          [postId],
        );
        const current = currentResult.rows[0];
        if (!current) {
          return { status: 'not_found' };
        }
        const threadOwner = current.topic_author_account_id === actorId && !current.topic_locked;
        const ownerWithinWindow = current.author_account_id === actorId
          && !current.topic_locked
          && !current.topic_deleted_at
          && new Date(current.created_at).getTime() >= ownerEditCutoff.getTime();
        if (!moderator && !threadOwner && !ownerWithinWindow) {
          return { status: 'denied' };
        }
        if (new Date(current.updated_at).getTime() !== expectedUpdatedAt.getTime()) {
          return { status: 'conflict' };
        }
        const auditReason = moderator
          ? reason
          : threadOwner && current.author_account_id !== actorId
            ? 'Thread owner edit'
            : 'Author edit';
        await client.query(
          `INSERT INTO post_revisions (post_id, editor_account_id, body, reason)
           VALUES ($1, $2, $3, $4)`,
          [postId, actorId, current.body, auditReason],
        );
        await client.query(
          `UPDATE posts SET body = $2, updated_at = $3 WHERE id = $1`,
          [postId, body, updatedAt],
        );
        await syncPostMentions(client, actorId, postId, current.topic_id, mentions);
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'post.edit', $3, jsonb_build_object(
             'postId', $4::text, 'topicId', $5::text
           ))`,
          [actorId, current.author_account_id, auditReason, postId, current.topic_id],
        );
        return { post: await selectPost(client, postId), status: 'ok' };
      });
    },
    async editTopic({ actorId, expectedUpdatedAt, moderator, reason, title, topicId, updatedAt }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT * FROM topics WHERE id = $1 AND deleted_at IS NULL FOR UPDATE`,
          [topicId],
        );
        const current = currentResult.rows[0];
        if (!current) {
          return { status: 'not_found' };
        }
        if (!moderator && (current.author_account_id !== actorId || current.locked)) {
          return { status: 'denied' };
        }
        if (new Date(current.updated_at).getTime() !== expectedUpdatedAt.getTime()) {
          return { status: 'conflict' };
        }
        const auditReason = moderator ? reason : 'Thread owner edit';
        const result = await client.query(
          `UPDATE topics SET title = $2, updated_at = $3 WHERE id = $1 RETURNING *`,
          [topicId, title, updatedAt],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'topic.edit', $3, jsonb_build_object(
             'topicId', $4::text, 'previousTitle', $5::text, 'title', $6::text
           ))`,
          [actorId, current.author_account_id, auditReason, topicId, current.title, title],
        );
        return { status: 'ok', topic: mapTopic(result.rows[0]) };
      });
    },
    async getTopic(topicId, accountId, limit, offset) {
      const topicResult = await pool.query(
        `SELECT topics.*, accounts.display_name, accounts.username, accounts.username_color,
          accounts.username_color_effect,
          EXISTS (
            SELECT 1 FROM topic_subscriptions
            WHERE topic_subscriptions.topic_id = topics.id
              AND topic_subscriptions.account_id = $2
          ) AS subscribed
         FROM topics JOIN accounts ON accounts.id = topics.author_account_id
         WHERE topics.id = $1 AND topics.deleted_at IS NULL`,
        [topicId, accountId],
      );
      if (!topicResult.rows[0]) {
        return null;
      }
      const postsResult = await pool.query(
        `SELECT posts.*, accounts.display_name, accounts.username, accounts.username_color,
          accounts.username_color_effect,
          accounts.avatar_content_type, accounts.avatar_updated_at,
          COALESCE((
            SELECT jsonb_agg(jsonb_build_object(
              'contentType', post_attachments.content_type,
              'createdAt', post_attachments.created_at,
              'id', post_attachments.id::text,
              'name', post_attachments.file_name,
              'postId', post_attachments.post_id::text,
              'size', post_attachments.byte_size,
              'url', '/api/attachments/' || post_attachments.id::text
            ) ORDER BY post_attachments.id)
            FROM post_attachments WHERE post_attachments.post_id = posts.id
          ), '[]'::jsonb) AS attachments,
          ARRAY(
            SELECT mentioned.username
            FROM post_mentions
            JOIN accounts mentioned ON mentioned.id = post_mentions.mentioned_account_id
            WHERE post_mentions.post_id = posts.id
              AND mentioned.membership_status = 'active'
              AND mentioned.deleted_at IS NULL
            ORDER BY mentioned.normalized_username
          ) AS mention_usernames
         FROM posts JOIN accounts ON accounts.id = posts.author_account_id
         WHERE posts.topic_id = $1
         ORDER BY posts.created_at, posts.id LIMIT $2 OFFSET $3`,
        [topicId, limit, offset],
      );
      return { posts: postsResult.rows.map(mapPost), topic: mapTopic(topicResult.rows[0]) };
    },
    async setTopicSubscription(accountId, topicId, subscribed) {
      const action = subscribed ? 'topic.subscribe' : 'topic.unsubscribe';
      const reason = subscribed ? 'Topic subscribed' : 'Topic unsubscribed';
      const statement = subscribed
        ? `WITH available_topic AS (
             SELECT id FROM topics WHERE id = $2 AND deleted_at IS NULL
           ), changed AS (
             INSERT INTO topic_subscriptions (account_id, topic_id)
             SELECT $1, id FROM available_topic
             ON CONFLICT DO NOTHING
             RETURNING topic_id
           ), audit_event AS (
             INSERT INTO moderation_audit_events (
               actor_account_id, target_account_id, action, reason, details
             )
             SELECT $1, $1, $3, $4, jsonb_build_object(
               'topicId', $2::text,
               'after', jsonb_build_object('subscribed', $5::boolean),
               'before', jsonb_build_object('subscribed', NOT $5::boolean)
             ) FROM changed
             RETURNING id
           )
           SELECT EXISTS (SELECT 1 FROM available_topic) AS available,
             EXISTS (SELECT 1 FROM audit_event) AS audited`
        : `WITH available_topic AS (
             SELECT id FROM topics WHERE id = $2 AND deleted_at IS NULL
           ), changed AS (
             DELETE FROM topic_subscriptions
             USING available_topic
             WHERE topic_subscriptions.account_id = $1
               AND topic_subscriptions.topic_id = available_topic.id
             RETURNING topic_subscriptions.topic_id
           ), audit_event AS (
             INSERT INTO moderation_audit_events (
               actor_account_id, target_account_id, action, reason, details
             )
             SELECT $1, $1, $3, $4, jsonb_build_object(
               'topicId', $2::text,
               'after', jsonb_build_object('subscribed', $5::boolean),
               'before', jsonb_build_object('subscribed', NOT $5::boolean)
             ) FROM changed
             RETURNING id
           )
           SELECT EXISTS (SELECT 1 FROM available_topic) AS available,
             EXISTS (SELECT 1 FROM audit_event) AS audited`;
      const result = await pool.query(statement, [accountId, topicId, action, reason, subscribed]);
      return result.rows[0]?.available ? { subscribed } : null;
    },
    async listPostsByAccount(accountId, limit, offset) {
      const result = await pool.query(
        `SELECT posts.*, topics.title AS topic_title, accounts.display_name,
          accounts.username, accounts.username_color, accounts.username_color_effect,
          accounts.avatar_content_type,
          accounts.avatar_updated_at,
          COALESCE((
            SELECT jsonb_agg(jsonb_build_object(
              'contentType', post_attachments.content_type,
              'createdAt', post_attachments.created_at,
              'id', post_attachments.id::text,
              'name', post_attachments.file_name,
              'postId', post_attachments.post_id::text,
              'size', post_attachments.byte_size,
              'url', '/api/attachments/' || post_attachments.id::text
            ) ORDER BY post_attachments.id)
            FROM post_attachments WHERE post_attachments.post_id = posts.id
          ), '[]'::jsonb) AS attachments,
          ARRAY(
            SELECT mentioned.username
            FROM post_mentions
            JOIN accounts mentioned ON mentioned.id = post_mentions.mentioned_account_id
            WHERE post_mentions.post_id = posts.id
              AND mentioned.membership_status = 'active'
              AND mentioned.deleted_at IS NULL
            ORDER BY mentioned.normalized_username
          ) AS mention_usernames
         FROM posts
         JOIN topics ON topics.id = posts.topic_id
         JOIN accounts ON accounts.id = posts.author_account_id
         WHERE posts.author_account_id = $1
           AND posts.deleted_at IS NULL
           AND topics.deleted_at IS NULL
         ORDER BY posts.created_at DESC, posts.id DESC LIMIT $2 OFFSET $3`,
        [accountId, limit, offset],
      );
      return result.rows.map(mapPost);
    },
    async listTopicsByAccount(accountId, limit) {
      const result = await pool.query(
        `SELECT topics.*, accounts.display_name, accounts.username, accounts.username_color,
          accounts.username_color_effect,
          count(posts.id) FILTER (WHERE posts.deleted_at IS NULL) AS post_count,
          COALESCE(max(posts.updated_at) FILTER (WHERE posts.deleted_at IS NULL), topics.updated_at)
            AS last_activity_at
         FROM topics
         JOIN accounts ON accounts.id = topics.author_account_id
         LEFT JOIN posts ON posts.topic_id = topics.id
         WHERE topics.author_account_id = $1 AND topics.deleted_at IS NULL
         GROUP BY topics.id, accounts.display_name, accounts.username,
           accounts.username_color, accounts.username_color_effect
         ORDER BY topics.created_at DESC, topics.id DESC LIMIT $2`,
        [accountId, limit],
      );
      return result.rows.map(mapTopic);
    },
    async listTopics(limit, offset) {
      const result = await pool.query(
        `SELECT topics.*, accounts.display_name, accounts.username, accounts.username_color,
          accounts.username_color_effect,
          count(posts.id) FILTER (WHERE posts.deleted_at IS NULL) AS post_count,
          COALESCE(max(posts.updated_at) FILTER (WHERE posts.deleted_at IS NULL), topics.updated_at)
            AS last_activity_at
         FROM topics
         JOIN accounts ON accounts.id = topics.author_account_id
         LEFT JOIN posts ON posts.topic_id = topics.id
         WHERE topics.deleted_at IS NULL
         GROUP BY topics.id, accounts.display_name, accounts.username,
           accounts.username_color, accounts.username_color_effect
         ORDER BY last_activity_at DESC, topics.id DESC LIMIT $1 OFFSET $2`,
        [limit, offset],
      );
      return result.rows.map(mapTopic);
    },
    async searchContent(query, limit, offset) {
      const result = await pool.query(
        `WITH search_query AS (
           SELECT plainto_tsquery('simple', $1) AS value
         ), matches AS (
           SELECT 'topic'::text AS kind, topics.id AS topic_id, NULL::bigint AS post_id,
             topics.title, topics.author_account_id AS topic_author_account_id,
             topic_authors.display_name AS topic_author,
             topic_authors.username AS topic_author_username,
             topic_authors.username_color AS topic_username_color,
             topic_authors.username_color_effect AS topic_username_color_effect,
             topics.created_at AS topic_created_at, topics.updated_at AS topic_updated_at,
             topics.locked, left(topics.title, 240) AS excerpt,
             NULL::uuid AS post_author_account_id, NULL::text AS post_author,
             NULL::text AS post_author_username, NULL::text AS post_username_color,
             NULL::text AS post_username_color_effect,
             NULL::timestamptz AS post_created_at, 0::bigint AS post_offset,
             ts_rank(to_tsvector('simple', topics.title), search_query.value) AS rank,
             topics.updated_at AS matched_at
           FROM topics
           JOIN accounts topic_authors ON topic_authors.id = topics.author_account_id
           CROSS JOIN search_query
           WHERE topics.deleted_at IS NULL
             AND to_tsvector('simple', topics.title) @@ search_query.value
           UNION ALL
           SELECT 'post'::text AS kind, topics.id AS topic_id, posts.id AS post_id,
             topics.title, topics.author_account_id AS topic_author_account_id,
             topic_authors.display_name AS topic_author,
             topic_authors.username AS topic_author_username,
             topic_authors.username_color AS topic_username_color,
             topic_authors.username_color_effect AS topic_username_color_effect,
             topics.created_at AS topic_created_at, topics.updated_at AS topic_updated_at,
             topics.locked, left(posts.body, 240) AS excerpt,
             posts.author_account_id AS post_author_account_id,
             post_authors.display_name AS post_author,
             post_authors.username AS post_author_username,
             post_authors.username_color AS post_username_color,
             post_authors.username_color_effect AS post_username_color_effect,
             posts.created_at AS post_created_at,
             (SELECT count(*) FROM posts earlier_posts
              WHERE earlier_posts.topic_id = posts.topic_id
                AND (earlier_posts.created_at, earlier_posts.id)
                  < (posts.created_at, posts.id)) AS post_offset,
             ts_rank(to_tsvector('simple', posts.body), search_query.value) AS rank,
             posts.updated_at AS matched_at
           FROM posts
           JOIN topics ON topics.id = posts.topic_id
           JOIN accounts topic_authors ON topic_authors.id = topics.author_account_id
           JOIN accounts post_authors ON post_authors.id = posts.author_account_id
           CROSS JOIN search_query
           WHERE posts.deleted_at IS NULL
             AND topics.deleted_at IS NULL
             AND to_tsvector('simple', posts.body) @@ search_query.value
         )
         SELECT * FROM matches
         ORDER BY rank DESC, matched_at DESC, topic_id DESC, post_id DESC NULLS LAST
         LIMIT $2 OFFSET $3`,
        [query, limit, offset],
      );
      return result.rows.map(mapSearchResult);
    },
    async deleteTopic({ actorId, deletedAt, moderator, reason, topicId }) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT * FROM topics WHERE id = $1 AND deleted_at IS NULL FOR UPDATE`,
          [topicId],
        );
        const current = currentResult.rows[0];
        if (!current) {
          return { status: 'not_found' };
        }
        if (!moderator && (current.author_account_id !== actorId || current.locked)) {
          return { status: 'denied' };
        }
        const auditReason = moderator ? reason : 'Thread owner deletion';
        const result = await client.query(
          `UPDATE topics SET deleted_at = $2, updated_at = $2 WHERE id = $1 RETURNING *`,
          [topicId, deletedAt],
        );
        await client.query(
          `DELETE FROM post_attachments USING posts
           WHERE post_attachments.post_id = posts.id AND posts.topic_id = $1`,
          [topicId],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, 'topic.delete', $3, jsonb_build_object(
             'topicId', $4::text, 'title', $5::text
           ))`,
          [actorId, current.author_account_id, auditReason, topicId, current.title],
        );
        return { status: 'ok', topic: mapTopic(result.rows[0]) };
      });
    },
    async setTopicLocked(topicId, locked, actorId, updatedAt) {
      return withTransaction(async (client) => {
        const result = await client.query(
          `UPDATE topics SET locked = $2, updated_at = $3
           WHERE id = $1 AND deleted_at IS NULL RETURNING *`,
          [topicId, locked, updatedAt],
        );
        if (!result.rows[0]) {
          return null;
        }
        await client.query(
          `INSERT INTO moderation_audit_events (
             actor_account_id, target_account_id, action, reason, details
           ) VALUES ($1, $2, $3, $4, jsonb_build_object('topicId', $5::text))`,
          [
            actorId,
            result.rows[0].author_account_id,
            locked ? 'topic.lock' : 'topic.unlock',
            'Topic lock changed',
            topicId,
          ],
        );
        return mapTopic(result.rows[0]);
      });
    },
  };
}