import { isValidUsername, normalizeUsername } from './username.js';
import { stripHtmlTags } from './authored-text.js';
import {
  digestUsernameColorUnlockCode,
  usernameColorEffects,
} from './username-color-effects.js';

const profileActivityLimit = 10;
const mentionUsernameLimit = 10;
const mentionUsernamePrefixPattern = /^(?=.{1,32}$)[a-z0-9][a-z0-9_-]*(?: [a-z0-9_-]+)?$/;
const usernameColors = new Set(['default', 'forest', 'red', 'blue', 'gold', 'teal']);
const usernameHexColorPattern = /^#[0-9a-f]{6}$/i;
const usernameColorEffectSet = new Set(usernameColorEffects);

export class ProfileError extends Error {
  constructor(code, statusCode) {
    super(code);
    this.code = code;
    this.statusCode = statusCode;
  }
}

function validateDescription(value) {
  if (typeof value !== 'string') {
    throw new ProfileError('invalid_profile_description', 400);
  }
  const description = stripHtmlTags(value).trim();
  if (description.length > 500) {
    throw new ProfileError('invalid_profile_description', 400);
  }
  return description;
}

function validateUsernameColor(value) {
  if (usernameColors.has(value)) {
    return value;
  }
  if (typeof value !== 'string' || !usernameHexColorPattern.test(value)) {
    throw new ProfileError('invalid_username_color', 400);
  }
  return value.toLowerCase();
}

function validateUsernameColorEffect(value) {
  if (!usernameColorEffectSet.has(value)) {
    throw new ProfileError('invalid_username_color_effect', 400);
  }
  return value;
}

export function createProfileService({ authService, forumRepository, repository }) {
  async function searchMentionUsernames(sessionToken, prefix) {
    const session = await authService.getSession(sessionToken);
    const normalizedPrefix = normalizeUsername(prefix);
    if (!mentionUsernamePrefixPattern.test(normalizedPrefix)) {
      throw new ProfileError('invalid_username_prefix', 400);
    }
    const usernames = await repository.searchActiveUsernamesByPrefix(
      normalizedPrefix,
      session.account.id,
      mentionUsernameLimit,
    );
    return { usernames };
  }

  async function findProfile(sessionToken, username) {
    const session = await authService.getSession(sessionToken);
    const normalizedUsername = normalizeUsername(username);
    if (!isValidUsername(username)) {
      throw new ProfileError('profile_not_found', 404);
    }
    const profile = await repository.findPublicProfileByUsername(
      normalizedUsername,
      session.account.id,
    );
    if (!profile) {
      throw new ProfileError('profile_not_found', 404);
    }
    return { normalizedUsername, profile, session };
  }

  async function getProfile(sessionToken, username) {
    const { profile } = await findProfile(sessionToken, username);
    const [recentThreads, recentPosts] = await Promise.all([
      forumRepository.listTopicsByAccount(profile.id, profileActivityLimit),
      forumRepository.listPostsByAccount(profile.id, profileActivityLimit, 0),
    ]);
    return { profile, recentPosts, recentThreads };
  }

  async function setFollowing(sessionToken, csrfToken, username, following) {
    if (typeof following !== 'boolean') {
      throw new ProfileError('invalid_follow_state', 400);
    }
    const { normalizedUsername, profile, session } = await findProfile(sessionToken, username);
    await authService.requireCsrf(session, csrfToken);
    if (profile.id === session.account.id) {
      throw new ProfileError('cannot_follow_self', 409);
    }
    await repository.setFollowing(session.account.id, profile.id, following);
    return repository.findPublicProfileByUsername(
      normalizedUsername,
      session.account.id,
    );
  }

  async function updateProfile(sessionToken, csrfToken, input) {
    const session = await authService.getSession(sessionToken);
    await authService.requireCsrf(session, csrfToken);
    const profile = await repository.updateProfile(session.account.id, {
      description: validateDescription(input.description),
      usernameColor: validateUsernameColor(input.usernameColor),
      usernameColorEffect: validateUsernameColorEffect(
        input.usernameColorEffect ?? session.account.usernameColorEffect ?? 'none',
      ),
    });
    if (!profile) {
      throw new ProfileError('username_color_effect_locked', 403);
    }
    return profile;
  }

  async function redeemUsernameColorUnlock(sessionToken, csrfToken, input) {
    const session = await authService.getSession(sessionToken);
    await authService.requireCsrf(session, csrfToken);
    const tokenDigest = digestUsernameColorUnlockCode(input.code);
    if (!tokenDigest) {
      throw new ProfileError('invalid_unlock_code', 400);
    }
    if (!await repository.redeemUsernameColorUnlockCode(session.account.id, tokenDigest)) {
      throw new ProfileError('invalid_unlock_code', 400);
    }
    return { usernameColorEffectsUnlocked: true };
  }

  return {
    getProfile,
    redeemUsernameColorUnlock,
    searchMentionUsernames,
    setFollowing,
    updateProfile,
  };
}