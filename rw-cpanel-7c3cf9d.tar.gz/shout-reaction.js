import emojiRegex from 'emoji-regex';
import { normalizeDatabaseId } from './database-id.js';

const maximumPageSize = 50;

export class ShoutReactionError extends Error {
  constructor(code, statusCode) {
    super(code);
    this.code = code;
    this.statusCode = statusCode;
  }
}

export function isValidShoutReaction(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length > 32) {
    return false;
  }
  const matches = [...value.matchAll(emojiRegex())];
  return matches.length === 1 && matches[0][0] === value;
}

function parsePageValue(value, fallback, maximum, allowZero = true) {
  if (value === undefined || value === null) {
    return fallback;
  }
  if (!['number', 'string'].includes(typeof value) || !/^\d+$/.test(String(value))) {
    throw new ShoutReactionError('invalid_reaction_query', 400);
  }
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed > maximum || !allowZero && parsed === 0) {
    throw new ShoutReactionError('invalid_reaction_query', 400);
  }
  return parsed;
}

export function createShoutReactionService({ authService, repository }) {
  return Object.freeze({
    async listReactions(sessionToken, shoutId, query = {}) {
      await authService.getSession(sessionToken);
      const id = normalizeDatabaseId(shoutId);
      if (!id) {
        throw new ShoutReactionError('invalid_shout', 400);
      }
      const reaction = query.reaction ?? null;
      if (reaction !== null && !isValidShoutReaction(reaction)) {
        throw new ShoutReactionError('invalid_reaction', 400);
      }
      const limit = parsePageValue(query.limit, reaction ? 5 : 50, maximumPageSize, false);
      const offset = parsePageValue(query.offset, 0, Number.MAX_SAFE_INTEGER);
      const rows = await repository.listShoutReactions(id, reaction, limit + 1, offset);
      if (rows === null) {
        throw new ShoutReactionError('shout_unavailable', 404);
      }
      return {
        hasMore: rows.length > limit,
        nextOffset: offset + Math.min(rows.length, limit),
        reactions: rows.slice(0, limit),
      };
    },
  });
}