function mapThread(row) {
  return {
    createdAt: row.created_at,
    id: String(row.id),
    lockedAt: row.locked_at,
    memberCount: Number(row.member_count ?? 0),
    ownerId: row.owner_account_id,
    participantUsernames: row.participant_usernames ?? [],
    title: row.title,
    updatedAt: row.updated_at,
  };
}

function mapMessage(row) {
  return {
    author: row.username,
    authorId: row.author_account_id,
    body: row.body,
    createdAt: row.created_at,
    id: String(row.id),
    mentionUsernames: row.mention_usernames ?? [],
    threadId: String(row.thread_id),
  };
}

async function recordLifecycleAudit(client, {
  action,
  actorId,
  details,
  reason,
  targetId,
}) {
  await client.query(
    `INSERT INTO moderation_audit_events (
       actor_account_id, target_account_id, action, reason, details
     ) VALUES ($1, $2, $3, $4, $5::jsonb)`,
    [actorId, targetId, action, reason, JSON.stringify(details)],
  );
}

async function notifyThreadMembers(client, actorId, threadId, message) {
  await client.query(
    `INSERT INTO notifications (account_id, message, href)
    SELECT members.account_id, actor.username || $3, '/messages'
     FROM direct_message_members members
     JOIN accounts recipients ON recipients.id = members.account_id
     JOIN accounts actor ON actor.id = $2
     WHERE members.thread_id = $1
       AND members.account_id <> $2
       AND members.left_at IS NULL
       AND recipients.membership_status = 'active'
       AND recipients.deleted_at IS NULL`,
    [threadId, actorId, message],
  );
}

export function createDirectMessageRepository(pool) {
  async function withTransaction(operation) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await operation(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async function selectThread(queryable, threadId) {
    const result = await queryable.query(
      `SELECT threads.*,
        count(members.account_id) FILTER (WHERE members.left_at IS NULL) AS member_count
       FROM direct_message_threads threads
       LEFT JOIN direct_message_members members ON members.thread_id = threads.id
       WHERE threads.id = $1
       GROUP BY threads.id`,
      [threadId],
    );
    return result.rows[0] ? mapThread(result.rows[0]) : null;
  }

  async function selectMessage(queryable, messageId) {
    const result = await queryable.query(
      `SELECT messages.*, accounts.username,
        ARRAY(
          SELECT mentioned.username
          FROM direct_message_mentions
          JOIN accounts mentioned
            ON mentioned.id = direct_message_mentions.mentioned_account_id
          WHERE direct_message_mentions.message_id = messages.id
            AND mentioned.membership_status = 'active'
            AND mentioned.deleted_at IS NULL
          ORDER BY mentioned.normalized_username
        ) AS mention_usernames
       FROM direct_messages messages
       JOIN accounts ON accounts.id = messages.author_account_id
       WHERE messages.id = $1`,
      [messageId],
    );
    return result.rows[0] ? mapMessage(result.rows[0]) : null;
  }

  async function selectUnreadCount(queryable, accountId) {
    const result = await queryable.query(
      `SELECT count(*)::integer AS unread_count
       FROM direct_message_members viewer_members
       JOIN direct_messages messages ON messages.thread_id = viewer_members.thread_id
       WHERE viewer_members.account_id = $1
         AND viewer_members.left_at IS NULL
         AND messages.author_account_id <> $1
         AND messages.id > GREATEST(
           viewer_members.last_read_message_id,
           COALESCE(viewer_members.visible_after_message_id, 0)
         )`,
      [accountId],
    );
    return Number(result.rows[0]?.unread_count ?? 0);
  }

  return {
    async createMessage(accountId, threadId, body, mentions = []) {
      return withTransaction(async (client) => {
        const access = await client.query(
          `SELECT threads.id
           FROM direct_message_threads threads
           JOIN direct_message_members viewer_members
             ON viewer_members.thread_id = threads.id
             AND viewer_members.account_id = $2
             AND viewer_members.left_at IS NULL
           WHERE threads.id = $1 AND threads.locked_at IS NULL
           FOR UPDATE OF threads, viewer_members`,
          [threadId, accountId],
        );
        if (!access.rows[0]) {
          return null;
        }
        const inserted = await client.query(
          `INSERT INTO direct_messages (thread_id, author_account_id, body)
           VALUES ($1, $2, $3) RETURNING id`,
          [threadId, accountId, body],
        );
        await client.query(
          `INSERT INTO direct_message_mentions (message_id, mentioned_account_id)
           SELECT $3, id FROM accounts
           WHERE normalized_username = ANY($1::text[])
             AND id <> $2
             AND membership_status = 'active'
             AND deleted_at IS NULL
           ON CONFLICT DO NOTHING`,
          [mentions, accountId, inserted.rows[0].id],
        );
        await client.query(
          `UPDATE direct_message_threads SET updated_at = now() WHERE id = $1`,
          [threadId],
        );
        await notifyThreadMembers(client, accountId, threadId, ' sent a direct message');
        return selectMessage(client, inserted.rows[0].id);
      });
    },
    async createThread(accountId, title, usernames) {
      if (!Array.isArray(usernames) || usernames.length === 0) {
        return null;
      }
      return withTransaction(async (client) => {
        const invited = await client.query(
          `SELECT id FROM accounts
           WHERE normalized_username = ANY($1::text[])
             AND id <> $2
             AND membership_status = 'active'
             AND deleted_at IS NULL
           ORDER BY id`,
          [usernames, accountId],
        );
        if (invited.rows.length !== usernames.length) {
          return null;
        }
        const threadResult = await client.query(
          `INSERT INTO direct_message_threads (title, owner_account_id)
           VALUES ($1, $2) RETURNING id`,
          [title, accountId],
        );
        const threadId = threadResult.rows[0].id;
        await client.query(
          `INSERT INTO direct_message_members (
             thread_id, account_id, invited_by, visible_after_message_id
           ) VALUES ($1, $2, $2, 0)`,
          [threadId, accountId],
        );
        for (const { id } of invited.rows) {
          await client.query(
            `INSERT INTO direct_message_members (
               thread_id, account_id, invited_by, visible_after_message_id
             ) VALUES ($1, $2, $3, 0)`,
            [threadId, id, accountId],
          );
        }
        await notifyThreadMembers(
          client,
          accountId,
          threadId,
          ' started a direct message with you',
        );
        await recordLifecycleAudit(client, {
          action: 'direct_message.create',
          actorId: accountId,
          details: { invitedCount: invited.rows.length, threadId: String(threadId) },
          reason: 'Private thread created',
          targetId: accountId,
        });
        return selectThread(client, threadId);
      });
    },
    async getThread(accountId, threadId, limit, offset) {
      return withTransaction(async (client) => {
        const threadResult = await client.query(
          `SELECT threads.*, viewer_members.joined_at AS viewer_joined_at,
             viewer_members.visible_after_message_id AS viewer_visible_after_message_id
           FROM direct_message_threads threads
           JOIN direct_message_members viewer_members
             ON viewer_members.thread_id = threads.id
             AND viewer_members.account_id = $2
             AND viewer_members.left_at IS NULL
           WHERE threads.id = $1
           FOR SHARE OF threads, viewer_members`,
          [threadId, accountId],
        );
        if (!threadResult.rows[0]) {
          return null;
        }
        const membersResult = await client.query(
          `SELECT accounts.id, accounts.username, members.joined_at
           FROM direct_message_members members
           JOIN accounts ON accounts.id = members.account_id
           WHERE members.thread_id = $1 AND members.left_at IS NULL
           ORDER BY members.joined_at, accounts.id`,
          [threadId],
        );
        const messagesResult = await client.query(
          `SELECT messages.*, accounts.username,
            ARRAY(
              SELECT mentioned.username
              FROM direct_message_mentions
              JOIN accounts mentioned
                ON mentioned.id = direct_message_mentions.mentioned_account_id
              WHERE direct_message_mentions.message_id = messages.id
                AND mentioned.membership_status = 'active'
                AND mentioned.deleted_at IS NULL
              ORDER BY mentioned.normalized_username
            ) AS mention_usernames
           FROM direct_messages messages
           JOIN accounts ON accounts.id = messages.author_account_id
           WHERE messages.thread_id = $1 AND (
             ($5::bigint IS NOT NULL AND messages.id > $5)
             OR ($5::bigint IS NULL AND messages.created_at >= $4)
           )
           ORDER BY messages.id DESC LIMIT $2 OFFSET $3`,
          [
            threadId,
            limit,
            offset,
            threadResult.rows[0].viewer_joined_at,
            threadResult.rows[0].viewer_visible_after_message_id,
          ],
        );
        return {
          members: membersResult.rows.map((row) => ({
            id: row.id,
            joinedAt: row.joined_at,
            username: row.username,
          })),
          messages: messagesResult.rows.map(mapMessage),
          thread: mapThread({ ...threadResult.rows[0], member_count: membersResult.rows.length }),
        };
      });
    },
    async inspectThread(actorId, sessionId, threadId, reason, limit, offset) {
      return withTransaction(async (client) => {
        const actorResult = await client.query(
          `SELECT id FROM accounts
           WHERE id = $1 AND role IN ('admin', 'dev', 'owner') AND membership_status = 'active'
             AND deleted_at IS NULL AND force_password_change = false
           FOR UPDATE`,
          [actorId],
        );
        if (!actorResult.rows[0]) {
          return { status: 'denied' };
        }
        const sessionResult = await client.query(
          `SELECT id FROM sessions
           WHERE id = $1 AND account_id = $2 AND revoked_at IS NULL AND expires_at > now()
           FOR UPDATE`,
          [sessionId, actorId],
        );
        if (!sessionResult.rows[0]) {
          return { status: 'denied' };
        }
        const thread = await selectThread(client, threadId);
        if (!thread) {
          return { status: 'not_found' };
        }
        const membersResult = await client.query(
          `SELECT accounts.id, accounts.username, members.joined_at, members.left_at
           FROM direct_message_members members
           JOIN accounts ON accounts.id = members.account_id
           WHERE members.thread_id = $1
           ORDER BY members.joined_at, accounts.id`,
          [threadId],
        );
        const messagesResult = await client.query(
          `SELECT messages.*, accounts.username
           FROM direct_messages messages
           JOIN accounts ON accounts.id = messages.author_account_id
           WHERE messages.thread_id = $1
           ORDER BY messages.created_at, messages.id LIMIT $2 OFFSET $3`,
          [threadId, limit, offset],
        );
        await client.query(
          `INSERT INTO moderation_audit_events (actor_account_id, action, reason, details)
           VALUES ($1, 'direct_message.inspect', $2, $3::jsonb)`,
          [actorId, reason, JSON.stringify({ limit, offset, threadId: String(threadId) })],
        );
        return {
          inspection: {
            members: membersResult.rows.map((row) => ({
              id: row.id,
              joinedAt: row.joined_at,
              leftAt: row.left_at,
              username: row.username,
            })),
            messages: messagesResult.rows.map(mapMessage),
            thread,
          },
          status: 'ok',
        };
      });
    },
    async inviteMember(accountId, threadId, username) {
      return withTransaction(async (client) => {
        const access = await client.query(
          `SELECT threads.id
           FROM direct_message_threads threads
           JOIN direct_message_members owner_membership
             ON owner_membership.thread_id = threads.id
             AND owner_membership.account_id = $2
             AND owner_membership.left_at IS NULL
           WHERE threads.id = $1
             AND threads.owner_account_id = $2
             AND threads.locked_at IS NULL
           FOR UPDATE OF threads, owner_membership`,
          [threadId, accountId],
        );
        if (!access.rows[0]) {
          return null;
        }
        const invited = await client.query(
          `SELECT id FROM accounts
           WHERE normalized_username = $1
             AND id <> $2
             AND membership_status = 'active'
             AND deleted_at IS NULL`,
          [username, accountId],
        );
        if (!invited.rows[0]) {
          return null;
        }
        const membership = await client.query(
          `INSERT INTO direct_message_members (
             thread_id, account_id, invited_by,
             visible_after_message_id, last_read_message_id
           )
           SELECT $1, $2, $3,
             COALESCE(MAX(messages.id), 0), COALESCE(MAX(messages.id), 0)
           FROM direct_messages messages
           WHERE messages.thread_id = $1
           ON CONFLICT (thread_id, account_id) DO UPDATE
           SET invited_by = EXCLUDED.invited_by,
             joined_at = now(),
             left_at = NULL,
             visible_after_message_id = EXCLUDED.visible_after_message_id,
             last_read_message_id = EXCLUDED.last_read_message_id
           WHERE direct_message_members.left_at IS NOT NULL
           RETURNING account_id`,
          [threadId, invited.rows[0].id, accountId],
        );
        if (!membership.rows[0]) {
          return null;
        }
        await client.query(
          `UPDATE direct_message_threads SET updated_at = now() WHERE id = $1`,
          [threadId],
        );
        await recordLifecycleAudit(client, {
          action: 'direct_message.invite',
          actorId: accountId,
          details: { threadId: String(threadId) },
          reason: 'Private thread invitation',
          targetId: invited.rows[0].id,
        });
        return selectThread(client, threadId);
      });
    },
    async leaveThread(accountId, threadId) {
      return withTransaction(async (client) => {
        const currentResult = await client.query(
          `SELECT threads.*
           FROM direct_message_threads threads
           JOIN direct_message_members viewer_members
             ON viewer_members.thread_id = threads.id
             AND viewer_members.account_id = $2
             AND viewer_members.left_at IS NULL
           WHERE threads.id = $1
           FOR UPDATE OF threads, viewer_members`,
          [threadId, accountId],
        );
        const current = currentResult.rows[0];
        if (!current) {
          return null;
        }
        let ownerId = current.owner_account_id;
        let lockedAt = current.locked_at;
        if (ownerId === accountId && !lockedAt) {
          const successorResult = await client.query(
            `SELECT members.account_id
             FROM direct_message_members members
             JOIN accounts ON accounts.id = members.account_id
             WHERE members.thread_id = $1
               AND members.account_id <> $2
               AND members.left_at IS NULL
               AND accounts.membership_status = 'active'
               AND accounts.deleted_at IS NULL
             ORDER BY members.joined_at, members.account_id
             LIMIT 1 FOR UPDATE OF members`,
            [threadId, accountId],
          );
          ownerId = successorResult.rows[0]?.account_id ?? null;
          lockedAt = ownerId ? null : new Date();
          await client.query(
            `UPDATE direct_message_threads
             SET owner_account_id = $2, locked_at = $3, updated_at = now()
             WHERE id = $1`,
            [threadId, ownerId, lockedAt],
          );
        } else {
          await client.query(
            `UPDATE direct_message_threads SET updated_at = now() WHERE id = $1`,
            [threadId],
          );
        }
        await client.query(
          `UPDATE direct_message_members SET left_at = now()
           WHERE thread_id = $1 AND account_id = $2 AND left_at IS NULL`,
          [threadId, accountId],
        );
        await recordLifecycleAudit(client, {
          action: 'direct_message.leave',
          actorId: accountId,
          details: {
            ownershipChanged: current.owner_account_id !== ownerId,
            threadId: String(threadId),
            threadLocked: Boolean(lockedAt),
          },
          reason: 'Private thread left',
          targetId: accountId,
        });
        return { id: String(threadId), left: true, lockedAt, ownerId };
      });
    },
    async listInspectionThreads(limit, offset) {
      const result = await pool.query(
        `SELECT threads.*,
          count(members.account_id) FILTER (WHERE members.left_at IS NULL) AS member_count
         FROM direct_message_threads threads
         LEFT JOIN direct_message_members members ON members.thread_id = threads.id
         GROUP BY threads.id
         ORDER BY threads.updated_at DESC, threads.id DESC LIMIT $1 OFFSET $2`,
        [limit, offset],
      );
      return result.rows.map(mapThread);
    },
    async listThreads(accountId, limit, offset) {
      const result = await pool.query(
        `SELECT threads.*,
          count(members.account_id) FILTER (WHERE members.left_at IS NULL) AS member_count,
          ARRAY(
            SELECT accounts.username
            FROM direct_message_members participants
            JOIN accounts ON accounts.id = participants.account_id
            WHERE participants.thread_id = threads.id
              AND participants.account_id <> $1
              AND participants.left_at IS NULL
              AND accounts.membership_status = 'active'
              AND accounts.deleted_at IS NULL
            ORDER BY accounts.normalized_username, accounts.id
          ) AS participant_usernames
         FROM direct_message_threads threads
         JOIN direct_message_members viewer_members
           ON viewer_members.thread_id = threads.id
           AND viewer_members.account_id = $1
           AND viewer_members.left_at IS NULL
         LEFT JOIN direct_message_members members ON members.thread_id = threads.id
         GROUP BY threads.id
         ORDER BY threads.updated_at DESC, threads.id DESC LIMIT $2 OFFSET $3`,
        [accountId, limit, offset],
      );
      return result.rows.map(mapThread);
    },
    async countUnreadMessages(accountId) {
      return selectUnreadCount(pool, accountId);
    },
    async markThreadRead(accountId, threadId) {
      return withTransaction(async (client) => {
        const result = await client.query(
          `UPDATE direct_message_members viewer_members
           SET last_read_message_id = GREATEST(
             viewer_members.last_read_message_id,
             COALESCE((
               SELECT MAX(messages.id)
               FROM direct_messages messages
               WHERE messages.thread_id = viewer_members.thread_id
             ), 0)
           )
           WHERE viewer_members.thread_id = $1
             AND viewer_members.account_id = $2
             AND viewer_members.left_at IS NULL
           RETURNING viewer_members.last_read_message_id`,
          [threadId, accountId],
        );
        if (!result.rows[0]) {
          return null;
        }
        return { unreadCount: await selectUnreadCount(client, accountId) };
      });
    },
    async lockThread(accountId, threadId) {
      return withTransaction(async (client) => {
        const current = await client.query(
          `SELECT threads.id
           FROM direct_message_threads threads
           JOIN direct_message_members owner_membership
             ON owner_membership.thread_id = threads.id
             AND owner_membership.account_id = $2
             AND owner_membership.left_at IS NULL
           WHERE threads.id = $1
             AND threads.owner_account_id = $2
             AND threads.locked_at IS NULL
           FOR UPDATE OF threads, owner_membership`,
          [threadId, accountId],
        );
        if (!current.rows[0]) {
          return null;
        }
        await client.query(
          `UPDATE direct_message_threads SET locked_at = now(), updated_at = now()
           WHERE id = $1`,
          [threadId],
        );
        await recordLifecycleAudit(client, {
          action: 'direct_message.lock',
          actorId: accountId,
          details: { threadId: String(threadId) },
          reason: 'Private thread locked',
          targetId: accountId,
        });
        return selectThread(client, threadId);
      });
    },
  };
}