const e=new Set(["admin","dev","owner"]);export function isAdministratorRole(n){return e.has(n)}export function displayRole(e){return{dev:"Dev",owner:"Owner"}[e]??e}
