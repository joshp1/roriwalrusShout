export function isShoutboxNearBottom({clientHeight:o,scrollHeight:t,scrollTop:e},r=2){return t-o-e<=r}
