import { WebSocket, WebSocketServer } from 'ws';
import { stripHtmlTags } from './authored-text.js';
import { normalizeDatabaseId } from './database-id.js';
import { getClientAddress } from './request-limits.js';
import { extractMarkdownMentionUsernames, MentionError } from './mentions.js';
import { hasPermission, isAdministrator, permissions } from './policy.js';
import { isValidShoutReaction } from './shout-reaction.js';

const maximumShoutCursor = 9_223_372_036_854_775_807n;
export const maximumShoutboxBufferedBytes = 256 * 1024;

function parseShoutCursor(value) {
  if (value === null) {
    return null;
  }
  if (!/^(0|[1-9]\d{0,18})$/.test(value)) {
    return undefined;
  }
  return BigInt(value) <= maximumShoutCursor ? value : undefined;
}

function isCursorAfter(candidate, cursor) {
  const parsedCandidate = parseShoutCursor(candidate);
  return parsedCandidate !== undefined
    && parsedCandidate !== null
    && BigInt(parsedCandidate) > BigInt(cursor);
}

export function isShoutboxBackpressured(webSocket, maximumBufferedBytes, nextFrameBytes = 0) {
  return webSocket.bufferedAmount + nextFrameBytes > maximumBufferedBytes;
}

function rejectUpgrade(socket, statusCode, message, headers = {}) {
  const headerLines = Object.entries(headers)
    .map(([name, value]) => `${name}: ${value}\r\n`)
    .join('');
  socket.write(
    `HTTP/1.1 ${statusCode} ${message}\r\nConnection: close\r\n${headerLines}\r\n`,
  );
  socket.destroy();
}

export function attachShoutbox({
  authService,
  clearTimer = clearTimeout,
  clock = () => Date.now(),
  connectionLimit = { limit: 20, windowMs: 60_000 },
  maximumCatchUpChanges = 50,
  maximumBufferedBytes = maximumShoutboxBufferedBytes,
  maximumPendingDeliveries = 50,
  messageLimit = { limit: 60, windowMs: 60_000 },
  publicOrigin,
  readSessionToken,
  repository,
  requestLimiter,
  server,
  setTimer = setTimeout,
  trustedProxyAddresses = new Set(),
}) {
  const socketServer = new WebSocketServer({ maxPayload: 4096, noServer: true });
  const connectionStates = new Map();

  function removeConnection(webSocket) {
    const state = connectionStates.get(webSocket);
    if (state?.timer) {
      clearTimer(state.timer);
    }
    connectionStates.delete(webSocket);
  }

  function closeConnection(webSocket, code, reason) {
    removeConnection(webSocket);
    if (webSocket.readyState === WebSocket.OPEN) {
      webSocket.close(code, reason);
    }
  }

  function sendPayload(webSocket, payload) {
    const encoded = JSON.stringify(payload);
    if (
      webSocket.readyState !== WebSocket.OPEN
      || isShoutboxBackpressured(webSocket, maximumBufferedBytes, Buffer.byteLength(encoded))
    ) {
      closeConnection(webSocket, 1013, 'Transport buffer exceeded');
      return false;
    }
    webSocket.send(encoded);
    return true;
  }

  async function drainDeliveries(webSocket) {
    const state = connectionStates.get(webSocket);
    if (
      !state
      || !state.ready
      || state.draining
      || state.timer
      || state.pending.length === 0
      || webSocket.readyState !== WebSocket.OPEN
    ) {
      return;
    }

    state.draining = true;
    try {
      const session = await authService.getSession(state.sessionToken);
      const slowdownMs = isAdministrator(session.account) || session.account.role === 'moderator'
        ? 0
        : session.account.slowdownMs ?? 0;
      const waitMs = Math.max(0, state.lastDeliveredAt + slowdownMs - clock());
      if (waitMs > 0) {
        state.timer = setTimer(() => {
          state.timer = null;
          void drainDeliveries(webSocket);
        }, waitMs);
        return;
      }

      const payload = state.pending.shift();
      if (!sendPayload(webSocket, payload)) {
        return;
      }
      state.lastDeliveredAt = clock();
    } catch {
      closeConnection(webSocket, 1008, 'Account unavailable');
    } finally {
      state.draining = false;
    }

    if (state.pending.length > 0 && !state.timer) {
      void drainDeliveries(webSocket);
    }
  }

  function enqueueDelivery(webSocket, payload) {
    const state = connectionStates.get(webSocket);
    if (!state) {
      return;
    }
    if (state.pending.length >= maximumPendingDeliveries) {
      closeConnection(webSocket, 1013, 'Update queue exceeded');
      return;
    }
    state.pending.push(payload);
    void drainDeliveries(webSocket);
  }

  function broadcast(payload) {
    for (const client of socketServer.clients) {
      if (client.readyState === WebSocket.OPEN) {
        enqueueDelivery(client, payload);
      }
    }
  }

  function broadcastReaction(shout, actorId) {
    for (const [client, state] of connectionStates) {
      if (client.readyState === WebSocket.OPEN) {
        enqueueDelivery(client, {
          cursor: shout.syncCursor,
          id: shout.id,
          reactions: shout.reactions,
          type: 'shout_reaction',
          viewerReaction: state.accountId === actorId ? shout.viewerReaction : undefined,
        });
      }
    }
  }

  async function loadReadyPayload(cursor, viewerId) {
    if (cursor !== null) {
      const currentCursor = await repository.getShoutboxCursor();
      if (BigInt(cursor) > BigInt(currentCursor)) {
        const snapshot = await repository.getShoutboxSnapshot(50, viewerId);
        return { ...snapshot, reset: true, type: 'ready' };
      }
      const changes = await repository.listShoutChanges(
        cursor,
        maximumCatchUpChanges + 1,
        viewerId,
      );
      if (changes.length <= maximumCatchUpChanges) {
        return {
          changes,
          cursor: changes.at(-1)?.cursor ?? cursor,
          reset: false,
          type: 'ready',
        };
      }
    }

    const snapshot = await repository.getShoutboxSnapshot(50, viewerId);
    return { ...snapshot, reset: true, type: 'ready' };
  }

  server.on('upgrade', async (request, socket, head) => {
    const requestUrl = new URL(request.url ?? '/', 'http://localhost');
    if (requestUrl.pathname !== '/shoutbox') {
      rejectUpgrade(socket, 404, 'Not Found');
      return;
    }
    const cursor = parseShoutCursor(requestUrl.searchParams.get('cursor'));
    if (cursor === undefined) {
      rejectUpgrade(socket, 400, 'Bad Request');
      return;
    }
    if (publicOrigin && request.headers.origin !== publicOrigin) {
      rejectUpgrade(socket, 403, 'Forbidden');
      return;
    }
    const address = getClientAddress(request, trustedProxyAddresses);
    const admission = requestLimiter
      ? requestLimiter.consume(`shoutbox_connection:${address}`, connectionLimit)
      : { allowed: true };
    const sessionToken = readSessionToken(request);
    try {
      const session = await authService.getSession(sessionToken);
      if (!admission.allowed && !isAdministrator(session.account) && session.account.role !== 'moderator') {
        rejectUpgrade(socket, 429, 'Too Many Requests', {
          'Retry-After': String(Math.ceil(admission.retryAfterMs / 1000)),
        });
        return;
      }
      if (!session.account.preferences.shoutboxEnabled) {
        rejectUpgrade(socket, 403, 'Forbidden');
        return;
      }
      socketServer.handleUpgrade(request, socket, head, (webSocket) => {
        socketServer.emit('connection', webSocket, request, {
          accountId: session.account.id,
          address,
          cursor,
          sessionToken,
        });
      });
    } catch {
      rejectUpgrade(socket, 401, 'Unauthorized');
    }
  });

  socketServer.on('connection', async (
    webSocket,
    _request,
    { accountId, address, cursor, sessionToken },
  ) => {
    const state = {
      accountId,
      address,
      draining: false,
      lastDeliveredAt: clock(),
      pending: [],
      ready: false,
      sessionToken,
      timer: null,
    };
    connectionStates.set(webSocket, state);
    webSocket.once('close', () => removeConnection(webSocket));
    webSocket.on('error', () => removeConnection(webSocket));
    try {
      const readyPayload = await loadReadyPayload(cursor, accountId);
      if (!sendPayload(webSocket, readyPayload)) {
        return;
      }
      state.pending = state.pending.filter((payload) => (
        !payload.cursor || isCursorAfter(payload.cursor, readyPayload.cursor)
      ));
      state.ready = true;
      void drainDeliveries(webSocket);
    } catch {
      removeConnection(webSocket);
      webSocket.close(1011, 'Shoutbox unavailable');
      return;
    }

    webSocket.on('message', async (rawMessage, isBinary) => {
      try {
        const session = await authService.getSession(sessionToken);
        if (requestLimiter && !isAdministrator(session.account) && session.account.role !== 'moderator') {
          const admission = requestLimiter.consume(`shoutbox_message:${state.address}`, messageLimit);
          if (!admission.allowed) {
            sendPayload(webSocket, {
              code: 'shoutbox_rate_limited',
              retryAfterMs: admission.retryAfterMs,
              type: 'error',
            });
            return;
          }
        }
        if (isBinary) {
          sendPayload(webSocket, { code: 'invalid_message', type: 'error' });
          return;
        }
        const message = JSON.parse(rawMessage.toString());
        if (!['delete', 'edit', 'reaction', 'shout'].includes(message.type)) {
          sendPayload(webSocket, { code: 'invalid_shout', type: 'error' });
          return;
        }
        if (!session.account.preferences.shoutboxEnabled) {
          webSocket.close(1008, 'Shoutbox disabled');
          return;
        }

        const body = typeof message.body === 'string' ? stripHtmlTags(message.body).trim() : '';
        const reason = typeof message.reason === 'string' ? stripHtmlTags(message.reason).trim() : '';
        const shoutId = normalizeDatabaseId(message.id);
        const canModerate = hasPermission(session.account, permissions.shoutsModerate);
        if (message.type === 'delete') {
          if (!shoutId) {
            sendPayload(webSocket, { code: 'invalid_shout', type: 'error' });
            return;
          }
          const result = await repository.deleteShout(
            session.account.id,
            shoutId,
            canModerate,
            reason,
          );
          if (!result || result.reasonRequired) {
            sendPayload(webSocket, {
              code: result?.reasonRequired ? 'moderation_reason_required' : 'shout_unavailable',
              type: 'error',
            });
            return;
          }
          broadcast({ cursor: result.cursor, id: result.id, type: 'shout_deleted' });
          return;
        }

        if (message.type === 'reaction') {
          if (!shoutId || !isValidShoutReaction(message.reaction)) {
            sendPayload(webSocket, { code: 'invalid_reaction', type: 'error' });
            return;
          }
          const result = await repository.toggleShoutReaction(
            session.account.id,
            shoutId,
            message.reaction,
          );
          if (!result) {
            sendPayload(webSocket, { code: 'shout_unavailable', type: 'error' });
            return;
          }
          broadcastReaction(result, session.account.id);
          return;
        }

        if (body.length === 0 || body.length > 500 || (message.type === 'edit' && !shoutId)) {
          sendPayload(webSocket, { code: 'invalid_shout', type: 'error' });
          return;
        }
        await authService.requireShoutboxPostingAllowed(session.account);
        if (message.type === 'edit') {
          const result = await repository.updateShout(
            session.account.id,
            shoutId,
            body,
            extractMarkdownMentionUsernames(body),
            canModerate,
            reason,
          );
          if (!result || result.reasonRequired) {
            sendPayload(webSocket, {
              code: result?.reasonRequired ? 'moderation_reason_required' : 'shout_unavailable',
              type: 'error',
            });
            return;
          }
          broadcast({ cursor: result.syncCursor, shout: result, type: 'shout_updated' });
          return;
        }

        const shout = await repository.createShout(
          session.account.id,
          body,
          extractMarkdownMentionUsernames(body),
        );
        broadcast({ cursor: shout.syncCursor, shout, type: 'shout' });
      } catch (error) {
        const postingLimited = [
          'posting_flood_detected',
          'posting_rate_limited',
          'posting_slowdown',
        ].includes(error?.code);
        const postingMuted = error?.code === 'shoutbox_posting_muted';
        const invalidMention = error instanceof MentionError;
        sendPayload(webSocket, {
          code: postingLimited || postingMuted || invalidMention ? error.code : 'invalid_message',
          retryAfterMs: postingLimited ? error.retryAfterMs : undefined,
          type: 'error',
        });
      }
    });
  });

  server.on('close', () => {
    for (const webSocket of connectionStates.keys()) {
      removeConnection(webSocket);
    }
    socketServer.close();
  });
  return socketServer;
}